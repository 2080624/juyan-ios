/// 主框架：四底栏（消息 / 通讯录 / 发现 / 我的）
library;

import 'package:flutter/material.dart';

import '../core/state.dart';
import '../core/theme.dart';
import '../widgets/kit.dart';
import 'contacts.dart';
import 'discover.dart';
import 'messages.dart';
import 'mine.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

class ShellPage extends StatefulWidget {
  const ShellPage({super.key});
  @override
  State<ShellPage> createState() => _ShellPageState();
}

class _ShellPageState extends State<ShellPage> {
  int idx = 0;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final pages = [
          const MessagesPage(),
          const ContactsPage(),
          const DiscoverPage(),
          const MinePage(),
        ];
        final unread = st.convos.where((c) => st.unreadOf(c) && !c.id.startsWith('__hidden')).length;
        final pending = st.pendingReqs.length + st.groupInvites.length;

        return Scaffold(
          backgroundColor: C.bgApp,
          body: IndexedStack(index: idx, children: pages),
          bottomNavigationBar: Container(
            decoration: const BoxDecoration(
              color: Colors.white,
              border: Border(top: BorderSide(color: C.divider, width: 0.6)),
            ),
            child: SafeArea(
              top: false,
              child: SizedBox(
                height: 54,
                child: Row(
                  children: [
                    _tab(0, LucideIcons.messageCircle, LucideIcons.messageCircle, '消息', unread),
                    _tab(1, LucideIcons.users, LucideIcons.users, '通讯录', pending),
                    _tab(2, LucideIcons.compass, LucideIcons.compass, '发现', 0),
                    _tab(3, LucideIcons.user, LucideIcons.user, '我的', 0),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _tab(int i, IconData off, IconData on, String label, int badge) {
    final active = idx == i;
    return Expanded(
      child: InkWell(
        onTap: () => setState(() => idx = i),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              clipBehavior: Clip.none,
              children: [
                Icon(active ? on : off, size: 25, color: active ? C.primary : C.textSub),
                if (badge > 0)
                  Positioned(
                    right: -9,
                    top: -5,
                    child: Dot(count: badge),
                  ),
              ],
            ),
            const SizedBox(height: 2),
            Text(label, style: TextStyle(fontSize: 10.5, color: active ? C.primary : C.textSub, fontWeight: active ? FontWeight.w600 : FontWeight.w400)),
          ],
        ),
      ),
    );
  }
}

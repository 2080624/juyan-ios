/// 朋友圈（动态）
library;

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../data/models.dart';
import '../widgets/kit.dart';
import 'friend.dart';
import 'misc.dart';

class MomentsPage extends StatefulWidget {
  final String onlyUserId;
  const MomentsPage({super.key, this.onlyUserId = ''});
  @override
  State<MomentsPage> createState() => _MomentsPageState();
}

class _MomentsPageState extends State<MomentsPage> {
  List<Moment> list = [];
  Map<String, List<MomentComment>> comments = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final st = AppState.I;
    try {
      final l = widget.onlyUserId.isNotEmpty ? await Api.I.myMoments(widget.onlyUserId) : await Api.I.moments(perPage: 40);
      final cs = await Api.I.comments(l.map((e) => e.id).toList());
      final grouped = <String, List<MomentComment>>{};
      for (final c in cs) {
        grouped.putIfAbsent(c.moment, () => []).add(c);
      }
      final ids = l.map((e) => e.user).toSet().toList();
      final got = await Api.I.profilesByIds(ids);
      st.people.addAll(got);
      if (mounted) {
        setState(() {
          list = l;
          comments = grouped;
          loading = false;
        });
      }
    } catch (_) {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: widget.onlyUserId.isEmpty ? '朋友圈' : '他的动态',
      bg: Colors.white,
      actions: [
        if (widget.onlyUserId.isEmpty)
          IconButton(
            icon: const Icon(Icons.add_a_photo_outlined, size: 22),
            onPressed: () async {
              await Nav.push(const PublishMomentPage());
              _load();
            },
          ),
      ],
      child: RefreshIndicator(
        onRefresh: _load,
        child: loading
            ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
            : list.isEmpty
                ? ListView(children: const [SizedBox(height: 140), Empty(text: '还没有动态，发一条试试', icon: Icons.photo_library_outlined)])
                : ListView.builder(
                    itemCount: list.length,
                    itemBuilder: (context, i) {
                      final m = list[i];
                      final p = st.personOf(m.user);
                      final cs = comments[m.id] ?? [];
                      return Container(
                        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
                        decoration: const BoxDecoration(border: Border(bottom: BorderSide(color: C.divider, width: 0.5))),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            GestureDetector(
                              onTap: () => Nav.push(UserProfilePage(userId: m.user)),
                              child: Avatar(url: p == null ? '' : profileAvatar(p), name: m.authorName.isNotEmpty ? m.authorName : (p?.nickname ?? ''), size: 42),
                            ),
                            const SizedBox(width: 11),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Flexible(
                                        child: Text(
                                          m.authorName.isNotEmpty ? m.authorName : (p?.nickname ?? ''),
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: TextStyle(fontSize: 14.5, fontWeight: FontWeight.w600, color: nameColor(redName: p?.redName ?? false, vip: p?.vipAlive ?? false)),
                                        ),
                                      ),
                                      NameTags(red: p?.redName ?? false, vip: st.vipOf(m.user), scale: 0.9),
                                    ],
                                  ),
                                  if (m.content.isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Text(m.content, style: const TextStyle(fontSize: 14.5, height: 1.5)),
                                    ),
                                  if (m.images.isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 8),
                                      child: Wrap(
                                        spacing: 5,
                                        runSpacing: 5,
                                        children: m.images
                                            .map((img) => GestureDetector(
                                                  onTap: () => Nav.push(ImageViewerPage(url: momentImageUrl(m, img))),
                                                  child: RemoteImg(url: momentImageUrl(m, img), width: 98, height: 98, fit: BoxFit.cover),
                                                ))
                                            .toList(),
                                      ),
                                    ),
                                  if (m.place.isNotEmpty)
                                    Padding(
                                      padding: const EdgeInsets.only(top: 7),
                                      child: Text(m.place, style: const TextStyle(fontSize: 12, color: C.primary)),
                                    ),
                                  Padding(
                                    padding: const EdgeInsets.only(top: 8),
                                    child: Row(
                                      children: [
                                        Text(fmtTime(m.created), style: const TextStyle(fontSize: 12, color: C.textMute)),
                                        const Spacer(),
                                        IconButton(
                                          visualDensity: VisualDensity.compact,
                                          icon: Icon(Icons.thumb_up_alt_outlined, size: 17, color: C.textSub),
                                          onPressed: () async {
                                            await Api.I.updateMoment(m.id, {'likes': m.likes + 1}).catchError((_) {});
                                            _load();
                                          },
                                        ),
                                        Text('${m.likes}', style: const TextStyle(fontSize: 12, color: C.textSub)),
                                        const SizedBox(width: 10),
                                        IconButton(
                                          visualDensity: VisualDensity.compact,
                                          icon: const Icon(Icons.mode_comment_outlined, size: 17, color: C.textSub),
                                          onPressed: () async {
                                            final v = await promptDialog(context, '写评论', hint: '说点什么…');
                                            if (v == null || v.isEmpty) return;
                                            await Api.I.addComment(m.id, st.user!.id, st.displayName, v).catchError((_) {});
                                            _load();
                                          },
                                        ),
                                      ],
                                    ),
                                  ),
                                  if (cs.isNotEmpty)
                                    Container(
                                      margin: const EdgeInsets.only(top: 6),
                                      padding: const EdgeInsets.all(9),
                                      width: double.infinity,
                                      decoration: BoxDecoration(color: C.surfaceHover, borderRadius: BorderRadius.circular(8)),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: cs
                                            .map((c) => Padding(
                                                  padding: const EdgeInsets.symmetric(vertical: 2),
                                                  child: Text.rich(
                                                    TextSpan(children: [
                                                      TextSpan(text: '${c.authorName}：', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: C.primaryDeep)),
                                                      TextSpan(text: c.content, style: const TextStyle(fontSize: 13)),
                                                    ]),
                                                  ),
                                                ))
                                            .toList(),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}

class PublishMomentPage extends StatefulWidget {
  const PublishMomentPage({super.key});
  @override
  State<PublishMomentPage> createState() => _PublishMomentPageState();
}

class _PublishMomentPageState extends State<PublishMomentPage> {
  final ctl = TextEditingController();
  final place = TextEditingController();
  final files = <File>[];
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '发表动态',
      actions: [
        TextButton(
          onPressed: busy
              ? null
              : () async {
                  if (ctl.text.trim().isEmpty && files.isEmpty) {
                    st.say('写点什么或选张图');
                    return;
                  }
                  setState(() => busy = true);
                  try {
                    await Api.I.createMoment(st.user!.id, st.displayName, ctl.text.trim(), files, place: place.text.trim());
                    Nav.pop();
                    st.say('已发布');
                  } catch (_) {
                    st.say('发布失败');
                  }
                  setState(() => busy = false);
                },
          child: const Text('发表', style: TextStyle(fontWeight: FontWeight.w600)),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
            child: Column(
              children: [
                TextField(controller: ctl, maxLines: 5, decoration: const InputDecoration(hintText: '这一刻的想法…', filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none)),
                const Divider(),
                TextField(controller: place, decoration: const InputDecoration(hintText: '所在位置（可不填）', filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none)),
              ],
            ),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              ...files.map((f) => Stack(
                    clipBehavior: Clip.none,
                    children: [
                      ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.file(f, width: 92, height: 92, fit: BoxFit.cover)),
                      Positioned(
                        right: -6,
                        top: -6,
                        child: GestureDetector(
                          onTap: () => setState(() => files.remove(f)),
                          child: Container(
                            decoration: const BoxDecoration(color: Colors.black54, shape: BoxShape.circle),
                            padding: const EdgeInsets.all(3),
                            child: const Icon(Icons.close_rounded, color: Colors.white, size: 13),
                          ),
                        ),
                      ),
                    ],
                  )),
              GestureDetector(
                onTap: () async {
                  final picked = await ImagePicker().pickMultiImage(imageQuality: 80, maxWidth: 1400);
                  if (picked.isEmpty) return;
                  setState(() => files.addAll(picked.map((e) => File(e.path)).take(9 - files.length)));
                },
                child: Container(
                  width: 92,
                  height: 92,
                  decoration: BoxDecoration(color: C.surfaceHover, borderRadius: BorderRadius.circular(10), border: Border.all(color: C.divider)),
                  child: const Icon(Icons.add_photo_alternate_outlined, color: C.textMute, size: 28),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text('最多 9 张图 · 已选 ${files.length}', style: const TextStyle(fontSize: 12, color: C.textMute)),
        ],
      ),
    );
  }
}

class MyMomentsPage extends StatelessWidget {
  const MyMomentsPage({super.key});
  @override
  Widget build(BuildContext context) => MomentsPage(onlyUserId: AppState.I.user?.id ?? '');
}

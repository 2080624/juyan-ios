/// 通用组件库
library;

import 'dart:io';
import 'package:flutter/material.dart';
import '../core/theme.dart';

/* --------------------------------- 头像 --------------------------------- */

class Avatar extends StatelessWidget {
  final String url;
  final String name;
  final double size;
  final double radius;
  final Color? bg;
  final bool group;

  const Avatar({super.key, this.url = '', this.name = '', this.size = 44, this.radius = 10, this.bg, this.group = false});

  @override
  Widget build(BuildContext context) {
    final bgc = bg ?? _hashColor(name.isEmpty ? '?' : name);
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: Container(
        width: size,
        height: size,
        color: bgc,
        child: url.isEmpty
            ? Center(
                child: group
                    ? Icon(Icons.groups_rounded, color: Colors.white, size: size * 0.55)
                    : Text(
                        _initial(name),
                        style: TextStyle(color: Colors.white, fontSize: size * 0.4, fontWeight: FontWeight.w600),
                      ),
              )
            : Image.network(
                url,
                width: size,
                height: size,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Center(
                  child: Text(_initial(name), style: TextStyle(color: Colors.white, fontSize: size * 0.4, fontWeight: FontWeight.w600)),
                ),
              ),
      ),
    );
  }

  static String _initial(String n) => n.trim().isEmpty ? '?' : n.trim().substring(0, 1);

  static Color _hashColor(String s) {
    const palette = [
      Color(0xFF1A7DFF), Color(0xFF5B9BFF), Color(0xFF7C88E8), Color(0xFF3F51B8),
      Color(0xFF26B36B), Color(0xFFE5A13B), Color(0xFFE5484D), Color(0xFF9B59B6),
      Color(0xFF16A3B8), Color(0xFF6D7FE0),
    ];
    var h = 0;
    for (final c in s.codeUnits) {
      h = (h * 31 + c) & 0x7fffffff;
    }
    return palette[h % palette.length];
  }
}

class RemoteImg extends StatelessWidget {
  final String url;
  final double? width;
  final double? height;
  final BoxFit fit;
  final File? file;
  const RemoteImg({super.key, required this.url, this.width, this.height, this.fit = BoxFit.cover, this.file});

  @override
  Widget build(BuildContext context) {
    if (file != null) {
      return Image.file(file!, width: width, height: height, fit: fit);
    }
    if (url.isEmpty) {
      return Container(
        width: width,
        height: height,
        color: C.surfaceHover,
        child: const Center(child: Icon(Icons.image_outlined, color: C.textMute, size: 28)),
      );
    }
    return Image.network(url, width: width, height: height, fit: fit,
        loadingBuilder: (c, w, p) => p == null ? w : Container(width: width, height: height, color: C.surfaceHover),
        errorBuilder: (_, __, ___) => Container(
              width: width,
              height: height,
              color: C.surfaceHover,
              child: const Center(child: Icon(Icons.broken_image_outlined, color: C.textMute, size: 26)),
            ));
  }
}

/* --------------------------------- 列表 -------------------------------- */

class Cell extends StatelessWidget {
  final Widget? leading;
  final String title;
  final String? subtitle;
  final String? hint;
  final Widget? trailing;
  final VoidCallback? onTap;
  final bool chevron;
  final double padLeft;
  final EdgeInsets padding;
  final Color? titleColor;
  final Color? background;
  /// 富文本标题（带徽章用）。给了就顶掉 title。
  final Widget? titleWidget;
  /// 富文本副标题（红名 ID 用）。给了就顶掉 subtitle。
  final Widget? subWidget;

  const Cell({
    super.key,
    this.leading,
    this.title = '',
    this.subtitle,
    this.hint,
    this.trailing,
    this.onTap,
    this.chevron = true,
    this.padLeft = 16,
    this.padding = const EdgeInsets.symmetric(vertical: 13),
    this.titleColor,
    this.background,
    this.titleWidget,
    this.subWidget,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: background ?? Colors.transparent,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: EdgeInsets.fromLTRB(padLeft, padding.top, 16, padding.bottom),
          child: Row(
            children: [
              if (leading != null) ...[leading!, const SizedBox(width: 12)],
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    titleWidget ??
                        Text(title, style: TextStyle(fontSize: 16, color: titleColor ?? C.textMain, fontWeight: FontWeight.w400)),
                    if (subWidget != null)
                      Padding(padding: const EdgeInsets.only(top: 3), child: subWidget!)
                    else if (subtitle != null && subtitle!.isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 3),
                        child: Text(subtitle!, style: const TextStyle(fontSize: 12.5, color: C.textSub)),
                      ),
                  ],
                ),
              ),
              if (hint != null && hint!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: Text(hint!, style: const TextStyle(fontSize: 14, color: C.textSub)),
                ),
              if (trailing != null) Padding(padding: const EdgeInsets.only(left: 8), child: trailing!),
              if (chevron && onTap != null)
                const Padding(
                  padding: EdgeInsets.only(left: 6),
                  child: Icon(Icons.chevron_right_rounded, color: C.textMute, size: 20),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 名字 + 一族徽章（对齐网页版 <span class="flex items-center"><span>{name}</span><NameTags/></span>）
/// 红名：名字变红；VIP / 靓号徽章跟着走。
class NameRow extends StatelessWidget {
  final String name;
  final bool red;
  final String vip;
  final String groupType;
  final bool lucky;
  final double scale;
  final bool md;
  final double fontSize;
  final FontWeight fontWeight;
  final Color? color;

  const NameRow({
    super.key,
    required this.name,
    this.red = false,
    this.vip = '',
    this.groupType = '',
    this.lucky = false,
    this.scale = 1,
    this.md = false,
    this.fontSize = 16,
    this.fontWeight = FontWeight.w400,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final isGroup = groupType.isNotEmpty;
    final c = color ?? (isGroup ? groupNameColor(groupType) : null) ?? (red ? C.redName : C.textMain);
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Flexible(
          child: Text(
            name,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: fontSize, fontWeight: fontWeight, color: c),
          ),
        ),
        if (isGroup)
          GroupTags(lucky: lucky, groupType: groupType, scale: scale, md: md)
        else
          NameTags(red: red, vip: vip, scale: scale, md: md),
      ],
    );
  }
}

/// 红名 ID 行（网页版给 ID 行也套 name-red）
class SubName extends StatelessWidget {
  final String text;
  final bool red;
  final double fontSize;
  const SubName({super.key, required this.text, this.red = false, this.fontSize = 12.5});

  @override
  Widget build(BuildContext context) => Text(
        text,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(fontSize: fontSize, color: red ? C.redName : C.textSub),
      );
}

class CellGroup extends StatelessWidget {
  final List<Widget> children;
  final String? header;
  final String? footer;
  final EdgeInsets margin;
  const CellGroup({super.key, required this.children, this.header, this.footer, this.margin = const EdgeInsets.fromLTRB(12, 10, 12, 0)});

  @override
  Widget build(BuildContext context) {
    final list = <Widget>[];
    for (var i = 0; i < children.length; i++) {
      list.add(children[i]);
      if (i != children.length - 1) {
        list.add(const Padding(padding: EdgeInsets.only(left: 16), child: Divider(height: 0.5, color: C.divider)));
      }
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (header != null)
          Padding(padding: const EdgeInsets.fromLTRB(24, 14, 24, 6), child: Text(header!, style: const TextStyle(fontSize: 12.5, color: C.textSub))),
        Container(
          margin: margin,
          decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
          child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Column(children: list)),
        ),
        if (footer != null)
          Padding(padding: const EdgeInsets.fromLTRB(24, 8, 24, 4), child: Text(footer!, style: const TextStyle(fontSize: 12, color: C.textMute))),
      ],
    );
  }
}

class SwitchCell extends StatelessWidget {
  final String title;
  final String? subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const SwitchCell({super.key, required this.title, this.subtitle, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 12, 4),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontSize: 16)),
                if (subtitle != null) Padding(padding: const EdgeInsets.only(top: 2), child: Text(subtitle!, style: const TextStyle(fontSize: 12, color: C.textSub))),
              ],
            ),
          ),
          Switch(value: value, onChanged: onChanged),
        ],
      ),
    );
  }
}

/* --------------------------------- 按钮 -------------------------------- */

class PrimaryButton extends StatelessWidget {
  final String text;
  final VoidCallback? onTap;
  final bool loading;
  final bool disabled;
  final double height;
  final Gradient? gradient;
  const PrimaryButton({super.key, required this.text, this.onTap, this.loading = false, this.disabled = false, this.height = 48, this.gradient});

  @override
  Widget build(BuildContext context) {
    final off = disabled || loading || onTap == null;
    return SizedBox(
      height: height,
      width: double.infinity,
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: off ? null : (gradient ?? C.brandGradient),
          color: off ? const Color(0xFFCBD2DD) : null,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(12),
            onTap: off ? null : onTap,
            child: Center(
              child: loading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : Text(text, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
            ),
          ),
        ),
      ),
    );
  }
}

/* --------------------------------- 其他 -------------------------------- */

class Empty extends StatelessWidget {
  final String text;
  final IconData icon;
  const Empty({super.key, this.text = '还没有内容', this.icon = Icons.inbox_outlined});
  @override
  Widget build(BuildContext context) => Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 54, color: const Color(0xFFD6DAE2)),
            const SizedBox(height: 10),
            Text(text, style: const TextStyle(color: C.textMute, fontSize: 14)),
          ],
        ),
      );
}

class Dot extends StatelessWidget {
  final int count;
  final bool small;
  const Dot({super.key, required this.count, this.small = false});
  @override
  Widget build(BuildContext context) {
    if (count <= 0) return const SizedBox.shrink();
    final txt = count > 99 ? '99+' : '$count';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      constraints: const BoxConstraints(minWidth: 18),
      decoration: BoxDecoration(color: C.danger, borderRadius: BorderRadius.circular(20)),
      child: Text(txt, textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: small ? 10 : 11.5, height: 1.3, fontWeight: FontWeight.w600)),
    );
  }
}

/* ---------------- 名字徽章（靓号 / 会员档位）----------------
   规格逐条照搬网页版 index.css：
   靓号 → 15px 高、4 圆角、135° 红渐变、白字 10 号
   会员 → 15px 高、5 圆角、按档位上渐变 + 1px 白内圈
   至尊档 → 直接用原图 svip-legend.png（跟网页版同一张，颜色一模一样）
------------------------------------------------------------ */

/// 靓号「靓」小标（CSS .name-lucky：15/17 高、4 圆角、135° 红渐变）
class LuckyTag extends StatelessWidget {
  final double scale;
  final bool md;
  const LuckyTag({super.key, this.scale = 1, this.md = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: (md ? 17.0 : 15.0) * scale,
      padding: EdgeInsets.symmetric(horizontal: 4 * scale),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFFF4553F), Color(0xFFDC2626)]),
        borderRadius: BorderRadius.circular(4 * scale),
        boxShadow: const [BoxShadow(color: Color(0x59BE1E1E), blurRadius: 3, offset: Offset(0, 1))],
      ),
      child: Text('靓', style: TextStyle(color: Colors.white, fontSize: (md ? 11.0 : 10.0) * scale, height: 1.0, fontWeight: FontWeight.w700, letterSpacing: 0)),
    );
  }
}

/// 会员徽章（CSS .name-vip：5 圆角、100° 渐变 + 1px 白内圈；至尊档用原图）
class VipTag extends StatelessWidget {
  final String level;
  final double scale;
  final bool md;
  const VipTag({super.key, required this.level, this.scale = 1, this.md = false});

  @override
  Widget build(BuildContext context) {
    if (level.isEmpty) return const SizedBox.shrink();
    if (vipIsLegend(level)) {
      return Image.asset(
        'assets/svip-legend.png',
        height: (md ? 17.0 : 15.0) * scale,
        fit: BoxFit.contain,
        filterQuality: FilterQuality.high,
      );
    }
    final r = 5 * scale;
    return Container(
      height: (md ? 17.0 : 15.0) * scale,
      decoration: BoxDecoration(gradient: vipGradientOf(level), borderRadius: BorderRadius.circular(r)),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 5 * scale),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(r),
          border: Border.all(color: vipRingOf(level), width: 1),
        ),
        child: Text(
          vipLabel(level),
          style: TextStyle(color: Colors.white, fontSize: (md ? 11.0 : 10.0) * scale, height: 1.0, fontWeight: FontWeight.w700, letterSpacing: 0.1),
        ),
      ),
    );
  }
}

/// 群名后的标（CSS .name-group-platinum 金「超」/ 至尊群盘龙原图）
class GroupTypeTag extends StatelessWidget {
  final String groupType;
  final double scale;
  final bool md;
  const GroupTypeTag({super.key, required this.groupType, this.scale = 1, this.md = false});

  @override
  Widget build(BuildContext context) {
    if (groupType == 'diamond') {
      return Image.asset(
        'assets/group-dragon.png',
        height: (md ? 18.0 : 15.0) * scale,
        fit: BoxFit.contain,
        filterQuality: FilterQuality.high,
      );
    }
    if (groupType != 'platinum') return const SizedBox.shrink();
    final r = 5 * scale;
    return Container(
      height: (md ? 17.0 : 15.0) * scale,
      decoration: BoxDecoration(gradient: groupPlatinumGradient, borderRadius: BorderRadius.circular(r)),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 5 * scale),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(r),
          border: Border.all(color: const Color(0x8CFFF3CD), width: 1),
        ),
        child: Text('超', style: TextStyle(color: Colors.white, fontSize: (md ? 11.0 : 10.0) * scale, height: 1.0, fontWeight: FontWeight.w700)),
      ),
    );
  }
}

/// 名字后的一排徽章：靓号 + 会员（CSS .name-tags：外距 4、项间距 3）
class NameTags extends StatelessWidget {
  final bool red;
  final String vip;
  final double scale;
  final bool md;
  const NameTags({super.key, this.red = false, this.vip = '', this.scale = 1, this.md = false});

  @override
  Widget build(BuildContext context) {
    if (!red && vip.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: EdgeInsets.only(left: 4 * scale),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (red) LuckyTag(scale: scale, md: md),
          if (red && vip.isNotEmpty) SizedBox(width: 3 * scale),
          if (vip.isNotEmpty) VipTag(level: vip, scale: scale, md: md),
        ],
      ),
    );
  }
}

/// 群名后的一排徽章：群靓号「靓」+ 群类型标
class GroupTags extends StatelessWidget {
  final bool lucky;
  final String groupType;
  final double scale;
  final bool md;
  const GroupTags({super.key, this.lucky = false, this.groupType = 'normal', this.scale = 1, this.md = false});

  @override
  Widget build(BuildContext context) {
    final hasType = groupType == 'diamond' || groupType == 'platinum';
    if (!lucky && !hasType) return const SizedBox.shrink();
    return Padding(
      padding: EdgeInsets.only(left: 4 * scale),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (lucky) LuckyTag(scale: scale, md: md),
          if (lucky && hasType) SizedBox(width: 3 * scale),
          if (hasType) GroupTypeTag(groupType: groupType, scale: scale, md: md),
        ],
      ),
    );
  }
}

/// 品牌 logo（网页版那张原图 logo-jy.png，圆角 22%）
class JyLogo extends StatelessWidget {
  final double size;
  final double radius;
  final bool shadow;
  const JyLogo({super.key, this.size = 76, this.radius = 22, this.shadow = true});

  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          boxShadow: shadow ? C.shadow : null,
        ),
        clipBehavior: Clip.antiAlias,
        child: Image.asset('assets/logo-jy.png', fit: BoxFit.cover, filterQuality: FilterQuality.high),
      );
}

/// 统一底部弹层
Future<T?> showSheet<T>(BuildContext context, {required List<Widget> children, String? title}) {
  return showModalBottomSheet<T>(
    context: context,
    backgroundColor: C.surface,
    isScrollControlled: true,
    builder: (c) => SafeArea(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const SizedBox(height: 6),
          Container(width: 36, height: 4, decoration: BoxDecoration(color: const Color(0xFFE3E6EC), borderRadius: BorderRadius.circular(4))),
          if (title != null)
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
              child: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            ),
          Flexible(child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: children))),
          const SizedBox(height: 8),
        ],
      ),
    ),
  );
}

class SheetItem extends StatelessWidget {
  final String text;
  final IconData? icon;
  final Color? color;
  final VoidCallback? onTap;
  const SheetItem({super.key, required this.text, this.icon, this.color, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap == null
            ? null
            : () {
                Navigator.of(context).pop();
                onTap!();
              },
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 15),
          child: Row(
            children: [
              if (icon != null) ...[Icon(icon, size: 21, color: color ?? C.textMain), const SizedBox(width: 12)],
              Text(text, style: TextStyle(fontSize: 16, color: color ?? C.textMain)),
            ],
          ),
        ),
      ),
    );
  }
}

Future<bool> confirmDialog(BuildContext context, String title, {String? body, String ok = '确定', Color? okColor}) async {
  final r = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      title: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
      content: body == null ? null : Text(body, style: const TextStyle(fontSize: 14.5, color: C.textSub)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('取消', style: TextStyle(color: C.textSub))),
        TextButton(onPressed: () => Navigator.pop(c, true), child: Text(ok, style: TextStyle(color: okColor ?? C.danger))),
      ],
    ),
  );
  return r == true;
}

Future<String?> promptDialog(BuildContext context, String title, {String hint = '', bool obscure = false, int maxLines = 1}) async {
  final ctl = TextEditingController();
  final r = await showDialog<String>(
    context: context,
    builder: (c) => AlertDialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      title: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600)),
      content: TextField(
        controller: ctl,
        autofocus: true,
        obscureText: obscure,
        maxLines: maxLines,
        decoration: InputDecoration(hintText: hint),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c), child: const Text('取消', style: TextStyle(color: C.textSub))),
        TextButton(onPressed: () => Navigator.pop(c, ctl.text.trim()), child: const Text('确定', style: TextStyle(color: C.primary))),
      ],
    ),
  );
  return r;
}

/// 页面骨架：白底 + 返回栏
class PageScaffold extends StatelessWidget {
  final String title;
  final Widget child;
  final List<Widget> actions;
  final Color? bg;
  final PreferredSizeWidget? bottom;
  const PageScaffold({super.key, required this.title, required this.child, this.actions = const [], this.bg, this.bottom});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bg ?? C.bgApp,
      appBar: AppBar(
        title: Text(title),
        actions: actions,
        bottom: bottom,
        leading: Navigator.of(context).canPop()
            ? IconButton(
                icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 20),
                onPressed: () => Navigator.of(context).pop(),
              )
            : null,
      ),
      body: child,
    );
  }
}

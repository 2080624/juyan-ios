/// 本地通知（退到后台后用系统通知提醒）
library;

import 'package:flutter/foundation.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'notifier.dart';

class LocalSystemNotifier implements SystemNotifier {
  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  bool _ready = false;

  /// 点击通知的回调（传回会话 id）
  void Function(String convId)? onTap;

  Future<void> init() async {
    try {
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      const ios = DarwinInitializationSettings(
        requestAlertPermission: true,
        requestBadgePermission: true,
        requestSoundPermission: true,
      );
      await _plugin.initialize(
        settings: const InitializationSettings(android: android, iOS: ios),
        onDidReceiveNotificationResponse: (resp) {
          final p = resp.payload;
          if (p != null && p.isNotEmpty) onTap?.call(p);
        },
      );
      try {
        await _plugin
            .resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()
            ?.requestPermissions(alert: true, badge: true, sound: true);
      } catch (_) {}
      _ready = true;
    } catch (e) {
      debugPrint('notif init failed: $e');
      _ready = false;
    }
  }

  @override
  Future<void> show({required String title, required String body, String convId = ''}) async {
    if (!_ready) return;
    const ios = DarwinNotificationDetails(presentAlert: true, presentSound: true, presentBadge: true);
    const android = AndroidNotificationDetails(
      'juyan_message',
      '新消息',
      channelDescription: '聚言商聊的新消息提醒',
      importance: Importance.high,
      priority: Priority.high,
    );
    try {
      await _plugin.show(
        id: DateTime.now().millisecondsSinceEpoch ~/ 1000 % 100000,
        title: title,
        body: body,
        notificationDetails: const NotificationDetails(android: android, iOS: ios),
        payload: convId,
      );
    } catch (_) {}
  }

  /// 清掉全部通知（回到前台时）
  Future<void> clearAll() async {
    if (!_ready) return;
    try {
      await _plugin.cancelAll();
    } catch (_) {}
  }
}

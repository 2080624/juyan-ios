/// 设置相关
library;

import 'package:flutter/material.dart';

import '../core/prefs.dart';
import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../widgets/kit.dart';
import 'misc.dart';
import 'packet.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) => PageScaffold(
        title: '设置',
        child: ListView(
          children: [
            CellGroup(
              children: [
                Cell(
                  leading: const Icon(Icons.person_outline_rounded, color: C.textSub, size: 21),
                  title: '账号与安全',
                  onTap: () => Nav.push(const SettingsAccountPage()),
                ),
                Cell(
                  leading: const Icon(Icons.lock_outline_rounded, color: C.textSub, size: 21),
                  title: '支付密码',
                  hint: st.profile?.hasPayPwd == true ? '已设置' : '未设置',
                  onTap: () => Nav.push(const PayPwdPage()),
                ),
                Cell(
                  leading: const Icon(Icons.verified_user_outlined, color: C.textSub, size: 21),
                  title: '实名认证',
                  hint: st.profile?.real == true ? '已认证' : '未认证',
                  onTap: () => Nav.push(const SettingsRealnamePage()),
                ),
              ],
            ),
            CellGroup(
              children: [
                Cell(
                  leading: const Icon(Icons.notifications_none_rounded, color: C.textSub, size: 21),
                  title: '消息通知',
                  onTap: () => Nav.push(const SettingsNotifyPage()),
                ),
                Cell(
                  leading: const Icon(Icons.chat_outlined, color: C.textSub, size: 21),
                  title: '聊天设置',
                  onTap: () => Nav.push(const SettingsChatPage()),
                ),
                Cell(
                  leading: const Icon(Icons.shield_outlined, color: C.textSub, size: 21),
                  title: '隐私',
                  onTap: () => Nav.push(const SettingsPrivacyPage()),
                ),
                Cell(
                  leading: const Icon(Icons.cleaning_services_outlined, color: C.textSub, size: 21),
                  title: '存储空间',
                  onTap: () => Nav.push(const SettingsStoragePage()),
                ),
              ],
            ),
            CellGroup(
              children: [
                Cell(
                  leading: const Icon(Icons.block_rounded, color: C.textSub, size: 21),
                  title: '黑名单',
                  onTap: () => Nav.push(const BlacklistPage()),
                ),
                Cell(
                  leading: const Icon(Icons.reply_all_rounded, color: C.textSub, size: 21),
                  title: '自动回复',
                  hint: Prefs.flag('auto_reply', def: false) ? '已开启' : '未开启',
                  onTap: () => Nav.push(const AutoReplyPage()),
                ),
                Cell(
                  leading: const Icon(Icons.manage_accounts_outlined, color: C.textSub, size: 21),
                  title: '好友批量管理',
                  onTap: () => Nav.push(const ManageFriendsPage()),
                ),
                Cell(
                  leading: const Icon(Icons.groups_outlined, color: C.textSub, size: 21),
                  title: '群聊批量管理',
                  onTap: () => Nav.push(const ManageGroupsPage()),
                ),
              ],
            ),
            CellGroup(
              children: [
                Cell(
                  leading: const Icon(Icons.swap_horiz_rounded, color: C.textSub, size: 21),
                  title: '切换账号',
                  onTap: () => Nav.push(const SwitchAccountPage()),
                ),
                Cell(
                  leading: const Icon(Icons.info_outline_rounded, color: C.textSub, size: 21),
                  title: '关于聚言商聊',
                  onTap: () => Nav.push(const SettingsAboutPage()),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: PrimaryButton(
                text: '退出登录',
                gradient: const LinearGradient(colors: [C.danger, Color(0xFFF07070)]),
                onTap: () async {
                  if (await confirmDialog(context, '确定退出登录？')) {
                    await st.signOut();
                  }
                },
              ),
            ),
            const SizedBox(height: 14),
            Center(
              child: TextButton(
                onPressed: () => Nav.push(const SettingsCancelPage()),
                child: const Text('注销账号', style: TextStyle(color: C.textMute, fontSize: 13)),
              ),
            ),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}

/* ------------------------------ 账号与安全 ----------------------------- */

class SettingsAccountPage extends StatelessWidget {
  const SettingsAccountPage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '账号与安全',
      child: ListView(
        children: [
          CellGroup(
            children: [
              Cell(title: '昵称', hint: st.profile?.nickname ?? '', chevron: false),
              Cell(title: '账号 ID', hint: st.profile?.showId ?? '', chevron: false),
              Cell(title: '注册时间', hint: (st.profile?.created ?? '').split('T').first, chevron: false, onTap: null),
            ],
          ),
          CellGroup(
            children: [
              Cell(
                title: '修改密码',
                onTap: () async {
                  final a = await promptDialog(context, '原密码', obscure: true);
                  if (a == null) return;
                  final b = await promptDialog(context, '新密码（至少 6 位）', obscure: true);
                  if (b == null || b.length < 6) return;
                  try {
                    await Api.I.updateUser(st.user!.id, {'oldPassword': a, 'password': b, 'passwordConfirm': b});
                    st.say('密码已修改');
                  } catch (_) {
                    st.say('修改失败，检查原密码');
                  }
                },
              ),
            ],
          ),
          CellGroup(
            children: [
              Cell(
                title: '退出登录',
                titleColor: C.danger,
                chevron: false,
                onTap: () async {
                  if (await confirmDialog(context, '确定退出登录？')) await st.signOut();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/* ------------------------------- 消息通知 ------------------------------ */

class SettingsNotifyPage extends StatefulWidget {
  const SettingsNotifyPage({super.key});
  @override
  State<SettingsNotifyPage> createState() => _SettingsNotifyPageState();
}

class _SettingsNotifyPageState extends State<SettingsNotifyPage> {
  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '消息通知',
      child: ListView(
        children: [
          CellGroup(
            children: [
              SwitchCell(
                title: '接收新消息通知',
                value: Prefs.notifyMsg,
                onChanged: (v) async {
                  await Prefs.setFlag('notify_msg', v);
                  setState(() {});
                },
              ),
              SwitchCell(
                title: '声音',
                value: Prefs.notifySound,
                onChanged: (v) async {
                  await Prefs.setFlag('notify_sound', v);
                  setState(() {});
                },
              ),
              SwitchCell(
                title: '震动',
                value: Prefs.notifyVibrate,
                onChanged: (v) async {
                  await Prefs.setFlag('notify_vibrate', v);
                  setState(() {});
                },
              ),
              SwitchCell(
                title: '群消息提醒',
                subtitle: '关闭后群消息不再提醒，@ 你的除外',
                value: Prefs.notifyGroup,
                onChanged: (v) async {
                  await Prefs.setFlag('notify_group', v);
                  setState(() {});
                },
              ),
              SwitchCell(
                title: '朋友圈提醒',
                value: Prefs.notifyMoment,
                onChanged: (v) async {
                  await Prefs.setFlag('notify_moment', v);
                  setState(() {});
                },
              ),
            ],
          ),
          const Padding(
            padding: EdgeInsets.all(20),
            child: Text(
              '说明：App 在前台时用顶部横幅提醒；退到后台后，iOS 需要开发者证书才能走系统推送通道，当前版本在刚退到后台的一小段时间内仍会提醒。',
              style: TextStyle(fontSize: 12, color: C.textMute, height: 1.6),
            ),
          ),
        ],
      ),
    );
  }
}

/* -------------------------------- 聊天设置 ----------------------------- */

class SettingsChatPage extends StatefulWidget {
  const SettingsChatPage({super.key});
  @override
  State<SettingsChatPage> createState() => _SettingsChatPageState();
}

class _SettingsChatPageState extends State<SettingsChatPage> {
  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '聊天设置',
      child: ListView(
        children: [
          CellGroup(
            children: [
              SwitchCell(
                title: '回车发送消息',
                subtitle: '关闭后回车换行，用发送按钮发送',
                value: Prefs.enterToSend,
                onChanged: (v) async {
                  await Prefs.setFlag('chat_enter', v);
                  setState(() {});
                },
              ),
              SwitchCell(
                title: '显示「正在输入」',
                value: Prefs.typingOn,
                onChanged: (v) async {
                  await Prefs.setFlag('chat_typing', v);
                  setState(() {});
                },
              ),
              SwitchCell(
                title: '图片自动加载',
                subtitle: '关闭后点一下才加载图片，省流量',
                value: Prefs.autoImg,
                onChanged: (v) async {
                  await Prefs.setFlag('chat_autoimg', v);
                  setState(() {});
                },
              ),
              SwitchCell(
                title: '列表显示消息内容',
                value: Prefs.showPreview,
                onChanged: (v) async {
                  await Prefs.setFlag('chat_preview', v);
                  setState(() {});
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/* -------------------------------- 隐私 -------------------------------- */

class SettingsPrivacyPage extends StatefulWidget {
  const SettingsPrivacyPage({super.key});
  @override
  State<SettingsPrivacyPage> createState() => _SettingsPrivacyPageState();
}

class _SettingsPrivacyPageState extends State<SettingsPrivacyPage> {
  Map<String, dynamic> prefs = {};
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final r = await Api.I.prefsOf(AppState.I.user!.id);
      if (mounted) setState(() => prefs = r);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  bool _f(String k, bool def) {
    final v = prefs[k];
    if (v == null) return def;
    return v == true || v == 'true';
  }

  Future<void> _set(String k, bool v) async {
    setState(() => prefs[k] = v);
    await Api.I.prefsSet({k: v}).catchError((_) {});
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '隐私',
      child: loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : ListView(
              children: [
                CellGroup(
                  children: [
                    SwitchCell(title: '加我为好友时需要验证', value: _f('add_friend_verify', true), onChanged: (v) => _set('add_friend_verify', v)),
                    SwitchCell(title: '允许别人通过 ID 搜到我', value: _f('searchable', true), onChanged: (v) => _set('searchable', v)),
                    SwitchCell(title: '允许陌生人看我的动态', value: _f('stranger_moment', false), onChanged: (v) => _set('stranger_moment', v)),
                    SwitchCell(title: '允许好友评论我的动态', value: _f('friend_comment', true), onChanged: (v) => _set('friend_comment', v)),
                  ],
                ),
                CellGroup(
                  children: [
                    SwitchCell(
                      title: '对好友隐藏在线状态',
                      subtitle: '开启后好友看不到你的绿点和最后上线时间',
                      value: st.profile?.hideOnline ?? false,
                      onChanged: (v) async {
                        await Api.I.setOnlinePref(v).catchError((_) {});
                        await st.refreshProfile();
                      },
                    ),
                  ],
                ),
                CellGroup(
                  header: '加群方式',
                  children: [
                    ...[
                      ('free', '自动同意'),
                      ('verify', '需要群主审核'),
                      ('refuse', '自动拒绝'),
                    ].map((t) => Cell(
                          title: t.$2,
                          chevron: false,
                          trailing: prefs['join_group'] == t.$1 ? const Icon(Icons.check_circle_rounded, color: C.primary, size: 21) : null,
                          onTap: () => _set('join_group', true).then((_) => setState(() => prefs['join_group'] = t.$1)),
                        )),
                  ],
                ),
              ],
            ),
    );
  }
}

/* ------------------------------- 存储空间 ------------------------------ */

class SettingsStoragePage extends StatefulWidget {
  const SettingsStoragePage({super.key});
  @override
  State<SettingsStoragePage> createState() => _SettingsStoragePageState();
}

class _SettingsStoragePageState extends State<SettingsStoragePage> {
  String mode = 'off';

  @override
  void initState() {
    super.initState();
    mode = Prefs.autoClean;
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '存储空间',
      child: ListView(
        children: [
          CellGroup(
            header: '自动清理聊天缓存',
            footer: '只清理聊天图片、表情等缓存文件，不会删除聊天记录和账号信息',
            children: [
              ...[('off', '不自动清理'), ('15', '超过 15 天'), ('30', '超过 30 天')].map((t) => Cell(
                    title: t.$2,
                    chevron: false,
                    trailing: mode == t.$1 ? const Icon(Icons.check_circle_rounded, color: C.primary, size: 21) : null,
                    onTap: () async {
                      await Prefs.setStr('auto_clean', t.$1);
                      setState(() => mode = t.$1);
                      AppState.I.say('已设置');
                    },
                  )),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: PrimaryButton(
              text: '立即清理缓存',
              onTap: () async {
                AppState.I.say('缓存已清理');
              },
            ),
          ),
        ],
      ),
    );
  }
}

/* -------------------------------- 实名 -------------------------------- */

class SettingsRealnamePage extends StatefulWidget {
  const SettingsRealnamePage({super.key});
  @override
  State<SettingsRealnamePage> createState() => _SettingsRealnamePageState();
}

class _SettingsRealnamePageState extends State<SettingsRealnamePage> {
  final name = TextEditingController();
  final idNo = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    if (st.profile?.real == true) {
      return const PageScaffold(
        title: '实名认证',
        child: Empty(text: '已完成实名认证', icon: Icons.verified_rounded),
      );
    }
    return PageScaffold(
      title: '实名认证',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('实名信息仅用于身份核验，不会对外展示', style: TextStyle(fontSize: 12.5, color: C.textSub)),
          const SizedBox(height: 16),
          TextField(controller: name, decoration: const InputDecoration(hintText: '真实姓名')),
          const SizedBox(height: 12),
          TextField(controller: idNo, decoration: const InputDecoration(hintText: '身份证号')),
          const SizedBox(height: 22),
          PrimaryButton(
            text: '提交认证',
            loading: busy,
            onTap: () async {
              if (name.text.trim().isEmpty || idNo.text.trim().length < 15) {
                st.say('信息填完整');
                return;
              }
              setState(() => busy = true);
              try {
                await Api.I.realName(name.text.trim(), idNo.text.trim());
                await st.refreshProfile();
                st.say('认证成功');
              } catch (_) {
                st.say('认证失败，信息可能有误');
              }
              setState(() => busy = false);
            },
          ),
        ],
      ),
    );
  }
}

/* -------------------------------- 注销 -------------------------------- */

class SettingsCancelPage extends StatefulWidget {
  const SettingsCancelPage({super.key});
  @override
  State<SettingsCancelPage> createState() => _SettingsCancelPageState();
}

class _SettingsCancelPageState extends State<SettingsCancelPage> {
  final pwd = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '注销账号',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Icon(Icons.warning_amber_rounded, color: C.danger, size: 48),
          const SizedBox(height: 12),
          const Text('注销后账号无法恢复，聊天记录、好友、余额都会清空，请谨慎操作。',
              textAlign: TextAlign.center, style: TextStyle(fontSize: 13.5, color: C.textSub, height: 1.6)),
          const SizedBox(height: 22),
          TextField(controller: pwd, obscureText: true, decoration: const InputDecoration(hintText: '输入登录密码确认')),
          const SizedBox(height: 18),
          PrimaryButton(
            text: '确认注销',
            gradient: const LinearGradient(colors: [C.danger, Color(0xFFF07070)]),
            loading: busy,
            onTap: () async {
              if (pwd.text.isEmpty) return;
              setState(() => busy = true);
              try {
                await Api.I.cancelAccount(pwd.text);
                await st.signOut();
              } catch (_) {
                st.say('密码不正确');
              }
              setState(() => busy = false);
            },
          ),
        ],
      ),
    );
  }
}

/* -------------------------------- 关于 -------------------------------- */

class SettingsAboutPage extends StatelessWidget {
  const SettingsAboutPage({super.key});
  @override
  Widget build(BuildContext context) => PageScaffold(
        title: '关于',
        child: ListView(
          children: [
            const SizedBox(height: 40),
            Center(
              child: Container(
                width: 78,
                height: 78,
                decoration: BoxDecoration(gradient: C.brandGradient, borderRadius: BorderRadius.circular(22)),
                child: const Icon(Icons.chat_bubble_rounded, color: Colors.white, size: 38),
              ),
            ),
            const SizedBox(height: 16),
            const Center(child: Text('聚言商聊', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w700))),
            const SizedBox(height: 6),
            const Center(child: Text('v2.0 · Flutter 原生版', style: TextStyle(fontSize: 13, color: C.textSub))),
            const SizedBox(height: 30),
            CellGroup(
              children: [
                Cell(title: '用户协议', onTap: () => _doc(context, '用户协议', _agreement)),
                Cell(title: '隐私政策', onTap: () => _doc(context, '隐私政策', _privacy)),
              ],
            ),
          ],
        ),
      );

  void _doc(BuildContext context, String title, String body) {
    Nav.push(PageScaffold(
      title: title,
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Text(body, style: const TextStyle(fontSize: 14, height: 1.8)),
        ],
      ),
    ));
  }

  static const _agreement = '''
欢迎使用聚言商聊。

1. 你在注册时应提供真实、合法的信息，并对账号下的一切行为负责。
2. 你在使用本服务时，应遵守法律法规，不得发布违法、侵权、骚扰或误导他人的内容。
3. 我们有权对违反上述约定的账号采取限制功能、封禁等措施。
4. 本服务的部分功能需要消耗积分，积分获取与消耗规则以站内说明为准。
5. 我们会持续优化服务，功能与规则如有调整会在站内公告。
''';

  static const _privacy = '''
我们非常重视你的隐私。

1. 我们只收集提供服务所必需的信息，例如昵称、账号 ID。
2. 你的密码经过加密存储，我们无法查看明文。
3. 实名信息仅用于身份核验，不会对外展示。
4. 未经你的同意，我们不会向第三方提供你的个人信息，法律法规另有规定除外。
5. 你可以随时在设置中修改资料、退出登录或申请注销账号。
''';
}

/* -------------------------------- 黑名单 ------------------------------- */

class BlacklistPage extends StatefulWidget {
  const BlacklistPage({super.key});
  @override
  State<BlacklistPage> createState() => _BlacklistPageState();
}

class _BlacklistPageState extends State<BlacklistPage> {
  List<String> list = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final b = await Api.I.blocks();
      if (mounted) setState(() => list = b.map((e) => e.target).toList());
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '黑名单',
      child: loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : list.isEmpty
              ? const Empty(text: '黑名单是空的', icon: Icons.block_rounded)
              : ListView(
                  children: list
                      .map((uid) => Cell(
                            leading: Avatar(url: st.avatarOf(uid), name: st.displayOf(uid), size: 42),
                            title: st.displayOf(uid),
                            chevron: false,
                            trailing: TextButton(
                              onPressed: () async {
                                await Api.I.blockSet(target: uid, mode: 'remove').catchError((_) {});
                                _load();
                              },
                              child: const Text('移出', style: TextStyle(color: C.primary)),
                            ),
                          ))
                      .toList(),
                ),
    );
  }
}

/* ------------------------------- 自动回复 ------------------------------ */

class AutoReplyPage extends StatefulWidget {
  const AutoReplyPage({super.key});
  @override
  State<AutoReplyPage> createState() => _AutoReplyPageState();
}

class _AutoReplyPageState extends State<AutoReplyPage> {
  final ctl = TextEditingController(text: AppState.I.profile?.autoReply ?? '');
  bool on = false;

  @override
  void initState() {
    super.initState();
    on = AppState.I.profile?.autoReplyOn ?? false;
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '自动回复',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SwitchCell(
            title: '开启自动回复',
            subtitle: '别人给你发消息时自动回一句',
            value: on,
            onChanged: (v) async {
              setState(() => on = v);
              await Api.I.autoReplySet(on: v).catchError((_) {});
            },
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
            child: TextField(controller: ctl, maxLines: 4, decoration: const InputDecoration(hintText: '例如：我现在有点忙，稍后回复你', filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none)),
          ),
          const SizedBox(height: 16),
          PrimaryButton(
            text: '保存',
            onTap: () async {
              await Api.I.autoReplySet(text: ctl.text.trim(), on: on).catchError((_) {});
              await AppState.I.refreshProfile();
              AppState.I.say('已保存');
            },
          ),
        ],
      ),
    );
  }
}

/* ----------------------------- 好友批量管理 ---------------------------- */

class ManageFriendsPage extends StatefulWidget {
  const ManageFriendsPage({super.key});
  @override
  State<ManageFriendsPage> createState() => _ManageFriendsPageState();
}

class _ManageFriendsPageState extends State<ManageFriendsPage> {
  final picked = <String>{};

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '好友管理',
      actions: [
        TextButton(
          onPressed: picked.isEmpty
              ? null
              : () async {
                  if (!await confirmDialog(context, '删除选中的 ${picked.length} 位好友？')) return;
                  await Api.I.bulkUnfriend(picked.toList()).catchError((_) {});
                  picked.clear();
                  await st.refreshAll();
                  if (mounted) setState(() {});
                  st.say('已删除');
                },
          child: Text('删除(${picked.length})', style: TextStyle(color: picked.isEmpty ? C.textMute : C.danger)),
        ),
      ],
      child: ListView(
        children: st.friends
            .map((f) => Cell(
                  leading: Avatar(url: st.avatarOf(f.friend), name: st.displayOf(f.friend), size: 42),
                  title: st.displayOf(f.friend),
                  chevron: false,
                  trailing: Icon(
                    picked.contains(f.friend) ? Icons.check_circle_rounded : Icons.circle_outlined,
                    color: picked.contains(f.friend) ? C.primary : C.textMute,
                    size: 22,
                  ),
                  onTap: () => setState(() {
                    picked.contains(f.friend) ? picked.remove(f.friend) : picked.add(f.friend);
                  }),
                ))
            .toList(),
      ),
    );
  }
}

/* ----------------------------- 群聊批量管理 ---------------------------- */

class ManageGroupsPage extends StatefulWidget {
  const ManageGroupsPage({super.key});
  @override
  State<ManageGroupsPage> createState() => _ManageGroupsPageState();
}

class _ManageGroupsPageState extends State<ManageGroupsPage> {
  final picked = <String>{};

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final groups = st.convos.where((c) => c.isGroup).toList();
    return PageScaffold(
      title: '群聊管理',
      actions: [
        TextButton(
          onPressed: picked.isEmpty
              ? null
              : () async {
                  if (!await confirmDialog(context, '退出选中的 ${picked.length} 个群？')) return;
                  await Api.I.bulkQuit(picked.toList()).catchError((_) {});
                  picked.clear();
                  await st.refreshAll();
                  if (mounted) setState(() {});
                  st.say('已退出');
                },
          child: Text('退出(${picked.length})', style: TextStyle(color: picked.isEmpty ? C.textMute : C.danger)),
        ),
      ],
      child: groups.isEmpty
          ? const Empty(text: '还没有加入任何群聊', icon: Icons.groups_outlined)
          : ListView(
              children: groups
                  .map((c) => Cell(
                        leading: Avatar(url: st.avatarUrlOf(c), name: c.title, size: 42, group: true),
                        title: c.title,
                        subtitle: '${c.members.length} 人',
                        chevron: false,
                        trailing: c.owner == st.user?.id
                            ? const Text('我的群', style: TextStyle(fontSize: 12, color: C.textMute))
                            : Icon(
                                picked.contains(c.id) ? Icons.check_circle_rounded : Icons.circle_outlined,
                                color: picked.contains(c.id) ? C.primary : C.textMute,
                                size: 22,
                              ),
                        onTap: c.owner == st.user?.id
                            ? null
                            : () => setState(() {
                                  picked.contains(c.id) ? picked.remove(c.id) : picked.add(c.id);
                                }),
                      ))
                  .toList(),
            ),
    );
  }
}

/* ------------------------------- 语言（占位） --------------------------- */

class SettingsLanguagePage extends StatelessWidget {
  const SettingsLanguagePage({super.key});
  @override
  Widget build(BuildContext context) => const PageScaffold(
        title: '语言',
        child: Empty(text: '当前为简体中文', icon: Icons.language_rounded),
      );
}

class SettingsPayPage extends StatelessWidget {
  const SettingsPayPage({super.key});
  @override
  Widget build(BuildContext context) => const PayPwdPage();
}

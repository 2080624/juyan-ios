/// 群聊：群设置 / 成员 / 公告 / 升级 / 建群 / 历史 / 群二维码
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../data/models.dart';
import '../widgets/kit.dart';
import 'chat.dart';
import 'friend.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

/* -------------------------------- 建群 -------------------------------- */

class GroupCreatePage extends StatefulWidget {
  const GroupCreatePage({super.key});
  @override
  State<GroupCreatePage> createState() => _GroupCreatePageState();
}

class _GroupCreatePageState extends State<GroupCreatePage> {
  final picked = <String>{};
  final titleCtl = TextEditingController();
  String type = 'normal';
  int step = 0;
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: step == 0 ? '选择成员' : '创建群聊',
      actions: [
        TextButton(
          onPressed: picked.isEmpty || busy
              ? null
              : () async {
                  if (step == 0) {
                    setState(() => step = 1);
                    return;
                  }
                  if (titleCtl.text.trim().isEmpty) {
                    st.say('给群起个名字');
                    return;
                  }
                  setState(() => busy = true);
                  try {
                    final c = await Api.I.createConversation({
                      'kind': 'group',
                      'title': titleCtl.text.trim(),
                      'members': [st.user!.id, ...picked],
                      'owner': st.user!.id,
                      'group_type': type,
                      'group_no': _randNo(),
                      'last_text': '',
                      'last_time': DateTime.now().toUtc().toIso8601String(),
                    });
                    await st.refreshAll();
                    Nav.pop();
                    Nav.push(ChatPage(convId: c.id));
                  } catch (_) {
                    st.say('建群失败');
                  }
                  setState(() => busy = false);
                },
          child: Text(step == 0 ? '下一步(${picked.length})' : '创建', style: TextStyle(color: picked.isEmpty ? C.textMute : C.primary)),
        ),
      ],
      child: step == 0
          ? ListView(
              children: st.friends
                  .map((f) => Cell(
                        leading: Avatar(url: st.avatarOf(f.friend), name: st.displayOf(f.friend), size: 42),
                        titleWidget: NameRow(name: st.displayOf(f.friend), red: st.redOf(f.friend), vip: st.vipOf(f.friend)),
                        chevron: false,
                        trailing: Icon(
                          picked.contains(f.friend) ? LucideIcons.circleCheck : LucideIcons.circle,
                          color: picked.contains(f.friend) ? C.primary : C.textMute,
                          size: 22,
                        ),
                        onTap: () => setState(() {
                          picked.contains(f.friend) ? picked.remove(f.friend) : picked.add(f.friend);
                        }),
                      ))
                  .toList(),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                TextField(controller: titleCtl, decoration: const InputDecoration(hintText: '群名称')),
                const SizedBox(height: 18),
                const Text('群类型', style: TextStyle(fontSize: 13, color: C.textSub)),
                const SizedBox(height: 8),
                ...[
                  ('normal', '普通群', '最多 200 人'),
                  ('platinum', '超级群', '最多 2000 人 · 需 VIP1'),
                  ('diamond', '至尊群', '最多 5000 人 · 需 VIP3'),
                ].map((t) => Container(
                      margin: const EdgeInsets.only(bottom: 10),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: type == t.$1 ? C.primary : C.divider, width: type == t.$1 ? 1.5 : 1),
                      ),
                      child: Cell(
                        title: t.$2,
                        subtitle: t.$3,
                        chevron: false,
                        trailing: type == t.$1 ? const Icon(LucideIcons.circleCheck, color: C.primary, size: 22) : null,
                        onTap: () => setState(() => type = t.$1),
                      ),
                    )),
                const SizedBox(height: 10),
                Text('已选 ${picked.length} 位成员', style: const TextStyle(fontSize: 12.5, color: C.textSub)),
              ],
            ),
    );
  }

  String _randNo() {
    final n = DateTime.now().microsecondsSinceEpoch;
    return '${(n % 900000000) + 100000000}';
  }
}

/* ------------------------------- 群设置 ------------------------------- */

class GroupInfoPage extends StatefulWidget {
  final String convId;
  const GroupInfoPage({super.key, required this.convId});
  @override
  State<GroupInfoPage> createState() => _GroupInfoPageState();
}

class _GroupInfoPageState extends State<GroupInfoPage> {
  Conversation? conv;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final c = await Api.I.conversationById(widget.convId);
      if (mounted) setState(() => conv = c);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final c = conv;
    if (c == null) {
      return const PageScaffold(title: '群聊设置', child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
    }
    final isOwner = c.owner == st.user?.id;
    final isAdmin = c.admins.contains(st.user?.id);

    return PageScaffold(
      title: '群聊设置',
      child: ListView(
        children: [
          // 群名片（照网页版：头像居中 → 群名 → 群号 → 人数）
          Container(
            color: Colors.white,
            padding: const EdgeInsets.only(top: 20, bottom: 16),
            child: Column(
              children: [
                GestureDetector(
                  onTap: isOwner
                      ? () async {
                          final f = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 800);
                          if (f == null) return;
                          try {
                            await Api.I.upload('conversations', c.id, 'avatar', File(f.path));
                            await _load();
                            await st.refreshAll();
                            st.say('群头像已更新');
                          } catch (_) {
                            st.say('上传失败');
                          }
                        }
                      : () => st.say('只有群主能换群头像'),
                  child: Avatar(url: convAvatarUrl(c), name: c.title, size: 72, radius: 18, group: true),
                ),
                const SizedBox(height: 12),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Flexible(
                        child: Text(
                          c.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w600,
                            color: groupNameColor(c.groupType) ?? C.textMain,
                          ),
                        ),
                      ),
                      GroupTags(lucky: st.isGroupLucky(c.groupNo), groupType: c.groupType, scale: 0.9, md: true),
                    ],
                  ),
                ),
                const SizedBox(height: 6),
                GestureDetector(
                  onTap: () async {
                    if (c.groupNo.isEmpty) return;
                    await Clipboard.setData(ClipboardData(text: c.groupNo));
                    st.say('群号已复制');
                  },
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text('群号 ', style: TextStyle(fontSize: 13, color: C.textSub)),
                      Text(
                        c.groupNo.isEmpty ? '生成中' : c.groupNo,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: st.isGroupLucky(c.groupNo) ? FontWeight.w700 : FontWeight.w400,
                          color: st.isGroupLucky(c.groupNo) ? const Color(0xFFC9922E) : C.textSub,
                        ),
                      ),
                      if (st.isGroupLucky(c.groupNo)) ...[
                        const SizedBox(width: 4),
                        const LuckyTag(scale: 0.85),
                      ],
                    ],
                  ),
                ),
                const SizedBox(height: 4),
                GestureDetector(
                  onTap: () => Nav.push(GroupMembersPage(convId: c.id)),
                  child: Text('${c.members.length}/${c.capacity} 人', style: const TextStyle(fontSize: 13, color: C.textMute)),
                ),
              ],
            ),
          ),
          CellGroup(
            children: [
              Cell(
                leading: Avatar(url: convAvatarUrl(c), name: c.title, size: 46, group: true),
                title: '群头像',
                onTap: isOwner
                    ? () async {
                        final f = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 800);
                        if (f == null) return;
                        try {
                          await Api.I.upload('conversations', c.id, 'avatar', File(f.path));
                          await _load();
                          await st.refreshAll();
                          st.say('群头像已更新');
                        } catch (_) {
                          st.say('上传失败');
                        }
                      }
                    : null,
              ),
              Cell(
                title: '群名称',
                hint: c.title,
                onTap: isOwner || isAdmin
                    ? () async {
                        final v = await promptDialog(context, '修改群名称', hint: c.title);
                        if (v == null || v.isEmpty) return;
                        await Api.I.groupUpdate(c.id, {'title': v}).catchError((_) {});
                        await _load();
                        await st.refreshAll();
                      }
                    : null,
              ),
              Cell(
                title: '群号',
                hint: c.groupNo,
                chevron: false,
                trailing: IconButton(
                  icon: const Icon(LucideIcons.copy, size: 17, color: C.textMute),
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: c.groupNo));
                    st.say('群号已复制');
                  },
                ),
              ),
              Cell(title: '群类型', hint: c.typeName, onTap: isOwner ? () => Nav.push(GroupUpgradePage(convId: c.id)) : null),
              Cell(title: '群公告', hint: c.notice.isEmpty ? '未设置' : '已设置', onTap: () => Nav.push(GroupNoticePage(convId: c.id))),
              Cell(title: '群成员', hint: '${c.members.length}/${c.capacity}', onTap: () => Nav.push(GroupMembersPage(convId: c.id))),
              Cell(title: '群二维码', onTap: () => Nav.push(GroupQrPage(convId: c.id))),
              Cell(title: '查找聊天记录', onTap: () => Nav.push(GroupHistoryPage(convId: c.id))),
            ],
          ),
          CellGroup(
            children: [
              Cell(title: '我在本群的昵称', hint: c.nicknames[st.user!.id] ?? '未设置', onTap: () async {
                final v = await promptDialog(context, '群内昵称', hint: '最多 12 个字');
                if (v == null) return;
                await Api.I.groupNickSet(c.id, v).catchError((_) {});
                await _load();
              }),
              Cell(title: '清空聊天记录', titleColor: C.danger, onTap: () async {
                if (await confirmDialog(context, '清空本群聊天记录？')) {
                  st.say('已清空');
                }
              }),
            ],
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: PrimaryButton(
              text: isOwner ? '解散群聊' : '退出群聊',
              gradient: const LinearGradient(colors: [C.danger, Color(0xFFF07070)]),
              onTap: () async {
                final ok = await confirmDialog(context, isOwner ? '确定解散这个群？' : '确定退出这个群？', body: isOwner ? '解散后聊天记录将被清空，不可恢复' : null);
                if (!ok) return;
                try {
                  if (isOwner) {
                    await Api.I.groupDismiss(c.id);
                  } else {
                    await Api.I.groupLeave(c.id);
                  }
                  await st.refreshAll();
                  Nav.pop();
                  st.say(isOwner ? '群已解散' : '已退出群聊');
                } catch (_) {
                  st.say('操作失败');
                }
              },
            ),
          ),
        ],
      ),
    );
  }
}

/* ------------------------------- 群成员 ------------------------------- */

class GroupMembersPage extends StatefulWidget {
  final String convId;
  const GroupMembersPage({super.key, required this.convId});
  @override
  State<GroupMembersPage> createState() => _GroupMembersPageState();
}

class _GroupMembersPageState extends State<GroupMembersPage> {
  Conversation? conv;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final c = await Api.I.conversationById(widget.convId);
      final got = await Api.I.profilesByIds(c.members);
      AppState.I.people.addAll(got);
      if (mounted) setState(() => conv = c);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final c = conv;
    if (c == null) return const PageScaffold(title: '群成员', child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
    final isOwner = c.owner == st.user?.id;
    final isAdmin = c.admins.contains(st.user?.id);

    final members = [...c.members];
    members.sort((a, b) {
      if (a == c.owner) return -1;
      if (b == c.owner) return 1;
      final aa = c.admins.contains(a), bb = c.admins.contains(b);
      if (aa != bb) return aa ? -1 : 1;
      return 0;
    });

    return PageScaffold(
      title: '群成员 (${c.members.length})',
      actions: [
        if (isOwner || isAdmin)
          IconButton(
            icon: const Icon(LucideIcons.userPlus, size: 21),
            onPressed: () => _invite(c),
          ),
      ],
      child: ListView(
        children: members.map((uid) {
          final p = st.personOf(uid);
          final name = st.displayOf(uid, fallback: p?.showId ?? uid);
          final online = st.onlineOf(uid);
          return Cell(
            leading: Stack(
              clipBehavior: Clip.none,
              children: [
                Avatar(url: p == null ? '' : profileAvatar(p), name: name, size: 44),
                if (online)
                  Positioned(
                    right: -2,
                    bottom: -2,
                    child: Container(width: 12, height: 12, decoration: BoxDecoration(color: C.green, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2))),
                  ),
              ],
            ),
            titleWidget: NameRow(name: name, red: st.redOf(uid), vip: st.vipOf(uid)),
            subtitle: uid == c.owner
                ? '群主'
                : c.admins.contains(uid)
                    ? '管理员'
                    : (c.muted.contains(uid) ? '已禁言' : ''),
            chevron: uid != st.user?.id,
            onTap: uid == st.user?.id || !(isOwner || isAdmin)
                ? (uid == st.user?.id ? null : () => Nav.push(UserProfilePage(userId: uid)))
                : () => _manage(c, uid, name, isOwner),
          );
        }).toList(),
      ),
    );
  }

  Future<void> _manage(Conversation c, String uid, String name, bool isOwner) async {
    await showSheet(context, title: name, children: [
      SheetItem(text: '发消息', icon: LucideIcons.messageSquare, onTap: () async {
        final cc = await AppState.I.startDirect(uid, name);
        Nav.push(ChatPage(convId: cc.id));
      }),
      SheetItem(text: '看资料', icon: LucideIcons.user, onTap: () => Nav.push(UserProfilePage(userId: uid))),
      if (isOwner)
        SheetItem(
          text: c.admins.contains(uid) ? '取消管理员' : '设为管理员',
          icon: LucideIcons.shieldCheck,
          onTap: () async {
            final list = [...c.admins];
            c.admins.contains(uid) ? list.remove(uid) : list.add(uid);
            await Api.I.groupUpdate(c.id, {'admins': _jsonArr(list)}).catchError((_) {});
            await _load();
          },
        ),
      SheetItem(
        text: c.muted.contains(uid) ? '解除禁言' : '禁言',
        icon: LucideIcons.volumeOff,
        onTap: () async {
          await Api.I.groupMute(c.id, uid, !c.muted.contains(uid)).catchError((_) {});
          await _load();
        },
      ),
      SheetItem(text: '移出群聊', icon: LucideIcons.circleMinus, color: C.danger, onTap: () async {
        await Api.I.groupKick(c.id, uid).catchError((_) {});
        await _load();
        await AppState.I.refreshAll();
      }),
    ]);
  }

  String _jsonArr(List<String> v) => '[${v.map((e) => '"$e"').join(',')}]';

  Future<void> _invite(Conversation c) async {
    final st = AppState.I;
    final candidates = st.friends.where((f) => !c.members.contains(f.friend)).toList();
    if (candidates.isEmpty) {
      st.say('好友都已经在群里了');
      return;
    }
    await showSheet(context, title: '邀请好友进群', children: [
      for (final f in candidates)
        SheetItem(
          text: st.displayOf(f.friend),
          icon: LucideIcons.userPlus,
          onTap: () async {
            await Api.I.inviteToGroup(c.id, c.title, st.user!.id, st.displayName, f.friend).catchError((_) {});
            st.say('邀请已发出');
          },
        ),
    ]);
  }
}

/* ------------------------------- 群公告 ------------------------------- */

class GroupNoticePage extends StatefulWidget {
  final String convId;
  const GroupNoticePage({super.key, required this.convId});
  @override
  State<GroupNoticePage> createState() => _GroupNoticePageState();
}

class _GroupNoticePageState extends State<GroupNoticePage> {
  final ctl = TextEditingController();
  Conversation? conv;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await Api.I.conversationById(widget.convId).catchError((_) => null);
    if (c != null && mounted) {
      setState(() {
        conv = c;
        ctl.text = c.notice;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final c = conv;
    return PageScaffold(
      title: '群公告',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
            child: TextField(controller: ctl, maxLines: 8, decoration: const InputDecoration(hintText: '发个公告，让群里所有人都看到')),
          ),
          const SizedBox(height: 16),
          PrimaryButton(
            text: '发布公告',
            loading: busy,
            onTap: () async {
              setState(() => busy = true);
              await Api.I.groupUpdate(widget.convId, {'notice': ctl.text.trim()}).catchError((_) {});
              setState(() => busy = false);
              st.say('公告已发布');
              Nav.pop();
            },
          ),
          if (c != null && c.notice.isNotEmpty) ...[
            const SizedBox(height: 14),
            PrimaryButton(
              text: c.noticePinned ? '取消置顶' : '置顶公告',
              gradient: const LinearGradient(colors: [Color(0xFFE5A13B), Color(0xFFF0BE72)]),
              onTap: () async {
                await Api.I.noticePin(widget.convId, !c.noticePinned).catchError((_) {});
                await _load();
                await st.refreshAll();
              },
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: () async {
                await Api.I.groupUpdate(widget.convId, {'notice': ''}).catchError((_) {});
                ctl.clear();
                await _load();
                st.say('公告已清空');
              },
              child: const Text('清空公告', style: TextStyle(color: C.danger)),
            ),
          ],
        ],
      ),
    );
  }
}

class NoticeViewPage extends StatelessWidget {
  final String convId;
  const NoticeViewPage({super.key, required this.convId});

  @override
  Widget build(BuildContext context) {
    final c = AppState.I.convos.where((x) => x.id == convId).toList();
    final text = c.isEmpty ? '' : c.first.notice;
    return PageScaffold(
      title: '群公告',
      actions: [
        TextButton(
          onPressed: () async {
            await Clipboard.setData(ClipboardData(text: text));
            AppState.I.say('已复制');
          },
          child: const Text('复制全文'),
        ),
      ],
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
            child: SelectableText(text.isEmpty ? '暂无公告' : text, style: const TextStyle(fontSize: 15, height: 1.7)),
          ),
        ],
      ),
    );
  }
}

/* ------------------------------- 群升级 ------------------------------- */

class GroupUpgradePage extends StatefulWidget {
  final String convId;
  const GroupUpgradePage({super.key, required this.convId});
  @override
  State<GroupUpgradePage> createState() => _GroupUpgradePageState();
}

class _GroupUpgradePageState extends State<GroupUpgradePage> {
  Conversation? conv;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final c = await Api.I.conversationById(widget.convId).catchError((_) => null);
    if (mounted) setState(() => conv = c);
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final cur = conv?.groupType ?? 'normal';
    const order = ['normal', 'platinum', 'diamond'];
    final ci = order.indexOf(cur);
    return PageScaffold(
      title: '群类型',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('群类型只能升级，不能降级', style: TextStyle(fontSize: 13, color: C.textSub)),
          const SizedBox(height: 12),
          ...[
            ('normal', '普通群', '最多 200 人', '免费'),
            ('platinum', '超级群', '最多 2000 人', '需 VIP1'),
            ('diamond', '至尊群', '最多 5000 人', '需 VIP3'),
          ].map((t) {
            final target = t.$1;
            final ti = order.indexOf(target);
            final isCur = target == cur;
            final canUp = ti > ci;
            return Container(
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: isCur ? C.primary : C.divider, width: isCur ? 1.5 : 1),
              ),
              child: Column(
                children: [
                  Cell(
                    title: t.$2,
                    subtitle: '${t.$3} · ${t.$4}',
                    chevron: false,
                    trailing: isCur
                        ? const Text('当前', style: TextStyle(color: C.primary, fontSize: 13))
                        : canUp
                            ? SizedBox(
                                height: 32,
                                child: ElevatedButton(
                                  onPressed: () async {
                                    try {
                                      await Api.I.groupUpgrade(widget.convId, target);
                                      await _load();
                                      await st.refreshAll();
                                      st.say('升级成功');
                                    } catch (e) {
                                      st.say(e is ApiException ? (e.message.isEmpty ? '升级失败，检查会员等级' : e.message) : '升级失败');
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(backgroundColor: C.primary, foregroundColor: Colors.white, elevation: 0, padding: const EdgeInsets.symmetric(horizontal: 14)),
                                  child: const Text('升级', style: TextStyle(fontSize: 13)),
                                ),
                              )
                            : null,
                  ),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}

/* ------------------------------ 群二维码 ------------------------------ */

class GroupQrPage extends StatelessWidget {
  final String convId;
  const GroupQrPage({super.key, required this.convId});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final list = st.convos.where((c) => c.id == convId).toList();
    final c = list.isEmpty ? null : list.first;
    return PageScaffold(
      title: '群二维码',
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Avatar(url: c == null ? '' : convAvatarUrl(c), name: c?.title ?? '', size: 62, radius: 16, group: true),
            const SizedBox(height: 12),
            Text(c?.title ?? '', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            Text('群号 ${c?.groupNo ?? ''}', style: const TextStyle(fontSize: 13, color: C.textSub)),
          ],
        ),
      ),
    );
  }
}

/* ------------------------------ 群聊天记录 ----------------------------- */

class GroupHistoryPage extends StatelessWidget {
  final String convId;
  const GroupHistoryPage({super.key, required this.convId});

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '查找聊天记录',
      child: SearchMsgList(convId: convId),
    );
  }
}

class SearchMsgList extends StatefulWidget {
  final String convId;
  const SearchMsgList({super.key, required this.convId});
  @override
  State<SearchMsgList> createState() => _SearchMsgListState();
}

class _SearchMsgListState extends State<SearchMsgList> {
  final ctl = TextEditingController();
  List<Message> found = [];

  Future<void> _run() async {
    final hits = await Api.I.msgSearch(ctl.text.trim()).catchError((_) => <MsgSearchHit>[]);
    setState(() {
      found = hits
          .where((h) => h.conv == widget.convId)
          .map((h) => Message(id: h.id, conversation: h.conv, sender: h.sender, kind: h.kind, text: h.text, created: h.created))
          .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: TextField(
            controller: ctl,
            textInputAction: TextInputAction.search,
            onSubmitted: (_) => _run(),
            decoration: InputDecoration(
              hintText: '搜索本群聊天记录',
              suffixIcon: IconButton(icon: const Icon(LucideIcons.search, size: 20), onPressed: _run),
            ),
          ),
        ),
        Expanded(
          child: found.isEmpty
              ? const Empty(text: '输入关键词搜聊天记录', icon: LucideIcons.history)
              : ListView(
                  children: found
                      .map((m) => Cell(
                            leading: const Icon(LucideIcons.messageSquare, size: 19, color: C.textSub),
                            title: m.text,
                            subtitle: '${st.displayOf(m.sender)} · ${fmtDateTime(m.created)}',
                            chevron: false,
                          ))
                      .toList(),
                ),
        ),
      ],
    );
  }
}

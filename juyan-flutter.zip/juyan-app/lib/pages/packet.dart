/// 钱包：转账 / 礼物 / 红包详情 / 账单 / 钱包首页
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../data/models.dart';
import '../widgets/kit.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

/* ------------------------------ 转账面板 ------------------------------ */

class TransferSheet extends StatefulWidget {
  final String convId;
  const TransferSheet({super.key, required this.convId});
  @override
  State<TransferSheet> createState() => _TransferSheetState();
}

class _TransferSheetState extends State<TransferSheet> {
  final amount = TextEditingController();
  final note = TextEditingController();
  final pwd = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final peer = _peerOf(widget.convId);
    return PageScaffold(
      title: '转账',
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: C.shadow),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('转给 ${peer.$2}', style: const TextStyle(fontSize: 13, color: C.textSub)),
                const SizedBox(height: 10),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text('¥', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w600)),
                    const SizedBox(width: 8),
                    Expanded(
                      child: TextField(
                        controller: amount,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9.]'))],
                        style: const TextStyle(fontSize: 34, fontWeight: FontWeight.w700),
                        decoration: const InputDecoration(
                          hintText: '0.00',
                          filled: false,
                          border: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          focusedBorder: InputBorder.none,
                        ),
                      ),
                    ),
                  ],
                ),
                const Divider(),
                TextField(controller: note, decoration: const InputDecoration(hintText: '转账说明（可不填）', filled: false, border: InputBorder.none, enabledBorder: InputBorder.none, focusedBorder: InputBorder.none)),
                const SizedBox(height: 4),
                Text('余额 ¥${st.profile?.coins ?? 0}', style: const TextStyle(fontSize: 12.5, color: C.textSub)),
              ],
            ),
          ),
          const SizedBox(height: 18),
          if (st.profile?.hasPayPwd == true)
            TextField(controller: pwd, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(hintText: '输入 6 位支付密码', counterText: '')),
          const SizedBox(height: 16),
          PrimaryButton(
            text: '确认转账',
            loading: busy,
            onTap: () async {
              final amt = double.tryParse(amount.text.trim()) ?? 0;
              if (amt <= 0) {
                st.say('填个金额');
                return;
              }
              if (st.profile?.hasPayPwd != true) {
                st.say('先去「我的-设置-支付密码」设置密码');
                return;
              }
              setState(() => busy = true);
              try {
                await Api.I.transfer(peer.$1, (amt * 100).round(), pwd.text.trim(), widget.convId, note: note.text.trim());
                await st.refreshProfile();
                await st.refreshAll();
                Nav.pop();
                st.say('转账已发出');
              } catch (e) {
                st.say(e is ApiException ? (e.message.isEmpty ? '转账失败' : e.message) : '转账失败');
              }
              setState(() => busy = false);
            },
          ),
        ],
      ),
    );
  }

  (String, String) _peerOf(String convId) {
    final st = AppState.I;
    final list = st.convos.where((c) => c.id == convId).toList();
    if (list.isEmpty) return ('', '对方');
    final c = list.first;
    if (c.isGroup) return ('', c.title);
    final uid = c.members.firstWhere((m) => m != st.user?.id, orElse: () => '');
    return (uid, st.displayOf(uid));
  }
}

/* ------------------------------ 礼物面板 ------------------------------ */

class GiftSheet extends StatefulWidget {
  final String convId;
  const GiftSheet({super.key, required this.convId});
  @override
  State<GiftSheet> createState() => _GiftSheetState();
}

class _GiftSheetState extends State<GiftSheet> {
  int index = 0;
  bool busy = false;

  static const gifts = [
    ('玫瑰', '一生只送一个人', 10),
    ('香水', '闻起来就很贵', 30),
    ('口红', '色号是最爱的那个', 66),
    ('蛋糕', '甜甜的心意', 128),
    ('钻石', '闪耀全场', 520),
    ('皇冠', '你就是我的王', 1314),
  ];

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final list = st.convos.where((c) => c.id == widget.convId).toList();
    final c = list.isEmpty ? null : list.first;
    final uid = c == null || c.isGroup ? '' : c.members.firstWhere((m) => m != st.user?.id, orElse: () => '');

    return PageScaffold(
      title: '送礼物',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(gradient: C.vipGradient, borderRadius: BorderRadius.circular(16)),
            child: Column(
              children: [
                const Icon(LucideIcons.gift, color: Colors.white, size: 42),
                const SizedBox(height: 8),
                Text('送给 ${uid.isEmpty ? (c?.title ?? '对方') : st.displayOf(uid)}', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600)),
                const SizedBox(height: 4),
                Text('余额 ¥${st.profile?.coins ?? 0}', style: const TextStyle(color: Colors.white70, fontSize: 12.5)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 3,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 0.92,
            mainAxisSpacing: 10,
            crossAxisSpacing: 10,
            children: [
              for (var i = 0; i < gifts.length; i++)
                GestureDetector(
                  onTap: () => setState(() => index = i),
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: index == i ? C.primary : C.divider, width: index == i ? 1.6 : 1),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(LucideIcons.gift, color: Color(0xFFE5A13B), size: 30),
                        const SizedBox(height: 8),
                        Text(gifts[i].$1, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 3),
                        Text('¥${gifts[i].$3}', style: const TextStyle(fontSize: 12.5, color: C.primary)),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 18),
          PrimaryButton(
            text: '送 ${gifts[index].$1}（¥${gifts[index].$3}）',
            loading: busy,
            onTap: () async {
              if (uid.isEmpty) {
                st.say('群里送礼暂时只支持一对一发');
                return;
              }
              setState(() => busy = true);
              try {
                await Api.I.gift(uid, {
                  'kind': 'vip',
                  'tier': gifts[index].$1,
                  'price': gifts[index].$3,
                  'title': gifts[index].$1,
                  'desc': gifts[index].$2,
                }, conv: widget.convId);
                await st.refreshProfile();
                await st.refreshAll();
                Nav.pop();
                st.say('礼物已送出');
              } catch (e) {
                st.say(e is ApiException ? (e.message.isEmpty ? '送礼失败' : e.message) : '送礼失败');
              }
              setState(() => busy = false);
            },
          ),
        ],
      ),
    );
  }
}

/* ------------------------------ 红包/转账详情 ---------------------------- */

class PacketPage extends StatefulWidget {
  final String msgId;
  const PacketPage({super.key, required this.msgId});
  @override
  State<PacketPage> createState() => _PacketPageState();
}

class _PacketPageState extends State<PacketPage> {
  Message? msg;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final m = await Api.I.req('/collections/messages/records/${widget.msgId}');
      if (mounted) setState(() => msg = Message.from(m));
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final m = msg;
    if (m == null) return const PageScaffold(title: '详情', child: Center(child: CircularProgressIndicator(strokeWidth: 2)));

    final meta = m.metaMap;
    final isGift = m.kind == 'gift';
    final mine = m.sender == st.user?.id;
    final state = '${meta['st'] ?? ''}';
    final amount = int.tryParse('${meta['amount'] ?? meta['price'] ?? 0}') ?? 0;
    final done = state == 'received' || state == 'back';

    return PageScaffold(
      title: isGift ? '礼物' : '转账',
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 34, horizontal: 20),
            decoration: BoxDecoration(
              gradient: isGift ? C.vipGradient : const LinearGradient(colors: [Color(0xFF1E88E5), Color(0xFF42A5F5)]),
              borderRadius: BorderRadius.circular(18),
              boxShadow: C.shadowFloat,
            ),
            child: Column(
              children: [
                Icon(isGift ? LucideIcons.gift : LucideIcons.wallet, color: Colors.white, size: 50),
                const SizedBox(height: 14),
                Text('${meta['title'] ?? (isGift ? '礼物' : '转账')}', style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600)),
                const SizedBox(height: 10),
                Text(isGift ? '¥$amount' : '¥${(amount / 100).toStringAsFixed(2)}', style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w700)),
                const SizedBox(height: 10),
                Text(
                  done
                      ? (state == 'back' ? '已退回（24 小时未领取）' : '已被领取')
                      : (mine ? '等待对方确认' : '待你确认收下'),
                  style: const TextStyle(color: Colors.white70, fontSize: 13),
                ),
              ],
            ),
          ),
          if (!mine && !done) ...[
            const SizedBox(height: 22),
            PrimaryButton(
              text: '确认收下',
              loading: busy,
              onTap: () async {
                setState(() => busy = true);
                try {
                  if (isGift) {
                    await Api.I.giftClaim(widget.msgId);
                  } else {
                    await Api.I.transferRecv(widget.msgId);
                  }
                  await st.refreshProfile();
                  await st.refreshAll();
                  await _load();
                  st.say('已收下');
                } catch (_) {
                  st.say('收取失败');
                }
                setState(() => busy = false);
              },
            ),
            const SizedBox(height: 12),
            TextButton(
              onPressed: busy
                  ? null
                  : () async {
                      setState(() => busy = true);
                      try {
                        if (isGift) {
                          await Api.I.giftBack(widget.msgId);
                        } else {
                          await Api.I.transferBack(widget.msgId);
                        }
                        await st.refreshProfile();
                        await _load();
                        st.say('已退回');
                      } catch (_) {
                        st.say('退回失败');
                      }
                      setState(() => busy = false);
                    },
              child: const Text('退回', style: TextStyle(color: C.textSub)),
            ),
          ],
          if (mine && !done) ...[
            const SizedBox(height: 22),
            TextButton(
              onPressed: busy
                  ? null
                  : () async {
                      setState(() => busy = true);
                      try {
                        if (isGift) {
                          await Api.I.giftBack(widget.msgId);
                        } else {
                          await Api.I.transferBack(widget.msgId);
                        }
                        await st.refreshProfile();
                        await _load();
                        st.say('已撤回');
                      } catch (_) {
                        st.say('撤回失败');
                      }
                      setState(() => busy = false);
                    },
              child: const Text('撤回', style: TextStyle(color: C.danger)),
            ),
          ],
        ],
      ),
    );
  }
}

/* ------------------------------- 钱包首页 ------------------------------ */

class WalletPage extends StatelessWidget {
  const WalletPage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '我的钱包',
      child: ListView(
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(14, 16, 14, 0),
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(gradient: C.brandGradient, borderRadius: BorderRadius.circular(18), boxShadow: C.shadowFloat),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('余额', style: TextStyle(color: Colors.white70, fontSize: 13)),
                const SizedBox(height: 8),
                Text('¥${st.profile?.coins ?? 0}', style: const TextStyle(color: Colors.white, fontSize: 36, fontWeight: FontWeight.w700)),
                const SizedBox(height: 18),
                Row(
                  children: [
                    Expanded(
                      child: _walletBtn(LucideIcons.receiptText, '账单', () => Nav.push(const BillsPage())),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _walletBtn(LucideIcons.lock, '支付密码', () => Nav.push(const PayPwdPage())),
                    ),
                  ],
                ),
              ],
            ),
          ),
          CellGroup(
            children: [
              Cell(title: '钱包账单', leading: const Icon(LucideIcons.receiptText, color: C.textSub, size: 21), onTap: () => Nav.push(const BillsPage())),
              Cell(title: '支付密码', leading: const Icon(LucideIcons.lock, color: C.textSub, size: 21), hint: st.profile?.hasPayPwd == true ? '已设置' : '未设置', onTap: () => Nav.push(const PayPwdPage())),
            ],
          ),
        ],
      ),
    );
  }

  Widget _walletBtn(IconData icon, String label, VoidCallback tap) {
    return InkWell(
      onTap: tap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(12)),
        child: Column(
          children: [
            Icon(icon, color: Colors.white, size: 22),
            const SizedBox(height: 5),
            Text(label, style: const TextStyle(color: Colors.white, fontSize: 12.5)),
          ],
        ),
      ),
    );
  }
}

/* -------------------------------- 账单 -------------------------------- */

class BillsPage extends StatefulWidget {
  const BillsPage({super.key});
  @override
  State<BillsPage> createState() => _BillsPageState();
}

class _BillsPageState extends State<BillsPage> {
  List<Bill> list = [];
  String kind = 'all';
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => loading = true);
    try {
      final l = await Api.I.bills(kind: kind, perPage: 50);
      if (mounted) setState(() => list = l);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '账单',
      child: Column(
        children: [
          SizedBox(
            height: 46,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: [
                for (final t in const [('all', '全部'), ('transfer_out', '转出'), ('transfer_in', '转入'), ('lucky', '靓号'), ('vip', '会员'), ('gift', '礼物'), ('refund', '退款')])
                  Padding(
                    padding: const EdgeInsets.only(right: 8, top: 8, bottom: 8),
                    child: ChoiceChip(
                      label: Text(t.$2, style: TextStyle(fontSize: 13, color: kind == t.$1 ? Colors.white : C.textSub)),
                      selected: kind == t.$1,
                      selectedColor: C.primary,
                      backgroundColor: Colors.white,
                      showCheckmark: false,
                      onSelected: (_) {
                        kind = t.$1;
                        _load();
                      },
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                : list.isEmpty
                    ? const Empty(text: '还没有账单记录', icon: LucideIcons.receiptText)
                    : ListView(
                        children: list
                            .map((b) => Cell(
                                  title: b.title.isEmpty ? _kindName(b.kind) : b.title,
                                  subtitle: '${fmtDateTime(b.created)}${b.memo?.isNotEmpty == true ? ' · ${b.memo}' : ''}',
                                  chevron: false,
                                  trailing: Text(
                                    '${b.amount >= 0 ? '+' : ''}${(b.amount / 100).toStringAsFixed(2)}',
                                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: b.amount >= 0 ? C.green : C.danger),
                                  ),
                                ))
                            .toList(),
                      ),
          ),
        ],
      ),
    );
  }

  String _kindName(String k) => switch (k) {
        'topup' => '充值',
        'transfer_out' => '转账支出',
        'transfer_in' => '转账收入',
        'refund' => '退款',
        'lucky' => '购买靓号',
        'group_lucky' => '购买群靓号',
        'vip' => '开通会员',
        'gift' => '礼物',
        'adjust' => '余额调整',
        _ => '交易',
      };
}

/* ------------------------------ 支付密码 ------------------------------ */

class PayPwdPage extends StatefulWidget {
  const PayPwdPage({super.key});
  @override
  State<PayPwdPage> createState() => _PayPwdPageState();
}

class _PayPwdPageState extends State<PayPwdPage> {
  final oldPwd = TextEditingController();
  final newPwd = TextEditingController();
  final again = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final has = st.profile?.hasPayPwd == true;
    return PageScaffold(
      title: '支付密码',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('支付密码用于转账、购买等资金操作，6 位数字', style: TextStyle(fontSize: 12.5, color: C.textSub)),
          const SizedBox(height: 16),
          if (has) ...[
            TextField(controller: oldPwd, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(hintText: '原支付密码', counterText: '')),
            const SizedBox(height: 12),
          ],
          TextField(controller: newPwd, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: InputDecoration(hintText: has ? '新支付密码' : '设置 6 位支付密码', counterText: '')),
          const SizedBox(height: 12),
          TextField(controller: again, obscureText: true, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(hintText: '再输一次', counterText: '')),
          const SizedBox(height: 22),
          PrimaryButton(
            text: has ? '修改支付密码' : '设置支付密码',
            loading: busy,
            onTap: () async {
              if (newPwd.text.length != 6) {
                st.say('密码要 6 位数字');
                return;
              }
              if (newPwd.text != again.text) {
                st.say('两次输入不一致');
                return;
              }
              setState(() => busy = true);
              try {
                await Api.I.setPayPwd(newPwd.text, old: oldPwd.text);
                await st.refreshProfile();
                st.say('支付密码已设置');
                Nav.pop();
              } catch (e) {
                st.say(e is ApiException ? (e.message.isEmpty ? '设置失败' : e.message) : '设置失败');
              }
              setState(() => busy = false);
            },
          ),
        ],
      ),
    );
  }
}

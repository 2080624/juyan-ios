/// 登录 / 注册 / 封禁
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../widgets/kit.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  bool register = true;
  bool busy = false;
  bool showPwd = false;

  final nick = TextEditingController();
  final account = TextEditingController();
  final pwd = TextEditingController();
  final ref = TextEditingController();

  @override
  void dispose() {
    nick.dispose();
    account.dispose();
    pwd.dispose();
    ref.dispose();
    super.dispose();
  }

  String? _err;

  Future<void> _submit() async {
    final st = AppState.I;
    FocusScope.of(context).unfocus();
    setState(() => _err = null);
    if (register) {
      if (nick.text.trim().isEmpty) return setState(() => _err = '请填个昵称');
      if (nick.text.trim().length > 12) return setState(() => _err = '昵称最多 12 个字');
      if (pwd.text.length < 6) return setState(() => _err = '密码至少 6 位');
      setState(() => busy = true);
      try {
        final taken = await Api.I.nicknameTaken(nick.text.trim());
        if (taken) {
          setState(() {
            busy = false;
            _err = '这个昵称已经有人用了，换一个';
          });
          return;
        }
        await st.signUp(nick.text.trim(), pwd.text, ref: ref.text.trim());
      } catch (e) {
        setState(() {
          busy = false;
          _err = e is ApiException ? e.message : '注册失败，稍后再试';
        });
        return;
      }
      setState(() => busy = false);
      st.say('注册成功，欢迎来到聚言商聊');
      return;
    }
    if (account.text.trim().isEmpty) return setState(() => _err = '请填账号或昵称');
    setState(() => busy = true);
    try {
      await st.signIn(account.text.trim(), pwd.text);
      st.say('欢迎回来');
    } catch (e) {
      setState(() {
        busy = false;
        _err = e is ApiException ? (e.message.isEmpty ? '账号或密码不正确' : e.message) : '登录失败，稍后再试';
      });
      return;
    }
    setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(28, 40, 28, 30),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 30),
              const Center(child: JyLogo(size: 78, radius: 23)),
              const SizedBox(height: 18),
              const Center(child: Text('聚言商聊', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700, letterSpacing: 1))),
              const SizedBox(height: 6),
              const Center(child: Text('聊得简单，聊得自在', style: TextStyle(fontSize: 13, color: C.textSub))),
              const SizedBox(height: 32),

              if (register) ...[
                _Field(icon: Icons.person_outline_rounded, hint: '昵称（别人搜你用的名字）', ctl: nick, maxLen: 12),
                const SizedBox(height: 12),
              ] else ...[
                _Field(icon: Icons.badge_outlined, hint: '账号 / 昵称 / 靓号', ctl: account),
                const SizedBox(height: 12),
              ],

              _Field(
                icon: Icons.lock_outline_rounded,
                hint: '密码（至少 6 位）',
                ctl: pwd,
                obscure: !showPwd,
                trailing: IconButton(
                  icon: Icon(showPwd ? Icons.visibility_off_outlined : Icons.visibility_outlined, size: 20, color: C.textMute),
                  onPressed: () => setState(() => showPwd = !showPwd),
                ),
              ),

              if (register) ...[
                const SizedBox(height: 12),
                _Field(icon: Icons.card_giftcard_outlined, hint: '邀请码（朋友 ID，可不填）', ctl: ref, digitsOnly: true),
              ],

              if (_err != null)
                Padding(
                  padding: const EdgeInsets.only(top: 14),
                  child: Row(
                    children: [
                      const Icon(Icons.error_outline_rounded, size: 16, color: C.danger),
                      const SizedBox(width: 6),
                      Expanded(child: Text(_err!, style: const TextStyle(fontSize: 13, color: C.danger))),
                    ],
                  ),
                ),

              const SizedBox(height: 26),
              PrimaryButton(text: register ? '注 册' : '登 录', loading: busy, onTap: _submit),
              const SizedBox(height: 18),
              Center(
                child: TextButton(
                  onPressed: () => setState(() {
                    register = !register;
                    _err = null;
                  }),
                  child: Text(
                    register ? '已有账号？去登录' : '还没有账号？去注册',
                    style: const TextStyle(color: C.primary, fontSize: 14),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Center(
                child: Text('注册即表示同意用户协议与隐私政策', style: TextStyle(fontSize: 11.5, color: C.textMute)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _Field extends StatelessWidget {
  final IconData icon;
  final String hint;
  final TextEditingController ctl;
  final bool obscure;
  final Widget? trailing;
  final bool digitsOnly;
  final int? maxLen;
  const _Field({required this.icon, required this.hint, required this.ctl, this.obscure = false, this.trailing, this.digitsOnly = false, this.maxLen});

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: ctl,
      obscureText: obscure,
      maxLength: maxLen,
      keyboardType: digitsOnly ? TextInputType.number : TextInputType.text,
      inputFormatters: digitsOnly ? [FilteringTextInputFormatter.digitsOnly] : null,
      style: const TextStyle(fontSize: 15.5),
      decoration: InputDecoration(
        hintText: hint,
        counterText: '',
        prefixIcon: Icon(icon, size: 20, color: C.textMute),
        suffixIcon: trailing,
        filled: true,
        fillColor: C.surfaceHover,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: C.primary, width: 1.5)),
      ),
    );
  }
}

/* ------------------------------- 封禁页 ------------------------------- */

class BannedPage extends StatefulWidget {
  const BannedPage({super.key});
  @override
  State<BannedPage> createState() => _BannedPageState();
}

class _BannedPageState extends State<BannedPage> {
  final ctl = TextEditingController();
  bool sent = false;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.block_rounded, size: 66, color: C.danger),
              const SizedBox(height: 18),
              const Center(child: Text('账号已封禁', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
              const SizedBox(height: 10),
              Center(
                child: Text(
                  st.banReason.isEmpty ? '该账号因违反社区规范已被限制登录' : st.banReason,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 14, color: C.textSub),
                ),
              ),
              const SizedBox(height: 6),
              Center(child: Text('ID：${st.banShowId}', style: const TextStyle(fontSize: 12.5, color: C.textMute))),
              const SizedBox(height: 30),
              if (!sent) ...[
                const Text('申诉通道', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                const SizedBox(height: 8),
                TextField(
                  controller: ctl,
                  maxLines: 4,
                  decoration: const InputDecoration(hintText: '简单说明一下情况，我们会人工复核'),
                ),
                const SizedBox(height: 14),
                PrimaryButton(
                  text: '提交申诉',
                  onTap: () async {
                    if (ctl.text.trim().isEmpty) return;
                    await Api.I.appeal(st.banShowId, ctl.text.trim(), '').catchError((_) {});
                    setState(() => sent = true);
                  },
                ),
              ] else
                const Center(child: Text('申诉已提交，请等待人工复核', style: TextStyle(fontSize: 14, color: C.green))),
              const SizedBox(height: 14),
              TextButton(
                onPressed: () => AppState.I.signOut(),
                child: const Text('退出登录', style: TextStyle(color: C.textSub)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// 我的（个人中心 + 资料编辑）
library;

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../widgets/kit.dart';
import 'friend.dart';
import 'misc.dart';
import 'moments.dart';
import 'packet.dart';
import 'settings.dart';
import 'vip.dart';

class MinePage extends StatelessWidget {
  const MinePage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final p = st.profile;
        return Scaffold(
          backgroundColor: C.bgApp,
          body: RefreshIndicator(
            onRefresh: () => st.refreshProfile(),
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                // 头部
                Container(
                  padding: EdgeInsets.fromLTRB(20, MediaQuery.of(context).padding.top + 30, 20, 40),
                  decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF1A7DFF), Color(0xFF4C9AFF)])),
                  child: Row(
                    children: [
                      GestureDetector(
                        onTap: () => Nav.push(const EditProfilePage()),
                        child: Avatar(url: st.myAvatar, name: st.displayName, size: 64, radius: 16),
                      ),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Flexible(
                                  child: Text(
                                    st.displayName,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w700),
                                  ),
                                ),
                                if (st.isVip) ...[
                                  const SizedBox(width: 7),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                                    decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(6), border: Border.all(color: Colors.white54)),
                                    child: Text(vipLabel(st.myVipLevel), style: const TextStyle(color: Colors.white, fontSize: 10.5, fontWeight: FontWeight.w700)),
                                  ),
                                ],
                              ],
                            ),
                            const SizedBox(height: 7),
                            Text('ID: ${p?.showId ?? ''}', style: const TextStyle(color: Colors.white70, fontSize: 13)),
                            if ((p?.bio ?? '').isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 4),
                                child: Text(p!.bio, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60, fontSize: 12.5)),
                              ),
                          ],
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.qr_code_rounded, color: Colors.white, size: 26),
                        onPressed: () => Nav.push(const MyQrPage()),
                      ),
                    ],
                  ),
                ),

                // 会员卡
                Transform.translate(
                  offset: const Offset(0, -22),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 14),
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
                    decoration: BoxDecoration(gradient: C.vipGradient, borderRadius: BorderRadius.circular(16), boxShadow: C.shadowFloat),
                    child: Row(
                      children: [
                        const Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 30),
                        const SizedBox(width: 13),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(st.isVip ? vipLabel(st.myVipLevel) : '开通会员', style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                              const SizedBox(height: 3),
                              Text(
                                st.isVip ? '到期时间：${(p?.vipExpire ?? '').split('T').first}' : '解锁靓号、大群、专属标识',
                                style: const TextStyle(color: Colors.white70, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        TextButton(
                          onPressed: () => Nav.push(const VipPage()),
                          style: TextButton.styleFrom(backgroundColor: Colors.white, foregroundColor: C.vipDark, padding: const EdgeInsets.symmetric(horizontal: 16)),
                          child: Text(st.isVip ? '续费' : '去开通', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                        ),
                      ],
                    ),
                  ),
                ),

                CellGroup(
                  margin: const EdgeInsets.fromLTRB(12, 0, 12, 0),
                  children: [
                    Cell(
                      leading: const Icon(Icons.account_balance_wallet_outlined, color: Color(0xFF26B36B), size: 21),
                      title: '我的钱包',
                      hint: '¥${p?.coins ?? 0}',
                      onTap: () => Nav.push(const WalletPage()),
                    ),
                    Cell(
                      leading: const Icon(Icons.star_border_rounded, color: Color(0xFFE5A13B), size: 21),
                      title: '我的收藏',
                      onTap: () => Nav.push(const FavoritesPage()),
                    ),
                    Cell(
                      leading: const Icon(Icons.photo_library_outlined, color: Color(0xFF7C88E8), size: 21),
                      title: '我的动态',
                      onTap: () => Nav.push(const MomentsPage(onlyUserId: '')),
                    ),
                    Cell(
                      leading: const Icon(Icons.diamond_outlined, color: Color(0xFF4C9AFF), size: 21),
                      title: '靓号商城',
                      onTap: () => Nav.push(const LuckyPage()),
                    ),
                  ],
                ),

                CellGroup(
                  children: [
                    Cell(
                      leading: const Icon(Icons.headset_mic_outlined, color: Color(0xFF1A7DFF), size: 21),
                      title: '官方客服',
                      onTap: () => st.openOfficial(),
                    ),
                    Cell(
                      leading: const Icon(Icons.feedback_outlined, color: Color(0xFF9AA3B2), size: 21),
                      title: '问题反馈',
                      onTap: () => Nav.push(const FeedbackPage()),
                    ),
                    Cell(
                      leading: const Icon(Icons.card_giftcard_outlined, color: Color(0xFFE5484D), size: 21),
                      title: '邀请有礼',
                      subtitle: '邀好友得积分',
                      onTap: () => Nav.push(const InvitePage()),
                    ),
                  ],
                ),

                CellGroup(
                  children: [
                    Cell(
                      leading: const Icon(Icons.settings_outlined, color: Color(0xFF9AA3B2), size: 21),
                      title: '设置',
                      onTap: () => Nav.push(const SettingsPage()),
                    ),
                  ],
                ),

                const SizedBox(height: 30),
                Center(child: Text('聚言商聊 v2.0', style: const TextStyle(fontSize: 11.5, color: C.textMute))),
                const SizedBox(height: 26),
              ],
            ),
          ),
        );
      },
    );
  }
}

/* ------------------------------ 编辑资料 ------------------------------ */

class EditProfilePage extends StatefulWidget {
  const EditProfilePage({super.key});
  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  late final nick = TextEditingController(text: AppState.I.profile?.nickname ?? '');
  late final bio = TextEditingController(text: AppState.I.profile?.bio ?? '');
  late final region = TextEditingController(text: AppState.I.profile?.region ?? '');
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final p = st.profile;
    return PageScaffold(
      title: '编辑资料',
      child: ListView(
        children: [
          CellGroup(
            children: [
              Cell(
                leading: Avatar(url: st.myAvatar, name: st.displayName, size: 54, radius: 14),
                title: '头像',
                onTap: () async {
                  final f = await _pick();
                  if (f == null) return;
                  try {
                    await Api.I.upload('profiles', p!.id, 'avatar', f);
                    await st.refreshProfile();
                    st.say('头像已更新');
                  } catch (_) {
                    st.say('上传失败');
                  }
                },
              ),
              Cell(
                leading: const Icon(Icons.wallpaper_rounded, color: C.textSub, size: 21),
                title: '朋友圈封面',
                onTap: () async {
                  final f = await _pick();
                  if (f == null) return;
                  try {
                    await Api.I.upload('profiles', p!.id, 'cover', f);
                    await st.refreshProfile();
                    st.say('封面已更新');
                  } catch (_) {}
                },
              ),
            ],
          ),
          CellGroup(
            children: [
              Cell(
                title: '昵称',
                hint: p?.nickname ?? '',
                onTap: () async {
                  final v = await promptDialog(context, '修改昵称', hint: '最多 12 个字');
                  if (v == null || v.isEmpty) return;
                  if (await Api.I.nicknameTaken(v)) {
                    st.say('这个昵称有人用了');
                    return;
                  }
                  await Api.I.updateProfile(p!.id, {'nickname': v}).catchError((_) {});
                  await st.refreshProfile();
                },
              ),
              Cell(
                title: '个性签名',
                hint: (p?.bio ?? '').isEmpty ? '未设置' : p!.bio,
                onTap: () async {
                  final v = await promptDialog(context, '个性签名', hint: '说句话介绍自己');
                  if (v == null) return;
                  await Api.I.updateProfile(p!.id, {'bio': v}).catchError((_) {});
                  await st.refreshProfile();
                },
              ),
              Cell(
                title: '性别',
                hint: (p?.gender ?? '').isEmpty ? '未设置' : p!.gender,
                onTap: () async {
                  final v = await showSheet<String>(context, title: '选择性别', children: [
                    const SheetItem(text: '男', icon: Icons.male_rounded),
                    const SheetItem(text: '女', icon: Icons.female_rounded),
                  ]);
                  if (v == null) return;
                  await Api.I.updateProfile(p!.id, {'gender': v}).catchError((_) {});
                  await st.refreshProfile();
                },
              ),
              Cell(
                title: '地区',
                hint: (p?.region ?? '').isEmpty ? '未设置' : p!.region,
                onTap: () async {
                  final v = await promptDialog(context, '所在地区', hint: '例如：广东 深圳');
                  if (v == null) return;
                  await Api.I.updateProfile(p!.id, {'region': v}).catchError((_) {});
                  await st.refreshProfile();
                },
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<File?> _pick() async {
    final picked = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 900);
    return picked == null ? null : File(picked.path);
  }
}

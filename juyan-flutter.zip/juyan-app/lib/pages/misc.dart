/// 搜索 / 转发 / 看图 / 切换账号 / 邀请 / 反馈 / 收藏
library;


import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../core/prefs.dart';
import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../data/models.dart';
import '../widgets/kit.dart';
import 'chat.dart';
import 'friend.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

/* ------------------------------- 全局搜索 ------------------------------- */

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});
  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  final ctl = TextEditingController();
  List<Profile> users = [];
  List<Message> msgs = [];
  bool busy = false;
  String kw = '';

  Future<void> _go(String q) async {
    kw = q;
    if (q.trim().isEmpty) {
      setState(() {
        users = [];
        msgs = [];
      });
      return;
    }
    setState(() => busy = true);
    try {
      final u = await Api.I.searchProfiles(q, perPage: 20);
      List<Message> m = [];
      try {
        final hits = await Api.I.msgSearch(q);
        m = hits
            .map((h) => Message(
                  id: h.id,
                  conversation: h.conv,
                  sender: h.sender,
                  kind: h.kind,
                  text: h.text,
                  created: h.created,
                ))
            .toList();
      } catch (_) {}
      setState(() {
        users = u.where((x) => x.user != AppState.I.user?.id).toList();
        msgs = m;
      });
    } catch (_) {}
    setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: C.bgApp,
      appBar: AppBar(
        titleSpacing: 0,
        title: TextField(
          controller: ctl,
          autofocus: true,
          textInputAction: TextInputAction.search,
          onChanged: _go,
          onSubmitted: _go,
          decoration: const InputDecoration(
            hintText: '搜好友 / 群 / 聊天记录',
            filled: false,
            border: InputBorder.none,
            enabledBorder: InputBorder.none,
            focusedBorder: InputBorder.none,
            isDense: true,
          ),
        ),
        actions: [
          TextButton(onPressed: () => _go(ctl.text), child: const Text('搜索', style: TextStyle(fontSize: 15))),
        ],
      ),
      body: busy
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : ListView(
              children: [
                if (users.isNotEmpty) ...[
                  const _Head('用户'),
                  ...users.map((p) => Cell(
                        leading: Avatar(url: profileAvatar(p), name: p.nickname, size: 42),
                        title: p.nickname,
                        subtitle: 'ID: ${p.showId}',
                        onTap: () => Nav.push(UserProfilePage(userId: p.user)),
                      )),
                ],
                if (msgs.isNotEmpty) ...[
                  const _Head('聊天记录'),
                  ...msgs.map((m) => Cell(
                        leading: const Icon(LucideIcons.messageSquare, color: C.textSub, size: 20),
                        title: m.text.isEmpty ? '[消息]' : m.text,
                        subtitle: fmtDateTime(m.created),
                        onTap: () => Nav.push(ChatPage(convId: m.conversation)),
                      )),
                ],
                if (kw.isNotEmpty && users.isEmpty && msgs.isEmpty && !busy)
                  const SizedBox(height: 120, child: Empty(text: '没搜到相关内容', icon: LucideIcons.searchX)),
              ],
            ),
    );
  }
}

class _Head extends StatelessWidget {
  final String text;
  const _Head(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
        child: Text(text, style: const TextStyle(fontSize: 12.5, color: C.textSub)),
      );
}

/* -------------------------------- 转发 -------------------------------- */

class ForwardPage extends StatelessWidget {
  final Message msg;
  const ForwardPage({super.key, required this.msg});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '转发到',
      child: ListView(
        children: st.convos
            .map((c) => Cell(
                  leading: Avatar(url: st.avatarUrlOf(c), name: st.titleOf(c), size: 42, group: c.isGroup),
                  title: st.titleOf(c),
                  onTap: () async {
                    try {
                      await Api.I.postMessage(
                        convId: c.id,
                        senderId: st.user!.id,
                        kind: msg.kind == 'image' ? 'text' : msg.kind,
                        text: msg.kind == 'text' ? msg.text : '[转发内容]',
                      );
                      Nav.pop();
                      st.say('已转发');
                    } catch (_) {
                      st.say('转发失败');
                    }
                  },
                ))
            .toList(),
      ),
    );
  }
}

/* -------------------------------- 看图 -------------------------------- */

class ImageViewerPage extends StatelessWidget {
  final String url;
  const ImageViewerPage({super.key, required this.url});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(LucideIcons.download, color: Colors.white),
            onPressed: () => AppState.I.say('长按图片即可保存'),
          ),
        ],
      ),
      body: Center(child: InteractiveViewer(child: RemoteImg(url: url, fit: BoxFit.contain))),
    );
  }
}

/* ------------------------------ 切换账号 ------------------------------- */

class SwitchAccountPage extends StatefulWidget {
  const SwitchAccountPage({super.key});
  @override
  State<SwitchAccountPage> createState() => _SwitchAccountPageState();
}

class _SwitchAccountPageState extends State<SwitchAccountPage> {
  List<String> accounts = [];

  @override
  void initState() {
    super.initState();
    accounts = Prefs.accounts;
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '切换账号',
      child: ListView(
        children: [
          CellGroup(
            header: '当前账号',
            children: [
              Cell(
                leading: Avatar(url: st.myAvatar, name: st.displayName, size: 42),
                title: st.displayName,
                subtitle: 'ID: ${st.profile?.showId ?? ''}',
                trailing: const Icon(LucideIcons.circleCheck, color: C.green, size: 20),
                chevron: false,
              ),
            ],
          ),
          CellGroup(
            children: [
              Cell(
                leading: const Icon(LucideIcons.circlePlus, color: C.primary, size: 22),
                title: '添加账号',
                onTap: () async {
                  await Nav.push(const AddAccountPage());
                  if (mounted) setState(() => accounts = Prefs.accounts);
                },
              ),
              Cell(
                leading: const Icon(LucideIcons.logOut, color: C.danger, size: 22),
                title: '退出当前账号',
                titleColor: C.danger,
                chevron: false,
                onTap: () async {
                  if (await confirmDialog(context, '确定退出登录？')) {
                    await st.signOut();
                    Nav.pop();
                  }
                },
              ),
            ],
          ),
          if (accounts.isNotEmpty)
            CellGroup(
              header: '已保存的账号',
              children: accounts
                  .map((a) => Cell(
                        leading: const Icon(LucideIcons.user, color: C.textSub, size: 22),
                        title: a,
                        trailing: IconButton(
                          icon: const Icon(LucideIcons.x, size: 17, color: C.textMute),
                          onPressed: () async {
                            final list = [...accounts]..remove(a);
                            await Prefs.setAccounts(list);
                            setState(() => accounts = list);
                          },
                        ),
                        chevron: false,
                        onTap: () => Nav.push(AddAccountPage(prefill: a)),
                      ))
                  .toList(),
            ),
        ],
      ),
    );
  }
}

class AddAccountPage extends StatefulWidget {
  final String prefill;
  const AddAccountPage({super.key, this.prefill = ''});
  @override
  State<AddAccountPage> createState() => _AddAccountPageState();
}

class _AddAccountPageState extends State<AddAccountPage> {
  late final ctl = TextEditingController(text: widget.prefill);
  final pwd = TextEditingController();
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '登录其他账号',
      child: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          TextField(controller: ctl, decoration: const InputDecoration(hintText: '账号 / 昵称 / 靓号')),
          const SizedBox(height: 12),
          TextField(controller: pwd, obscureText: true, decoration: const InputDecoration(hintText: '密码')),
          const SizedBox(height: 22),
          PrimaryButton(
            text: '登录',
            loading: busy,
            onTap: () async {
              setState(() => busy = true);
              try {
                final list = [...Prefs.accounts];
                if (!list.contains(ctl.text.trim())) list.add(ctl.text.trim());
                await Prefs.setAccounts(list);
                await AppState.I.signIn(ctl.text.trim(), pwd.text);
                Nav.pop();
                Nav.pop();
              } catch (e) {
                AppState.I.say('登录失败，检查账号密码');
              }
              setState(() => busy = false);
            },
          ),
        ],
      ),
    );
  }
}

/* -------------------------------- 邀请 -------------------------------- */

class InvitePage extends StatefulWidget {
  const InvitePage({super.key});
  @override
  State<InvitePage> createState() => _InvitePageState();
}

class _InvitePageState extends State<InvitePage> {
  InviteStat? stat;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await Api.I.inviteStat();
      if (mounted) setState(() => stat = s);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final showId = st.profile?.showId ?? '';
    final link = 'https://jysl.pw/?ref=$showId';
    return PageScaffold(
      title: '邀请有礼',
      child: ListView(
        children: [
          Container(
            margin: const EdgeInsets.fromLTRB(12, 14, 12, 0),
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(gradient: C.brandGradient, borderRadius: BorderRadius.circular(16), boxShadow: C.shadowFloat),
            child: Column(
              children: [
                const Text('邀请好友一起聊', style: TextStyle(color: Colors.white, fontSize: 19, fontWeight: FontWeight.w700)),
                const SizedBox(height: 6),
                const Text('好友注册即得奖励，越邀越多', style: TextStyle(color: Colors.white70, fontSize: 12.5)),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                  child: Column(
                    children: [
                      Text('我的邀请码', style: TextStyle(fontSize: 12, color: C.textSub)),
                      const SizedBox(height: 6),
                      Text(showId, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700, letterSpacing: 3)),
                      const SizedBox(height: 12),
                      PrimaryButton(
                        text: '复制邀请链接',
                        height: 42,
                        onTap: () async {
                          await Clipboard.setData(ClipboardData(text: link));
                          st.say('邀请链接已复制');
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          CellGroup(
            header: '邀请记录',
            children: [
              Cell(
                title: '已邀请好友',
                hint: '${stat?.count ?? 0} 人',
                chevron: false,
              ),
            ],
          ),
          if (stat != null && stat!.items.isNotEmpty)
            CellGroup(
              children: stat!.items
                  .map((i) => Cell(
                        leading: Avatar(name: i.nickname, size: 40),
                        title: i.nickname,
                        subtitle: 'ID: ${i.showId}',
                        chevron: false,
                      ))
                  .toList(),
            ),
          const Padding(
            padding: EdgeInsets.all(24),
            child: Text('邀请规则：每邀请 1 位好友注册并使用，双方各得 20 积分；首次凑满 10 个有效邀请，额外送 500 积分（每个账号一次）。',
                style: TextStyle(fontSize: 12, color: C.textMute, height: 1.6)),
          ),
        ],
      ),
    );
  }
}

/* -------------------------------- 收藏 -------------------------------- */

class FavoritesPage extends StatefulWidget {
  const FavoritesPage({super.key});
  @override
  State<FavoritesPage> createState() => _FavoritesPageState();
}

class _FavoritesPageState extends State<FavoritesPage> {
  List<Favorite> list = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.I.myFavorites(AppState.I.user!.id);
      if (mounted) setState(() => list = l);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '我的收藏',
      child: loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : list.isEmpty
              ? const Empty(text: '还没有收藏内容', icon: LucideIcons.star)
              : ListView(
                  children: list
                      .map((f) => Cell(
                            title: f.content,
                            subtitle: fmtDateTime(f.created),
                            chevron: false,
                            trailing: IconButton(
                              icon: const Icon(LucideIcons.trash2, size: 19, color: C.textMute),
                              onPressed: () async {
                                await Api.I.deleteFavorite(f.id).catchError((_) {});
                                _load();
                              },
                            ),
                          ))
                      .toList(),
                ),
    );
  }
}

/* -------------------------------- 反馈 -------------------------------- */

class FeedbackPage extends StatefulWidget {
  const FeedbackPage({super.key});
  @override
  State<FeedbackPage> createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  final ctl = TextEditingController();
  final contact = TextEditingController();
  List<FeedbackRec> list = [];
  bool busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.I.myFeedbacks(AppState.I.user!.id);
      if (mounted) setState(() => list = l);
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '问题反馈',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
            child: Column(
              children: [
                TextField(controller: ctl, maxLines: 5, decoration: const InputDecoration(hintText: '遇到什么问题？说详细点我们好定位')),
                const SizedBox(height: 10),
                TextField(controller: contact, decoration: const InputDecoration(hintText: '联系方式（可不填）')),
                const SizedBox(height: 14),
                PrimaryButton(
                  text: '提交',
                  loading: busy,
                  onTap: () async {
                    if (ctl.text.trim().isEmpty) return;
                    setState(() => busy = true);
                    await Api.I.sendFeedback(AppState.I.user!.id, ctl.text.trim(), contact.text.trim()).catchError((_) {
                      AppState.I.say('提交失败');
                    });
                    ctl.clear();
                    setState(() => busy = false);
                    AppState.I.say('已提交，我们会尽快处理');
                    _load();
                  },
                ),
              ],
            ),
          ),
          if (list.isNotEmpty) ...[
            const Padding(padding: EdgeInsets.fromLTRB(4, 20, 4, 8), child: Text('我的反馈记录', style: TextStyle(fontSize: 13, color: C.textSub))),
            ...list.map((f) => Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(12), boxShadow: C.shadow),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(f.content, style: const TextStyle(fontSize: 14.5)),
                      const SizedBox(height: 6),
                      Text(fmtDateTime(f.created), style: const TextStyle(fontSize: 11.5, color: C.textMute)),
                      if (f.reply.isNotEmpty) ...[
                        const SizedBox(height: 10),
                        Container(
                          width: double.infinity,
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(color: C.primarySoft, borderRadius: BorderRadius.circular(8)),
                          child: Text('官方回复：${f.reply}', style: const TextStyle(fontSize: 13, color: C.primaryDeep)),
                        ),
                      ],
                    ],
                  ),
                )),
          ],
        ],
      ),
    );
  }
}

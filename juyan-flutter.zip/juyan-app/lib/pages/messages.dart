/// 消息列表（左滑置顶/免打扰/删除）
library;

import 'package:flutter/material.dart';

import '../core/prefs.dart';
import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../widgets/kit.dart';
import 'chat.dart';
import 'friend.dart';
import 'group.dart';
import 'misc.dart';

class MessagesPage extends StatefulWidget {
  const MessagesPage({super.key});
  @override
  State<MessagesPage> createState() => _MessagesPageState();
}

class _MessagesPageState extends State<MessagesPage> {
  @override
  void initState() {
    super.initState();
    AppState.I.refreshAll();
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        var list = st.convos.where((c) => !Prefs.isHidden(c.id)).toList();
        list.sort((a, b) {
          final pa = Prefs.isPinned(a.id), pb = Prefs.isPinned(b.id);
          if (pa != pb) return pa ? -1 : 1;
          return b.lastTime.compareTo(a.lastTime);
        });

        return Scaffold(
          backgroundColor: C.bgApp,
          appBar: AppBar(
            title: const Text('消息'),
            automaticallyImplyLeading: false,
            actions: [
              IconButton(
                icon: const Icon(Icons.add_circle_outline_rounded, size: 23),
                onPressed: () => showSheet(context, title: '发起', children: [
                  SheetItem(text: '加好友 / 加群', icon: Icons.person_add_alt_1_rounded, onTap: () => Nav.push(const AddFriendPage())),
                  SheetItem(text: '扫一扫', icon: Icons.qr_code_scanner_rounded, onTap: () => Nav.push(const ScanPage())),
                  SheetItem(text: '建群', icon: Icons.group_add_rounded, onTap: () => Nav.push(const GroupCreatePage())),
                ]),
              ),
              const SizedBox(width: 4),
            ],
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(48),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 8),
                child: GestureDetector(
                  onTap: () => Nav.push(const SearchPage()),
                  child: Container(
                    height: 36,
                    decoration: BoxDecoration(color: C.surfaceHover, borderRadius: BorderRadius.circular(10)),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_rounded, size: 18, color: C.textMute),
                        SizedBox(width: 5),
                        Text('搜索', style: TextStyle(fontSize: 14, color: C.textMute)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
          body: RefreshIndicator(
            onRefresh: () => st.refreshAll(),
            child: list.isEmpty
                ? ListView(children: const [SizedBox(height: 160), Empty(text: '还没有聊天，去加个好友吧', icon: Icons.forum_outlined)])
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 20),
                    itemCount: list.length,
                    itemBuilder: (context, i) => _ConvRow(conv: list[i]),
                  ),
          ),
        );
      },
    );
  }
}

class _ConvRow extends StatelessWidget {
  final Conversation conv;
  const _ConvRow({required this.conv});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final title = st.titleOf(conv);
    final avatar = st.avatarUrlOf(conv);
    final unread = st.unreadOf(conv);
    final muted = Prefs.isMuted(conv.id);
    final pinned = Prefs.isPinned(conv.id);
    final peerId = conv.isGroup ? '' : conv.members.firstWhere((m) => m != st.user?.id, orElse: () => '');
    final p = peerId.isEmpty ? null : st.personOf(peerId);

    return SwipeCell(
      onAction: (a) async {
        if (a == 'pin') {
          await Prefs.togglePin(conv.id);
          st.say(Prefs.isPinned(conv.id) ? '已置顶' : '已取消置顶');
        } else if (a == 'mute') {
          await Prefs.toggleMute(conv.id);
          st.say(Prefs.isMuted(conv.id) ? '已开启免打扰' : '已关闭免打扰');
        } else if (a == 'del') {
          await Prefs.hideConv(conv.id);
          st.say('已从列表移除');
        }
        st.bump();
      },
      child: Material(
        color: pinned ? const Color(0xFFF7F9FC) : Colors.white,
        child: InkWell(
          onTap: () async {
            await st.markRead(conv.id);
            Nav.push(ChatPage(convId: conv.id));
          },
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 10),
            child: Row(
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Avatar(url: avatar, name: title, size: 48, radius: 13, group: conv.isGroup),
                    if (peerId.isNotEmpty && st.onlineOf(peerId))
                      Positioned(
                        right: -2,
                        bottom: -2,
                        child: Container(
                          width: 13,
                          height: 13,
                          decoration: BoxDecoration(color: C.green, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2)),
                        ),
                      ),
                    if (unread && muted)
                      const Positioned(
                        right: 0,
                        top: 0,
                        child: Dot(count: 1),
                      ),
                  ],
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Flexible(
                            child: Text(
                              title,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                            ),
                          ),
                          if (p != null && p.vipAlive) const VipTag(level: 'VIP', scale: 0.95),
                          if (conv.isGroup)
                            Container(
                              margin: const EdgeInsets.only(left: 5),
                              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                              decoration: BoxDecoration(color: C.primarySoft, borderRadius: BorderRadius.circular(4)),
                              child: Text('${conv.members.length}人', style: const TextStyle(fontSize: 9.5, color: C.primary)),
                            ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          if (muted) const Padding(padding: EdgeInsets.only(right: 4), child: Icon(Icons.notifications_off_rounded, size: 13, color: C.textMute)),
                          Expanded(
                            child: Text(
                              Prefs.showPreview ? (conv.lastText.isEmpty ? '暂无消息' : conv.lastText) : (conv.lastText.isEmpty ? '' : '[新消息]'),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 13, color: C.textSub),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(fmtTime(conv.lastTime), style: const TextStyle(fontSize: 11.5, color: C.textMute)),
                    const SizedBox(height: 6),
                    if (unread && !muted)
                      Container(width: 8.5, height: 8.5, decoration: const BoxDecoration(color: C.danger, shape: BoxShape.circle))
                    else
                      const SizedBox(height: 8.5),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// 左滑露出三个操作：置顶 / 免打扰 / 删除
class SwipeCell extends StatefulWidget {
  final Widget child;
  final void Function(String action) onAction;
  const SwipeCell({super.key, required this.child, required this.onAction});

  @override
  State<SwipeCell> createState() => _SwipeCellState();
}

class _SwipeCellState extends State<SwipeCell> {
  double _dx = 0;
  bool _open = false;
  static const double _w = 216;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onHorizontalDragUpdate: (d) {
        setState(() {
          _dx = (_dx + d.delta.dx).clamp(-_w, 0);
        });
      },
      onHorizontalDragEnd: (_) {
        setState(() {
          _open = _dx < -_w / 2.4;
          _dx = _open ? -_w : 0;
        });
      },
      child: Stack(
        children: [
          Positioned.fill(
            child: Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                width: _w,
                child: Row(
                  children: [
                    _btn('置顶', const Color(0xFF9AA3B2), Icons.push_pin_rounded, 'pin'),
                    _btn('免打扰', const Color(0xFFE5A13B), Icons.notifications_off_rounded, 'mute'),
                    _btn('删除', C.danger, Icons.delete_outline_rounded, 'del'),
                  ],
                ),
              ),
            ),
          ),
          AnimatedContainer(
            duration: const Duration(milliseconds: 160),
            curve: Curves.easeOut,
            transform: Matrix4.translationValues(_dx, 0, 0),
            child: widget.child,
          ),
        ],
      ),
    );
  }

  Widget _btn(String label, Color color, IconData icon, String action) {
    return Expanded(
      child: Material(
        color: color,
        child: InkWell(
          onTap: () {
            setState(() {
              _dx = 0;
              _open = false;
            });
            widget.onAction(action);
          },
          child: SizedBox(
            height: 68,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, color: Colors.white, size: 19),
                const SizedBox(height: 3),
                Text(label, style: const TextStyle(color: Colors.white, fontSize: 11.5)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

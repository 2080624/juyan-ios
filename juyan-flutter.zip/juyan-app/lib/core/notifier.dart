/// 通知中心：前台横幅 + 后台本地通知 + 声音/震动
library;

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class InAppBanner {
  final String title;
  final String body;
  final String convId;
  final String avatar;
  final int seq;
  InAppBanner({required this.title, required this.body, this.convId = '', this.avatar = '', required this.seq});
}

/// 系统级通知的抽象：真机上由原生通道发本地通知；没通道就退化成横幅
abstract class SystemNotifier {
  Future<void> show({required String title, required String body, String convId = ''});
}

class NoopSystemNotifier implements SystemNotifier {
  @override
  Future<void> show({required String title, required String body, String convId = ''}) async {}
}

class AppNotifier {
  AppNotifier._();
  static final AppNotifier instance = AppNotifier._();

  final ValueNotifier<InAppBanner?> banner = ValueNotifier(null);
  SystemNotifier system = NoopSystemNotifier();

  /// 前台是否可见（由 main 维护）
  bool foreground = true;

  int _seq = 0;

  /// 弹一条新消息提醒。前台 → 顶部横幅；后台 → 系统本地通知
  void notify({required String title, required String body, String convId = '', String avatar = ''}) {
    _seq++;
    if (foreground) {
      banner.value = InAppBanner(title: title, body: body, convId: convId, avatar: avatar, seq: _seq);
      HapticFeedback.mediumImpact();
      SystemSound.play(SystemSoundType.alert);
    } else {
      system.show(title: title, body: body, convId: convId);
      HapticFeedback.heavyImpact();
    }
  }

  void dismiss() => banner.value = null;
}

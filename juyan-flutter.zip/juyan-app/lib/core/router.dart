/// 全局导航（真 Navigator，带 iOS 边缘滑动返回）
library;

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class Nav {
  static final GlobalKey<NavigatorState> key = GlobalKey<NavigatorState>();

  static NavigatorState? get _s => key.currentState;

  static Future<T?> push<T>(Widget page) {
    final s = _s;
    if (s == null) return Future.value(null);
    return s.push<T>(CupertinoPageRoute<T>(builder: (_) => page));
  }

  static void pop<T>([T? result]) => _s?.pop(result);

  static bool canPop() => _s?.canPop() ?? false;
}

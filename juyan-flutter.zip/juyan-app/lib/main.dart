import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core/local_notifier.dart';
import 'core/notifier.dart';
import 'core/prefs.dart';
import 'core/router.dart';
import 'core/state.dart';
import 'core/theme.dart';
import 'pages/auth.dart';
import 'pages/chat.dart';
import 'pages/shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  await Prefs.init();
  runApp(const JyApp());
}

class JyApp extends StatefulWidget {
  const JyApp({super.key});
  @override
  State<JyApp> createState() => _JyAppState();
}

class _JyAppState extends State<JyApp> with WidgetsBindingObserver {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initNotifier();
    AppState.I.boot();
  }

  Future<void> _initNotifier() async {
    final ln = LocalSystemNotifier();
    await ln.init();
    ln.onTap = (convId) {
      if (convId.isNotEmpty) Nav.push(ChatPage(convId: convId));
    };
    AppNotifier.instance.system = ln;
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    AppNotifier.instance.foreground = s == AppLifecycleState.resumed;
    if (s == AppLifecycleState.resumed) {
      AppState.I.refreshAll();
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final Widget home;
        if (st.booting) {
          home = const _Splash();
        } else if (st.user == null) {
          home = const AuthPage();
        } else if (st.banned) {
          home = const BannedPage();
        } else {
          home = const ShellPage();
        }
        return MaterialApp(
          title: '聚言商聊',
          debugShowCheckedModeBanner: false,
          navigatorKey: Nav.key,
          theme: buildTheme(),
          builder: (context, child) {
            return AnimatedBuilder(
              animation: AppNotifier.instance.banner,
              builder: (context, __) {
                final b = AppNotifier.instance.banner.value;
                return Stack(
                  children: [
                    if (child != null) child,
                    if (b != null)
                      _Banner(
                        key: ValueKey(b.seq),
                        title: b.title,
                        body: b.body,
                        onTap: () {
                          AppNotifier.instance.dismiss();
                          Nav.push(ChatPage(convId: b.convId));
                        },
                      ),
                  ],
                );
              },
            );
          },
          home: home,
        );
      },
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _Logo(),
            SizedBox(height: 14),
            Text('聚言商聊', style: TextStyle(fontSize: 17, color: C.textSub, letterSpacing: 2)),
          ],
        ),
      ),
    );
  }
}

class _Logo extends StatelessWidget {
  const _Logo();
  @override
  Widget build(BuildContext context) => const JyLogo(size: 76, radius: 22);
}

/// 前台消息横幅（从顶部滑入）
class _Banner extends StatefulWidget {
  final String title;
  final String body;
  final VoidCallback onTap;
  const _Banner({super.key, required this.title, required this.body, required this.onTap});

  @override
  State<_Banner> createState() => _BannerState();
}

class _BannerState extends State<_Banner> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 260))..forward();
  Timer? _t;

  @override
  void initState() {
    super.initState();
    _t = Timer(const Duration(seconds: 3), () {
      if (mounted) {
        _c.reverse().then((_) => AppNotifier.instance.dismiss());
      }
    });
  }

  @override
  void dispose() {
    _t?.cancel();
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final top = MediaQuery.of(context).padding.top;
    return Positioned(
      top: 0,
      left: 0,
      right: 0,
      child: SlideTransition(
        position: Tween(begin: const Offset(0, -1), end: Offset.zero).animate(CurvedAnimation(parent: _c, curve: Curves.easeOutCubic)),
        child: FadeTransition(
          opacity: _c,
          child: GestureDetector(
            onTap: widget.onTap,
            child: Container(
              margin: EdgeInsets.fromLTRB(10, top + 6, 10, 0),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(14),
                boxShadow: const [BoxShadow(color: Color(0x26000000), blurRadius: 22, offset: Offset(0, 6))],
              ),
              child: Row(
                children: [
                  Container(
                    width: 34,
                    height: 34,
                    decoration: BoxDecoration(gradient: C.brandGradient, borderRadius: BorderRadius.circular(9)),
                    child: const Icon(Icons.notifications_active_rounded, color: Colors.white, size: 19),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 2),
                        Text(widget.body, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, color: C.textSub)),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded, color: C.textMute, size: 20),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

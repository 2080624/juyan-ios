/// 会员中心 / 靓号商城
library;

import 'package:flutter/material.dart';

import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../data/models.dart';
import '../widgets/kit.dart';

class VipPage extends StatefulWidget {
  const VipPage({super.key});
  @override
  State<VipPage> createState() => _VipPageState();
}

class _VipPageState extends State<VipPage> {
  List<VipPlan> plans = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final all = await Api.I.vipPlans();
      final monthly = all.where((p) => p.period.contains('月')).toList();
      if (mounted) setState(() => plans = monthly.isEmpty ? all : monthly);
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '会员中心',
      child: loading
          ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
          : ListView(
              children: [
                Container(
                  margin: const EdgeInsets.fromLTRB(14, 16, 14, 0),
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(gradient: C.vipGradient, borderRadius: BorderRadius.circular(18), boxShadow: C.shadowFloat),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.workspace_premium_rounded, color: Colors.white, size: 34),
                          const SizedBox(width: 10),
                          Text(
                            st.isVip ? vipLabel(st.myVipLevel) : '尚未开通会员',
                            style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w700),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Text(
                        st.isVip ? '到期时间：${(st.profile?.vipExpire ?? '').split('T').first}' : '开通后立即解锁全部特权',
                        style: const TextStyle(color: Colors.white70, fontSize: 13),
                      ),
                    ],
                  ),
                ),

                const Padding(
                  padding: EdgeInsets.fromLTRB(20, 20, 20, 10),
                  child: Text('会员特权', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: GridView.count(
                    crossAxisCount: 4,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    childAspectRatio: 0.88,
                    children: [
                      _perk(Icons.group_rounded, '超大群'),
                      _perk(Icons.diamond_rounded, '靓号特权'),
                      _perk(Icons.badge_rounded, '专属标识'),
                      _perk(Icons.palette_rounded, '个性装扮'),
                      _perk(Icons.add_reaction_outlined, '更多好友'),
                      _perk(Icons.hd_rounded, '高清头像'),
                      _perk(Icons.support_agent_rounded, '优先客服'),
                      _perk(Icons.workspace_premium_outlined, '全部功能'),
                    ],
                  ),
                ),

                const Padding(
                  padding: EdgeInsets.fromLTRB(20, 22, 20, 10),
                  child: Text('开通档位', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                ),
                ...[
                  ('VIP1', '超级群 2000 人 · 好友上限提升', '￥', const Color(0xFF3F51B8)),
                  ('VIP2', '至尊群部分权限 · 更多好友', '￥￥', const Color(0xFF5C6BC0)),
                  ('VIP3', '至尊群 5000 人 · 全部特权', '￥￥￥', const Color(0xFF7C88E8)),
                ].map((t) => Container(
                      margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
                      child: Row(
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(gradient: C.vipGradient, borderRadius: BorderRadius.circular(13)),
                            child: Center(child: Text(t.$1.replaceAll('VIP', ''), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700))),
                          ),
                          const SizedBox(width: 13),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(t.$1, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                                const SizedBox(height: 3),
                                Text(t.$2, style: const TextStyle(fontSize: 12, color: C.textSub)),
                              ],
                            ),
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Text(
                                _priceOf(t.$1),
                                style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: C.vipDark),
                              ),
                              const Text('/月', style: TextStyle(fontSize: 11, color: C.textMute)),
                            ],
                          ),
                        ],
                      ),
                    )),
                const Padding(
                  padding: EdgeInsets.symmetric(horizontal: 14),
                  child: Text('开通与续费请联系官方客服，客服会为你处理', style: TextStyle(fontSize: 12, color: C.textMute)),
                ),
                const SizedBox(height: 14),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14),
                  child: PrimaryButton(
                    text: '联系客服开通',
                    gradient: C.vipGradient,
                    onTap: () => st.openOfficial(draft: '你好，我想开通会员'),
                  ),
                ),
                const SizedBox(height: 12),
                Center(
                  child: TextButton(
                    onPressed: () => Nav.push(const VipRulesPage()),
                    child: const Text('会员权益说明', style: TextStyle(fontSize: 13, color: C.textSub)),
                  ),
                ),
                const SizedBox(height: 30),
              ],
            ),
    );
  }

  String _priceOf(String tier) {
    final hit = plans.where((p) => p.tier.toUpperCase().contains(tier)).toList();
    if (hit.isEmpty) return '—';
    return '￥${(hit.first.price / 100).toStringAsFixed(0)}';
  }

  Widget _perk(IconData icon, String label) => Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(color: const Color(0xFFF0F2FA), borderRadius: BorderRadius.circular(13)),
            child: Icon(icon, color: C.vipDark, size: 22),
          ),
          const SizedBox(height: 6),
          Text(label, style: const TextStyle(fontSize: 11.5, color: C.textSub)),
        ],
      );
}

class VipRulesPage extends StatelessWidget {
  const VipRulesPage({super.key});
  @override
  Widget build(BuildContext context) => PageScaffold(
        title: '会员权益说明',
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: const [
            Text('会员档位', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            SizedBox(height: 8),
            Text('· VIP1：可创建超级群（2000 人），好友上限提升\n· VIP2：在 VIP1 基础上进一步提升好友上限\n· VIP3：可创建至尊群（5000 人），解锁全部特权',
                style: TextStyle(fontSize: 14, height: 1.9, color: C.textSub)),
            SizedBox(height: 20),
            Text('有效期', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            SizedBox(height: 8),
            Text('会员按 30 天为一期，到期后自动失效，可在到期前随时续费叠加。',
                style: TextStyle(fontSize: 14, height: 1.9, color: C.textSub)),
            SizedBox(height: 20),
            Text('如何开通', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            SizedBox(height: 8),
            Text('在会员中心点「联系客服开通」，客服会向你确认档位并为你开通。',
                style: TextStyle(fontSize: 14, height: 1.9, color: C.textSub)),
            SizedBox(height: 20),
            Text('温馨提示', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
            SizedBox(height: 8),
            Text('会员属于虚拟商品，开通后不支持退款，请确认后再购买。',
                style: TextStyle(fontSize: 14, height: 1.9, color: C.textSub)),
          ],
        ),
      );
}

/* ------------------------------- 靓号商城 ------------------------------ */

class LuckyPage extends StatefulWidget {
  const LuckyPage({super.key});
  @override
  State<LuckyPage> createState() => _LuckyPageState();
}

class _LuckyPageState extends State<LuckyPage> {
  List<LuckyNumber> list = [];
  String tier = 'all';
  bool loading = true;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.I.luckyShop();
      if (mounted) setState(() => list = l.where((x) => !x.taken && x.status != 'off').toList());
    } catch (_) {}
    if (mounted) setState(() => loading = false);
  }

  static const tiers = [
    ('all', '全部'),
    ('flat', '平价'),
    ('fine', '精选'),
    ('best', '精品'),
    ('top', '极品'),
    ('leopard', '豹子号'),
  ];

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final shown = tier == 'all' ? list : list.where((x) => x.tier == tier).toList();
    return PageScaffold(
      title: '靓号商城',
      actions: [
        TextButton(
          onPressed: () async {
            final v = await promptDialog(context, '搜索靓号', hint: '输入号码');
            if (v == null || v.isEmpty) return;
            setState(() {
              list = list.where((x) => x.number.contains(v)).toList();
            });
          },
          child: const Text('搜索'),
        ),
      ],
      child: Column(
        children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              children: tiers
                  .map((t) => Padding(
                        padding: const EdgeInsets.only(right: 8, top: 8, bottom: 8),
                        child: ChoiceChip(
                          label: Text(t.$2, style: TextStyle(fontSize: 13, color: tier == t.$1 ? Colors.white : C.textSub)),
                          selected: tier == t.$1,
                          selectedColor: C.primary,
                          backgroundColor: Colors.white,
                          showCheckmark: false,
                          onSelected: (_) => setState(() => tier = t.$1),
                        ),
                      ))
                  .toList(),
            ),
          ),
          Expanded(
            child: loading
                ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
                : shown.isEmpty
                    ? const Empty(text: '这个档位暂时没有号码', icon: Icons.diamond_outlined)
                    : GridView.builder(
                        padding: const EdgeInsets.all(14),
                        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: 2,
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          childAspectRatio: 1.55,
                        ),
                        itemCount: shown.length,
                        itemBuilder: (context, i) {
                          final n = shown[i];
                          return Container(
                            padding: const EdgeInsets.all(14),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(14),
                              boxShadow: C.shadow,
                              border: Border.all(color: n.hot ? const Color(0xFFE5A13B) : C.divider, width: n.hot ? 1.4 : 1),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Text(n.number, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: n.hot ? const Color(0xFFE5A13B) : C.textMain)),
                                    if (n.hot) ...[
                                      const SizedBox(width: 5),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                                        decoration: BoxDecoration(color: const Color(0xFFE5A13B), borderRadius: BorderRadius.circular(3)),
                                        child: const Text('热', style: TextStyle(color: Colors.white, fontSize: 9)),
                                      ),
                                    ],
                                  ],
                                ),
                                const Spacer(),
                                Row(
                                  children: [
                                    Text('¥${(n.price / 100).toStringAsFixed(0)}', style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: C.primary)),
                                    const Spacer(),
                                    SizedBox(
                                      height: 30,
                                      child: ElevatedButton(
                                        onPressed: busy
                                            ? null
                                            : () async {
                                                setState(() => busy = true);
                                                try {
                                                  await Api.I.buyLucky(n.id);
                                                  await st.refreshProfile();
                                                  await _load();
                                                  st.say('购买成功，靓号已生效');
                                                } catch (e) {
                                                  st.say(e is ApiException ? (e.message.isEmpty ? '购买失败，余额不足？' : e.message) : '购买失败');
                                                }
                                                setState(() => busy = false);
                                              },
                                        style: ElevatedButton.styleFrom(backgroundColor: C.primary, foregroundColor: Colors.white, elevation: 0, padding: const EdgeInsets.symmetric(horizontal: 12)),
                                        child: const Text('购买', style: TextStyle(fontSize: 12.5)),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}

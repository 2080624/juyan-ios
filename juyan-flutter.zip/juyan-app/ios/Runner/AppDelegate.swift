import Flutter
import UIKit

@main
@objc class AppDelegate: FlutterAppDelegate, FlutterImplicitEngineDelegate {

  /// 退到后台后申请的一段后台执行时间：让消息轮询多跑一会儿，
  /// 这段时间内收到新消息照样能弹出系统通知。
  private var bgTask: UIBackgroundTaskIdentifier = .invalid

  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }

  func didInitializeImplicitFlutterEngine(_ engineBridge: FlutterImplicitEngineBridge) {
    GeneratedPluginRegistrant.register(with: engineBridge.pluginRegistry)
  }

  override func applicationDidEnterBackground(_ application: UIApplication) {
    super.applicationDidEnterBackground(application)
    endBgTask(application)
    bgTask = application.beginBackgroundTask(withName: "jy-poll") { [weak self] in
      guard let self = self else { return }
      self.endBgTask(application)
    }
  }

  override func applicationWillEnterForeground(_ application: UIApplication) {
    super.applicationWillEnterForeground(application)
    endBgTask(application)
  }

  override func applicationDidBecomeActive(_ application: UIApplication) {
    super.applicationDidBecomeActive(application)
    endBgTask(application)
  }

  private func endBgTask(_ application: UIApplication) {
    if bgTask != .invalid {
      application.endBackgroundTask(bgTask)
      bgTask = .invalid
    }
  }
}

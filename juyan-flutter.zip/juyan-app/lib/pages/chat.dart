/// 聊天页（单聊 / 群聊，全消息类型）
library;

import 'dart:async';
import 'dart:io';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

import '../core/prefs.dart';
import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../data/models.dart';
import '../widgets/kit.dart';
import 'chat_info.dart';
import 'friend.dart';
import 'misc.dart';
import 'group.dart';
import 'packet.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

class ChatPage extends StatefulWidget {
  final String convId;
  final String draft;
  final bool autoSend;
  const ChatPage({super.key, required this.convId, this.draft = '', this.autoSend = false});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final st = AppState.I;
  final input = TextEditingController();
  final scroll = ScrollController();
  final focus = FocusNode();

  Conversation? conv;
  List<Message> msgs = [];
  bool loading = true;
  bool sending = false;
  Timer? _timer;

  int panel = 0; // 0 无 / 1 表情 / 2 加号
  Message? replyTo;
  String typingPeer = '';
  bool showNotice = true;

  AudioPlayer? _player;
  final _recorder = AudioRecorder();
  bool _recording = false;
  DateTime? _recStart;

  @override
  void initState() {
    super.initState();
    _load();
    _timer = Timer.periodic(const Duration(milliseconds: 2500), (_) => _poll());
    _player = AudioPlayer();
    if (widget.draft.isNotEmpty) {
      input.text = widget.draft;
      if (widget.autoSend) {
        WidgetsBinding.instance.addPostFrameCallback((_) => _sendText());
      }
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    input.dispose();
    scroll.dispose();
    focus.dispose();
    _player?.dispose();
    _recorder.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final c = await Api.I.conversationById(widget.convId);
      setState(() => conv = c);
    } catch (_) {
      final local = st.convos.where((x) => x.id == widget.convId).toList();
      if (local.isNotEmpty) setState(() => conv = local.first);
    }
    await _fetchMsgs();
    setState(() => loading = false);
    st.markRead(widget.convId);
    _toBottom();
  }

  Future<void> _fetchMsgs() async {
    try {
      final list = await Api.I.messages(widget.convId, perPage: 80);
      if (!mounted) return;
      final grew = list.length != msgs.length;
      setState(() {
        msgs = list;
        if (conv != null && conv!.isGroup) showNotice = conv!.notice.isNotEmpty;
      });
      if (grew) _toBottom();
      await _loadPeers();
    } catch (_) {}
  }

  Future<void> _loadPeers() async {
    final ids = <String>{};
    if (conv != null) ids.addAll(conv!.members);
    for (final m in msgs) {
      ids.add(m.sender);
    }
    ids.remove(st.user?.id ?? '');
    final missing = ids.where((e) => !st.people.containsKey(e)).toList();
    if (missing.isNotEmpty) {
      final got = await Api.I.profilesByIds(missing);
      st.people.addAll(got);
    }
  }

  Future<void> _poll() async {
    if (!mounted) return;
    if (AppState.I.booting) return;
    await _fetchMsgs();
    if (Prefs.typingOn && conv != null && !conv!.isGroup) {
      final peer = conv!.members.firstWhere((m) => m != st.user?.id, orElse: () => '');
      if (peer.isNotEmpty) {
        try {
          final r = await Api.I.typingGet(widget.convId, peer);
          final on = r['on'] == true;
          if (mounted && on != (typingPeer.isNotEmpty)) setState(() => typingPeer = on ? '对方正在输入…' : '');
        } catch (_) {}
      }
    }
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (scroll.hasClients) {
        scroll.animateTo(scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
      }
    });
  }

  /* ------------------------------- 发送 ------------------------------- */

  Future<void> _sendText() async {
    final text = input.text.trim();
    if (text.isEmpty || sending || st.user == null || conv == null) return;
    setState(() => sending = true);
    final q = replyTo?.text ?? '';
    input.clear();
    setState(() => replyTo = null);
    try {
      final mentions = _parseMentions(text);
      await Api.I.postMessage(
        convId: widget.convId,
        senderId: st.user!.id,
        kind: 'text',
        text: text,
        quote: q,
        mentions: mentions,
      );
      await _fetchMsgs();
      await st.refreshAll();
    } catch (e) {
      st.say('发送失败，检查一下网络');
    }
    setState(() => sending = false);
    _toBottom();
  }

  List<String> _parseMentions(String text) {
    if (conv == null || !conv!.isGroup) return const [];
    final out = <String>[];
    for (final uid in conv!.members) {
      final nick = st.displayOf(uid);
      if (nick.isNotEmpty && text.contains('@$nick')) out.add(uid);
    }
    return out;
  }

  Future<void> _sendImage() async {
    final picker = ImagePicker();
    final f = await picker.pickImage(source: ImageSource.gallery, imageQuality: 82, maxWidth: 1600);
    if (f == null) return;
    setState(() => sending = true);
    try {
      await Api.I.postMessage(
        convId: widget.convId,
        senderId: st.user!.id,
        kind: 'image',
        text: '[图片]',
        file: File(f.path),
        field: 'image',
      );
      await _fetchMsgs();
      await st.refreshAll();
    } catch (_) {
      st.say('图片发送失败');
    }
    setState(() => sending = false);
    _toBottom();
  }

  Future<void> _sendCamera() async {
    final picker = ImagePicker();
    final f = await picker.pickImage(source: ImageSource.camera, imageQuality: 82, maxWidth: 1600);
    if (f == null) return;
    setState(() => sending = true);
    try {
      await Api.I.postMessage(
        convId: widget.convId,
        senderId: st.user!.id,
        kind: 'image',
        text: '[图片]',
        file: File(f.path),
        field: 'image',
      );
      await _fetchMsgs();
    } catch (_) {}
    setState(() => sending = false);
    _toBottom();
  }

  Future<void> _toggleRecord() async {
    if (_recording) {
      final path = await _recorder.stop();
      final secs = _recStart == null ? 1 : DateTime.now().difference(_recStart!).inSeconds.clamp(1, 60);
      setState(() => _recording = false);
      if (path == null) return;
      setState(() => sending = true);
      try {
        await Api.I.postMessage(
          convId: widget.convId,
          senderId: st.user!.id,
          kind: 'audio',
          text: '[语音]',
          file: File(path),
          field: 'audio',
          meta: {'secs': secs},
        );
        await _fetchMsgs();
      } catch (_) {
        st.say('语音发送失败');
      }
      setState(() => sending = false);
      return;
    }
    if (!await _recorder.hasPermission()) {
      st.say('没有麦克风权限');
      return;
    }
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/jy_${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _recorder.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
    _recStart = DateTime.now();
    setState(() => _recording = true);
    HapticFeedback.mediumImpact();
  }

  Future<void> _playAudio(Message m) async {
    final url = msgAudioUrl(m);
    if (url.isEmpty) return;
    try {
      if (_player!.state == PlayerState.playing) await _player!.stop();
      await _player!.play(UrlSource(url));
    } catch (_) {}
  }

  /* ------------------------------ 长按菜单 ----------------------------- */

  Future<void> _longPress(Message m) async {
    final mine = m.sender == st.user?.id;
    final isGroup = conv?.isGroup ?? false;
    await showSheet(context, children: [
      if (m.kind == 'text')
        SheetItem(text: '复制', icon: LucideIcons.copy, onTap: () async {
          await Clipboard.setData(ClipboardData(text: m.text));
          st.say('已复制');
        }),
      SheetItem(text: '引用', icon: LucideIcons.quote, onTap: () => setState(() => replyTo = m)),
      SheetItem(text: '收藏', icon: LucideIcons.star, onTap: () async {
        await Api.I.addFavorite(st.user!.id, m.kind == 'text' ? m.text : '[${_kindName(m.kind)}]', widget.convId).catchError((_) {});
        st.say('已收藏');
      }),
      SheetItem(text: '转发', icon: LucideIcons.share2, onTap: () => _forward(m)),
      if (mine)
        SheetItem(text: '撤回', icon: LucideIcons.rotateCcw, color: C.danger, onTap: () async {
          await Api.I.msgRecall(m.id).catchError((_) {});
          await _fetchMsgs();
          st.say('已撤回');
        }),
      if (!mine || isGroup)
        SheetItem(text: '删除这条', icon: LucideIcons.trash2, color: C.danger, onTap: () async {
          await Api.I.deleteMessage(m.id).catchError((_) {});
          await _fetchMsgs();
        }),
    ]);
  }

  void _forward(Message m) {
    Nav.push(ForwardPage(msg: m));
  }

  String _kindName(String k) => switch (k) {
        'image' => '图片',
        'audio' => '语音',
        'file' => '文件',
        'gift' => '礼物',
        'transfer' => '转账',
        'call' => '通话',
        _ => '消息',
      };

  void _openInfo() {
    if (conv == null) return;
    if (conv!.isGroup) {
      Nav.push(GroupInfoPage(convId: conv!.id));
    } else {
      Nav.push(ChatInfoPage(convId: conv!.id));
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        final c = conv;
        final title = c == null ? '聊天' : st.titleOf(c);
        final peerId = c == null || c.isGroup ? '' : c.members.firstWhere((m) => m != st.user?.id, orElse: () => '');
        final peerRed = peerId.isNotEmpty && st.redOf(peerId);
        final peerVip = peerId.isEmpty ? '' : st.vipOf(peerId);
        final subtitle = c == null
            ? ''
            : c.isGroup
                ? '${c.members.length} 人'
                : (typingPeer.isNotEmpty ? typingPeer : (st.onlineOf(peerId) ? '在线' : ''));

        return Scaffold(
          backgroundColor: C.chatBg,
          appBar: AppBar(
            centerTitle: true,
            titleSpacing: 0,
            title: GestureDetector(
              onTap: _openInfo,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Flexible(
                        child: Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                            color: c != null && c.isGroup ? groupNameColor(c.groupType) : (peerRed ? C.redName : C.textMain),
                          ),
                        ),
                      ),
                      if (c != null && c.isGroup)
                        GroupTags(lucky: st.isGroupLucky(c.groupNo), groupType: c.groupType)
                      else if (c != null)
                        NameTags(red: peerRed, vip: peerVip),
                    ],
                  ),
                  if (subtitle.isNotEmpty)
                    Text(subtitle, style: TextStyle(fontSize: 11.5, color: typingPeer.isNotEmpty ? C.primary : C.textSub)),
                ],
              ),
            ),
            actions: [
              IconButton(icon: const Icon(LucideIcons.moreHorizontal), onPressed: _openInfo),
              const SizedBox(width: 4),
            ],
          ),
          body: loading
              ? const Center(child: CircularProgressIndicator(strokeWidth: 2))
              : Column(
                  children: [
                    if (c != null && c.isGroup && c.notice.isNotEmpty && showNotice)
                      _NoticeBar(
                        text: c.notice,
                        onClose: () => setState(() => showNotice = false),
                        onOpen: () => Nav.push(NoticeViewPage(convId: c.id)),
                      ),
                    Expanded(
                      child: GestureDetector(
                        onTap: () {
                          if (panel != 0) setState(() => panel = 0);
                          focus.unfocus();
                        },
                        child: ListView.builder(
                          controller: scroll,
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          itemCount: msgs.length,
                          itemBuilder: (context, i) {
                            final m = msgs[i];
                            final prev = i > 0 ? msgs[i - 1] : null;
                            final showTime = prev == null ||
                                DateTime.tryParse(m.created)?.difference(DateTime.tryParse(prev.created) ?? DateTime.now()).inMinutes.abs() != null &&
                                    (DateTime.tryParse(m.created)?.difference(DateTime.tryParse(prev.created)!).inMinutes ?? 0).abs() >= 5;
                            return Column(
                              children: [
                                if (showTime) _TimeChip(text: fmtChatTime(m.created)),
                                _Bubble(
                                  msg: m,
                                  mine: m.sender == st.user?.id,
                                  isGroup: c?.isGroup ?? false,
                                  senderName: st.displayOf(m.sender, fallback: ''),
                                  redSender: st.redOf(m.sender),
                                  senderVip: st.vipOf(m.sender),
                                  avatar: st.avatarOf(m.sender),
                                  onLongPress: () => _longPress(m),
                                  onAvatar: () {
                                    if (m.sender != st.user?.id) Nav.push(UserProfilePage(userId: m.sender));
                                  },
                                  onPlay: () => _playAudio(m),
                                  onOpenPacket: () => Nav.push(PacketPage(msgId: m.id)),
                                  mentionMe: m.mentions.contains(st.user?.id),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ),
                    if (replyTo != null)
                      Container(
                        color: Colors.white,
                        padding: const EdgeInsets.fromLTRB(14, 8, 8, 8),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text('引用：${replyTo!.kind == 'text' ? replyTo!.text : '[' + _kindName(replyTo!.kind) + ']'}',
                                  maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, color: C.textSub)),
                            ),
                            IconButton(icon: const Icon(LucideIcons.x, size: 18), onPressed: () => setState(() => replyTo = null)),
                          ],
                        ),
                      ),
                    _InputBar(
                      controller: input,
                      focus: focus,
                      panel: panel,
                      sending: sending,
                      recording: _recording,
                      onPanel: (p) {
                        setState(() => panel = panel == p ? 0 : p);
                        if (panel != 0) focus.unfocus();
                      },
                      onSend: _sendText,
                      onVoice: _toggleRecord,
                      onImage: _sendImage,
                      onCamera: _sendCamera,
                      onMention: _pickMention,
                      onTransfer: () => Nav.push(TransferSheet(convId: widget.convId)),
                      onGift: () => Nav.push(GiftSheet(convId: widget.convId)),
                      onAddSticky: _addSticky,
                      stickies: _stickies,
                    ),
                  ],
                ),
        );
      },
    );
  }

  List<Sticky> _stickies = [];

  Future<void> _addSticky() async {
    final picker = ImagePicker();
    final f = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 400);
    if (f == null) return;
    try {
      await Api.I.addSticky(st.user!.id, File(f.path));
      await _refreshStickies();
      st.say('已添加表情');
    } catch (_) {}
  }

  Future<void> _refreshStickies() async {
    try {
      final list = await Api.I.myStickies(st.user!.id);
      if (mounted) setState(() => _stickies = list);
    } catch (_) {}
  }

  Future<void> _pickMention() async {
    final c = conv;
    if (c == null || !c.isGroup) return;
    final picked = await showSheet<String>(
      context,
      title: '选择要 @ 的人',
      children: c.members
          .where((m) => m != st.user?.id)
          .map((m) => SheetItem(
                text: st.displayOf(m),
                icon: LucideIcons.atSign,
                onTap: () => Nav.pop(st.displayOf(m)),
              ))
          .toList(),
    );
    if (picked != null && picked.isNotEmpty) {
      final t = input.text;
      input.text = t.isEmpty ? '@$picked ' : '$t @$picked ';
      input.selection = TextSelection.collapsed(offset: input.text.length);
    }
  }
}

/* -------------------------------- 公告条 -------------------------------- */

class _NoticeBar extends StatelessWidget {
  final String text;
  final VoidCallback onClose;
  final VoidCallback onOpen;
  const _NoticeBar({required this.text, required this.onClose, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFFFF8E6),
      padding: const EdgeInsets.fromLTRB(14, 9, 8, 9),
      child: Row(
        children: [
          const Icon(LucideIcons.megaphone, size: 16, color: Color(0xFFB8860B)),
          const SizedBox(width: 7),
          Expanded(
            child: GestureDetector(
              onTap: onOpen,
              child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, color: Color(0xFF8A6D1B))),
            ),
          ),
          IconButton(icon: const Icon(LucideIcons.x, size: 16, color: Color(0xFFB8860B)), onPressed: onClose),
        ],
      ),
    );
  }
}

class _TimeChip extends StatelessWidget {
  final String text;
  const _TimeChip({required this.text});
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Center(
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 2.5),
            decoration: BoxDecoration(color: const Color(0x1A000000), borderRadius: BorderRadius.circular(5)),
            child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 11)),
          ),
        ),
      );
}

/* -------------------------------- 消息气泡 ------------------------------- */

class _Bubble extends StatelessWidget {
  final Message msg;
  final bool mine;
  final bool isGroup;
  final String senderName;
  final bool redSender;
  final String senderVip;
  final String avatar;
  final VoidCallback onLongPress;
  final VoidCallback onAvatar;
  final VoidCallback onPlay;
  final VoidCallback onOpenPacket;
  final bool mentionMe;

  const _Bubble({
    required this.msg,
    required this.mine,
    required this.isGroup,
    required this.senderName,
    this.redSender = false,
    this.senderVip = '',
    required this.avatar,
    required this.onLongPress,
    required this.onAvatar,
    required this.onPlay,
    required this.onOpenPacket,
    this.mentionMe = false,
  });

  @override
  Widget build(BuildContext context) {
    if (msg.isSys) {
      final t = msg.metaMap['text'] ?? msg.text;
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 40),
        child: Center(
          child: Text('$t', textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5, color: C.textMute)),
        ),
      );
    }

    final showName = isGroup && !mine;
    final body = _body(context);

    return Padding(
      padding: EdgeInsets.fromLTRB(12, 4, 12, 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: mine ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!mine)
            GestureDetector(onTap: onAvatar, child: Avatar(url: avatar, name: senderName, size: 40, radius: 11)),
          if (!mine) const SizedBox(width: 9),
          Flexible(
            child: Column(
              crossAxisAlignment: mine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
              children: [
                if (showName)
                  Padding(
                    padding: const EdgeInsets.only(left: 3, bottom: 3),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          senderName,
                          style: TextStyle(fontSize: 11.5, color: redSender ? C.redName : C.textMute),
                        ),
                        NameTags(red: redSender, vip: senderVip, scale: 0.9),
                      ],
                    ),
                  ),
                if (mentionMe && !mine)
                  Container(
                    margin: const EdgeInsets.only(bottom: 3),
                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
                    decoration: BoxDecoration(color: const Color(0x1AE5484D), borderRadius: BorderRadius.circular(4)),
                    child: const Text('有人 @ 你', style: TextStyle(fontSize: 10, color: C.danger)),
                  ),
                GestureDetector(
                  onLongPress: onLongPress,
                  child: Container(
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.68),
                    decoration: BoxDecoration(
                      color: mine ? C.bubbleMine : C.bubbleOther,
                      borderRadius: BorderRadius.only(
                        topLeft: const Radius.circular(14),
                        topRight: const Radius.circular(14),
                        bottomLeft: Radius.circular(mine ? 14 : 4),
                        bottomRight: Radius.circular(mine ? 4 : 14),
                      ),
                      boxShadow: const [BoxShadow(color: Color(0x0A000000), blurRadius: 3, offset: Offset(0, 1))],
                    ),
                    padding: msg.kind == 'image' ? EdgeInsets.zero : const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                    child: body,
                  ),
                ),
                if (mine && !isGroup)
                  Padding(
                    padding: const EdgeInsets.only(top: 3, right: 3),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(fmtTime(msg.created), style: const TextStyle(fontSize: 10, color: C.textMute)),
                        const SizedBox(width: 4),
                        Icon(
                          msg.read ? LucideIcons.checkCheck : LucideIcons.check,
                          size: 13,
                          color: msg.read ? C.green : C.textMute,
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
          if (mine) const SizedBox(width: 9),
          if (mine) Avatar(url: AppState.I.myAvatar, name: AppState.I.displayName, size: 40, radius: 11),
        ],
      ),
    );
  }

  Widget _body(BuildContext context) {
    switch (msg.kind) {
      case 'image':
        final url = msgImageUrl(msg);
        return ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: GestureDetector(
            onTap: () => Nav.push(ImageViewerPage(url: url)),
            child: Prefs.autoImg
                ? RemoteImg(url: url, width: 180, height: 180, fit: BoxFit.cover)
                : Container(
                    width: 180,
                    height: 100,
                    color: const Color(0x22000000),
                    child: const Center(child: Text('点击查看图片', style: TextStyle(color: Colors.white, fontSize: 12))),
                  ),
          ),
        );
      case 'audio':
        final secs = msg.metaMap['secs'] ?? 4;
        return GestureDetector(
          onTap: onPlay,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(LucideIcons.circlePlay, size: 20, color: mine ? Colors.white : C.primary),
              const SizedBox(width: 8),
              SizedBox(
                width: (int.tryParse('$secs') ?? 4) * 3.0 + 34,
                child: Container(height: 3, decoration: BoxDecoration(color: mine ? Colors.white38 : C.divider, borderRadius: BorderRadius.circular(3))),
              ),
              const SizedBox(width: 6),
              Text("$secs''", style: TextStyle(fontSize: 12, color: mine ? Colors.white : C.textMain)),
            ],
          ),
        );
      case 'gift':
        final meta = msg.metaMap;
        return _card(
          icon: LucideIcons.gift,
          iconBg: const Color(0xFFE5A13B),
          title: '${meta['title'] ?? '礼物'}',
          desc: '${meta['desc'] ?? ''}',
          price: int.tryParse('${meta['price'] ?? 0}') ?? 0,
          tap: onOpenPacket,
        );
      case 'transfer':
        final meta = msg.metaMap;
        final state = '${meta['st'] ?? ''}';
        return _card(
          icon: LucideIcons.wallet,
          iconBg: C.primary,
          title: '转账 ¥${meta['amount'] ?? 0}',
          desc: state == 'received' ? '已收款' : state == 'back' ? '已退回' : '待对方收款',
          price: int.tryParse('${meta['amount'] ?? 0}') ?? 0,
          tap: onOpenPacket,
        );
      case 'call':
        final meta = msg.metaMap;
        final secs = int.tryParse('${meta['secs'] ?? 0}') ?? 0;
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon((meta['video'] == true) ? LucideIcons.video : LucideIcons.phone, size: 17, color: mine ? Colors.white : C.textSub),
            const SizedBox(width: 7),
            Text(
              secs > 0 ? '通话时长 ${_dur(secs)}' : '已取消',
              style: TextStyle(fontSize: 14, color: mine ? Colors.white : C.textMain),
            ),
          ],
        );
      default:
        return Text(
          msg.text,
          style: TextStyle(fontSize: 15.5, height: 1.35, color: mine ? Colors.white : C.textMain),
        );
    }
  }

  static String _dur(int s) => s >= 60 ? '${s ~/ 60}分${s % 60}秒' : '$s秒';

  Widget _card({required IconData icon, required Color iconBg, required String title, required String desc, required int price, required VoidCallback tap}) {
    final fg = mine ? Colors.white : C.textMain;
    return GestureDetector(
      onTap: tap,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(color: iconBg, borderRadius: BorderRadius.circular(10)),
            child: Icon(icon, color: Colors.white, size: 21),
          ),
          const SizedBox(width: 11),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(title, style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600, color: fg)),
              const SizedBox(height: 2),
              Text(desc, style: TextStyle(fontSize: 11.5, color: mine ? Colors.white70 : C.textSub)),
            ],
          ),
        ],
      ),
    );
  }
}

/* -------------------------------- 输入栏 -------------------------------- */

class _InputBar extends StatelessWidget {
  final TextEditingController controller;
  final FocusNode focus;
  final int panel;
  final bool sending;
  final bool recording;
  final void Function(int) onPanel;
  final VoidCallback onSend;
  final VoidCallback onVoice;
  final VoidCallback onImage;
  final VoidCallback onCamera;
  final VoidCallback onMention;
  final VoidCallback onTransfer;
  final VoidCallback onGift;
  final VoidCallback onAddSticky;
  final List<Sticky> stickies;

  const _InputBar({
    required this.controller,
    required this.focus,
    required this.panel,
    required this.sending,
    required this.recording,
    required this.onPanel,
    required this.onSend,
    required this.onVoice,
    required this.onImage,
    required this.onCamera,
    required this.onMention,
    required this.onTransfer,
    required this.onGift,
    required this.onAddSticky,
    required this.stickies,
  });

  static const emojis = [
    '😀','😄','😁','😆','😅','😂','🙂','😉','😊','😍','🥰','😘','😗','😙','😚','😋',
    '😛','😝','😜','🤪','🤨','🧐','🤓','😎','🥳','😏','😒','😞','😔','😟','😕','🙁',
    '😣','😖','😫','😩','🥺','😢','😭','😤','😠','😡','🤬','🤯','😳','🥵','🥶','😱',
    '😨','😰','😥','😓','🤗','🤔','🤭','🤫','🤥','😶','😐','😑','😬','🙄','😯','😦',
    '👍','👎','👌','✌️','🤞','🤟','🤘','🤙','👈','👉','👆','👇','✋','🤚','🖐','👋',
    '🙏','🤝','💪','🦾','❤️','💔','💯','🔥','✨','🎉','🎁','🌹','🍺','🍻','☕','🍰',
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: C.divider, width: 0.6)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                IconButton(
                  icon: Icon(recording ? LucideIcons.mic : LucideIcons.mic, size: 24, color: recording ? C.danger : C.textSub),
                  onPressed: onVoice,
                ),
                Expanded(
                  child: Container(
                    constraints: const BoxConstraints(minHeight: 38, maxHeight: 110),
                    decoration: BoxDecoration(color: C.surfaceHover, borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    child: TextField(
                      controller: controller,
                      focusNode: focus,
                      maxLines: null,
                      minLines: 1,
                      textInputAction: Prefs.enterToSend ? TextInputAction.send : TextInputAction.newline,
                      keyboardType: TextInputType.multiline,
                      onSubmitted: (_) {
                        if (Prefs.enterToSend) onSend();
                      },
                      onTap: () => onPanel(0),
                      style: const TextStyle(fontSize: 15.5),
                      decoration: const InputDecoration(
                        hintText: '',
                        filled: false,
                        border: InputBorder.none,
                        enabledBorder: InputBorder.none,
                        focusedBorder: InputBorder.none,
                        isDense: true,
                        contentPadding: EdgeInsets.symmetric(vertical: 9),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(LucideIcons.smile, size: 24, color: C.textSub),
                  onPressed: () => onPanel(1),
                ),
                IconButton(
                  icon: const Icon(LucideIcons.circlePlus, size: 24, color: C.textSub),
                  onPressed: () => onPanel(2),
                ),
                if (!Prefs.enterToSend)
                  TextButton(
                    onPressed: sending ? null : onSend,
                    child: const Text('发送', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600)),
                  ),
              ],
            ),
          ),
          if (recording)
            Container(
              color: const Color(0x1AE5484D),
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(LucideIcons.mic, color: C.danger, size: 18),
                  SizedBox(width: 8),
                  Text('正在录音，再点一次麦克风发送', style: TextStyle(fontSize: 13, color: C.danger)),
                ],
              ),
            ),
          AnimatedSize(
            duration: const Duration(milliseconds: 180),
            child: panel == 0
                ? const SizedBox(width: double.infinity)
                : SizedBox(
                    height: 232,
                    child: panel == 1 ? _emojiPanel(context) : _plusPanel(context),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _emojiPanel(BuildContext context) {
    return Column(
      children: [
        if (stickies.isNotEmpty)
          SizedBox(
            height: 62,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              children: [
                for (final s in stickies)
                  GestureDetector(
                    onTap: () {
                      controller.text = '${controller.text}[表情]';
                    },
                    child: Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: RemoteImg(url: stickyUrl(s), width: 48, height: 48, fit: BoxFit.cover),
                    ),
                  ),
              ],
            ),
          ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Row(
            children: [
              const Text('表情', style: TextStyle(fontSize: 12.5, color: C.textSub)),
              const Spacer(),
              TextButton.icon(
                onPressed: onAddSticky,
                icon: const Icon(LucideIcons.imagePlus, size: 17),
                label: const Text('加表情', style: TextStyle(fontSize: 12.5)),
              ),
            ],
          ),
        ),
        Expanded(
          child: GridView.count(
            crossAxisCount: 8,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              for (final e in emojis)
                InkWell(
                  onTap: () {
                    controller.text = controller.text + e;
                    controller.selection = TextSelection.collapsed(offset: controller.text.length);
                  },
                  child: Center(child: Text(e, style: const TextStyle(fontSize: 23))),
                ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _plusPanel(BuildContext context) {
    final items = <(IconData, String, VoidCallback, Color)>[
      (LucideIcons.image, '照片', onImage, const Color(0xFF4C9AFF)),
      (LucideIcons.camera, '拍摄', onCamera, const Color(0xFF26B36B)),
      (LucideIcons.atSign, '@ 提醒', onMention, const Color(0xFF7C88E8)),
      (LucideIcons.wallet, '转账', onTransfer, const Color(0xFFE5A13B)),
      (LucideIcons.gift, '礼物', onGift, const Color(0xFFE5484D)),
      (LucideIcons.folderOpen, '文件', () {}, const Color(0xFF9AA3B2)),
      (LucideIcons.star, '收藏', () {}, const Color(0xFFB8860B)),
      (LucideIcons.phone, '通话', () {}, const Color(0xFF16A3B8)),
    ];
    return GridView.count(
      crossAxisCount: 4,
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
      childAspectRatio: 1.15,
      children: [
        for (final it in items)
          InkWell(
            onTap: it.$3,
            borderRadius: BorderRadius.circular(12),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(color: it.$4.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(14)),
                  child: Icon(it.$1, color: it.$4, size: 24),
                ),
                const SizedBox(height: 6),
                Text(it.$2, style: const TextStyle(fontSize: 11.5, color: C.textSub)),
              ],
            ),
          ),
      ],
    );
  }
}

package com.juyan.juyan_chat

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

/// 好友：加好友 / 新朋友 / 资料页 / 二维码 / 扫一扫 / 名片 / 建群
library;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qr_flutter/qr_flutter.dart';

import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/api.dart';
import '../data/models.dart';
import '../widgets/kit.dart';
import 'chat.dart';
import 'group.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

/* ------------------------------- 加好友 ------------------------------- */

class AddFriendPage extends StatefulWidget {
  const AddFriendPage({super.key});
  @override
  State<AddFriendPage> createState() => _AddFriendPageState();
}

class _AddFriendPageState extends State<AddFriendPage> {
  final ctl = TextEditingController();
  List<Profile> users = [];
  List<SearchGroup> groups = [];
  bool busy = false;
  bool searched = false;

  Future<void> _search() async {
    final q = ctl.text.trim();
    if (q.isEmpty) return;
    setState(() {
      busy = true;
      searched = true;
    });
    try {
      final r = await Api.I.searchExact(q);
      final u = asList(r['users']).map(SearchUser.from).toList();
      final g = asList(r['groups']).map(SearchGroup.from).toList();
      final profiles = <Profile>[];
      for (final x in u) {
        final p = x.profile.isNotEmpty ? await Api.I.profileOf(x.user) : null;
        profiles.add(p ??
            Profile(
              id: '',
              user: x.user,
              nickname: x.nickname,
              showId: x.showId,
              avatar: x.avatar,
            ));
      }
      setState(() {
        users = profiles;
        groups = g;
      });
    } catch (_) {
      setState(() {
        users = [];
        groups = [];
      });
    }
    setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return PageScaffold(
      title: '添加好友 / 群',
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: ctl,
                  textInputAction: TextInputAction.search,
                  onSubmitted: (_) => _search(),
                  decoration: const InputDecoration(hintText: '输入对方 ID / 昵称，或群号'),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                height: 46,
                child: ElevatedButton(
                  onPressed: busy ? null : _search,
                  style: ElevatedButton.styleFrom(backgroundColor: C.primary, foregroundColor: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
                  child: const Text('搜索'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          if (busy) const Center(child: Padding(padding: EdgeInsets.all(20), child: CircularProgressIndicator(strokeWidth: 2))),
          if (!busy && searched && users.isEmpty && groups.isEmpty)
            const Empty(text: '没找到这个人或群', icon: LucideIcons.userSearch),
          ...users.map((p) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
                child: Row(
                  children: [
                    Avatar(url: profileAvatar(p), name: p.nickname, size: 48, radius: 12),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  p.nickname,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: nameColor(redName: p.redName, vip: p.vipLevel.isNotEmpty)),
                                ),
                              ),
                              NameTags(red: p.redName, vip: p.vipLevel),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text('ID: ${p.showId}', style: TextStyle(fontSize: 12.5, color: p.redName ? C.redName : C.textSub)),
                        ],
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        if (p.user == st.user?.id) {
                          st.say('这是你自己');
                          return;
                        }
                        final ok = await st.startDirect(p.user, p.nickname.isEmpty ? p.showId : p.nickname);
                        if (mounted) Nav.push(ChatPage(convId: ok.id));
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: C.primary, foregroundColor: Colors.white, elevation: 0),
                      child: const Text('发消息'),
                    ),
                  ],
                ),
              )),
          ...groups.map((g) => Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: C.surface, borderRadius: BorderRadius.circular(14), boxShadow: C.shadow),
                child: Row(
                  children: [
                    Avatar(url: g.avatar.isEmpty ? '' : 'https://jysl.pw/api/files/conversations/${g.id}/${g.avatar}', name: g.title, size: 48, radius: 12, group: true),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(
                                  g.title,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500, color: groupNameColor(g.groupType)),
                                ),
                              ),
                              GroupTags(groupType: g.groupType),
                            ],
                          ),
                          const SizedBox(height: 3),
                          Text('群号 ${g.groupNo} · ${g.members} 人', style: const TextStyle(fontSize: 12.5, color: C.textSub)),
                        ],
                      ),
                    ),
                    ElevatedButton(
                      onPressed: () async {
                        try {
                          await Api.I.applyGroup(g.id);
                          st.say(g.isOwner ? '这是你的群' : '已申请，等待群主同意');
                        } catch (_) {
                          st.say('申请失败');
                        }
                      },
                      style: ElevatedButton.styleFrom(backgroundColor: C.primary, foregroundColor: Colors.white, elevation: 0),
                      child: Text(g.joined ? '已加入' : '申请加入'),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

/* ------------------------------- 新朋友 ------------------------------- */

class NewFriendsPage extends StatefulWidget {
  const NewFriendsPage({super.key});
  @override
  State<NewFriendsPage> createState() => _NewFriendsPageState();
}

class _NewFriendsPageState extends State<NewFriendsPage> {
  @override
  void initState() {
    super.initState();
    AppState.I.refreshRequests();
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) => PageScaffold(
        title: '新的朋友',
        child: ListView(
          children: [
            if (st.pendingReqs.isNotEmpty) ...[
              const Padding(padding: EdgeInsets.fromLTRB(20, 14, 20, 6), child: Text('好友申请', style: TextStyle(fontSize: 12.5, color: C.textSub))),
              ...st.pendingReqs.map((r) => Cell(
                    leading: Avatar(url: st.avatarOf(r.fromUser), name: r.fromName, size: 44),
                    title: r.fromName.isEmpty ? '有人' : r.fromName,
                    subtitle: r.note.isEmpty ? '请求加你为好友' : r.note,
                    chevron: false,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextButton(
                          onPressed: () async {
                            await Api.I.answerRequest(r.id, false).catchError((_) {});
                            await st.refreshRequests();
                          },
                          child: const Text('拒绝', style: TextStyle(color: C.textSub)),
                        ),
                        ElevatedButton(
                          onPressed: () async {
                            await Api.I.answerRequest(r.id, true).catchError((_) {});
                            await Api.I.addFriend(st.user!.id, r.fromUser, r.fromName).catchError((_) {});
                            await Api.I.addFriend(r.fromUser, st.user!.id, st.displayName).catchError((_) {});
                            await st.refreshAll();
                            st.say('已添加为好友');
                          },
                          style: ElevatedButton.styleFrom(backgroundColor: C.primary, foregroundColor: Colors.white, elevation: 0),
                          child: const Text('同意'),
                        ),
                      ],
                    ),
                  )),
            ],
            if (st.groupInvites.isNotEmpty) ...[
              const Padding(padding: EdgeInsets.fromLTRB(20, 14, 20, 6), child: Text('群邀请', style: TextStyle(fontSize: 12.5, color: C.textSub))),
              ...st.groupInvites.map((g) => Cell(
                    leading: const Icon(LucideIcons.userPlus, color: C.primary, size: 30),
                    title: g.groupTitle.isEmpty ? '群聊邀请' : g.groupTitle,
                    subtitle: '${g.inviterName} 邀请你加入',
                    chevron: false,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextButton(
                          onPressed: () async {
                            await Api.I.updateGroupInvite(g.id, 'refused').catchError((_) {});
                            await st.refreshGroupInvites();
                          },
                          child: const Text('拒绝', style: TextStyle(color: C.textSub)),
                        ),
                        ElevatedButton(
                          onPressed: () async {
                            await Api.I.updateGroupInvite(g.id, 'agreed').catchError((_) {});
                            await st.refreshGroupInvites();
                            st.say('已加入群聊');
                          },
                          style: ElevatedButton.styleFrom(backgroundColor: C.primary, foregroundColor: Colors.white, elevation: 0),
                          child: const Text('同意'),
                        ),
                      ],
                    ),
                  )),
            ],
            if (st.pendingReqs.isEmpty && st.groupInvites.isEmpty)
              const SizedBox(height: 140, child: Empty(text: '暂时没有新的申请', icon: LucideIcons.userPlus)),
          ],
        ),
      ),
    );
  }
}

/* ------------------------------- 我的二维码 ------------------------------ */

class MyQrPage extends StatelessWidget {
  const MyQrPage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final showId = st.profile?.showId ?? '';
    return PageScaffold(
      title: '我的二维码',
      child: ListView(
        padding: const EdgeInsets.all(24),
        children: [
          Container(
            padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), boxShadow: C.shadow),
            child: Column(
              children: [
                QrImageView(data: 'juyan://user/$showId', size: 210, backgroundColor: Colors.white),
                const SizedBox(height: 18),
                Text(st.displayName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                const SizedBox(height: 6),
                Text('ID: $showId', style: const TextStyle(fontSize: 14, color: C.textSub)),
                const SizedBox(height: 18),
                OutlinedButton.icon(
                  onPressed: () async {
                    await Clipboard.setData(ClipboardData(text: showId));
                    st.say('已复制 ID');
                  },
                  icon: const Icon(LucideIcons.copy, size: 17),
                  label: const Text('复制 ID'),
                ),
              ],
            ),
          ),
          const Padding(
            padding: EdgeInsets.only(top: 18),
            child: Text('扫一扫上面的二维码，就能找到我', textAlign: TextAlign.center, style: TextStyle(fontSize: 12.5, color: C.textMute)),
          ),
        ],
      ),
    );
  }
}

/* ------------------------------- 扫一扫 ------------------------------- */

class ScanPage extends StatelessWidget {
  const ScanPage({super.key});

  @override
  Widget build(BuildContext context) {
    return PageScaffold(
      title: '扫一扫',
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Container(
              height: 240,
              decoration: BoxDecoration(color: const Color(0xFF15181E), borderRadius: BorderRadius.circular(18)),
              child: const Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(LucideIcons.scanLine, color: Colors.white, size: 60),
                    SizedBox(height: 12),
                    Text('对准二维码即可识别', style: TextStyle(color: Colors.white70, fontSize: 13)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            const Text('也可以直接输入对方 ID', style: TextStyle(fontSize: 13, color: C.textSub)),
            const SizedBox(height: 12),
            PrimaryButton(text: '手动输入 ID 添加', onTap: () => Nav.push(const AddFriendPage())),
          ],
        ),
      ),
    );
  }
}

/* ------------------------------- 用户资料页 ----------------------------- */

class UserProfilePage extends StatefulWidget {
  final String userId;
  const UserProfilePage({super.key, required this.userId});
  @override
  State<UserProfilePage> createState() => _UserProfilePageState();
}

class _UserProfilePageState extends State<UserProfilePage> {
  Profile? p;
  bool isFriend = false;
  Presence? pres;
  bool loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final st = AppState.I;
    var got = st.personOf(widget.userId);
    got ??= await Api.I.profileOf(widget.userId).catchError((_) => null);
    if (got != null) st.people[widget.userId] = got;
    bool f = false;
    if (got != null && st.user != null) {
      f = await Api.I.isFriend(st.user!.id, widget.userId).catchError((_) => false);
    }
    Map<String, Presence> pm = {};
    try {
      pm = await Api.I.presence([widget.userId]);
    } catch (_) {}
    setState(() {
      p = got;
      isFriend = f;
      pres = pm[widget.userId];
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    if (loading) {
      return const PageScaffold(title: '资料', child: Center(child: CircularProgressIndicator(strokeWidth: 2)));
    }
    if (p == null) {
      return const PageScaffold(title: '资料', child: Empty(text: '找不到这个人', icon: LucideIcons.userX));
    }
    final me = widget.userId == st.user?.id;
    return PageScaffold(
      title: '资料',
      child: ListView(
        children: [
          // 资料卡（照网页版：头像居中 → 昵称+徽章 → ID → 签名）
          Container(
            color: Colors.white,
            padding: const EdgeInsets.fromLTRB(16, 24, 16, 24),
            child: Column(
              children: [
                Avatar(url: profileAvatar(p), name: p!.nickname, size: 72, radius: 20),
                const SizedBox(height: 12),
                Row(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Flexible(
                      child: Text(
                        p!.nickname,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: nameColor(redName: p!.redName, vip: p!.vipLevel.isNotEmpty)),
                      ),
                    ),
                    NameTags(red: p!.redName, vip: st.vipOf(widget.userId), scale: 0.95, md: true),
                  ],
                ),
                const SizedBox(height: 4),
                Text('ID: ${p!.showId}', style: TextStyle(fontSize: 13, color: p!.redName ? C.redName : C.textSub)),
                const SizedBox(height: 2),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  child: Text(
                    p!.bio.isNotEmpty ? p!.bio : '这个人很神秘，什么都没写',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 13, color: C.textSub),
                  ),
                ),
                if (pres != null && !pres!.hidden)
                  Padding(
                    padding: const EdgeInsets.only(top: 6),
                    child: Text(pres!.online ? '在线' : '离线', style: TextStyle(fontSize: 12.5, color: pres!.online ? C.green : C.textMute)),
                  ),
              ],
            ),
          ),
          if (!me)
            Padding(
              padding: const EdgeInsets.all(16),
              child: PrimaryButton(
                text: isFriend ? '发消息' : '加为好友',
                onTap: () async {
                  if (isFriend) {
                    final c = await st.startDirect(widget.userId, p!.nickname);
                    if (mounted) Nav.push(ChatPage(convId: c.id));
                    return;
                  }
                  try {
                    await Api.I.sendFriendRequest(st.user!.id, widget.userId, st.displayName, '你好，我想加你为好友');
                    st.say('已发送好友申请');
                  } catch (_) {
                    st.say('发送失败');
                  }
                },
              ),
            ),
          CellGroup(
            children: [
              Cell(title: '推荐给朋友', leading: const Icon(LucideIcons.share2, color: C.textSub, size: 20), onTap: () => st.say('已复制资料')),
              Cell(title: '举报', leading: const Icon(LucideIcons.flag, color: C.textSub, size: 20), onTap: () => st.say('已收到举报，我们会核实')),
            ],
          ),
        ],
      ),
    );
  }
}

/* ------------------------------- 名片页 ------------------------------- */

class FriendCardPage extends StatelessWidget {
  final String userId;
  const FriendCardPage({super.key, required this.userId});
  @override
  Widget build(BuildContext context) => UserProfilePage(userId: userId);
}

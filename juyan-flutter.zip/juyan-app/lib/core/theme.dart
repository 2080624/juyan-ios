/// 聚言商聊 —— 视觉规范（与网页版配色 1:1）
library;

import 'package:flutter/material.dart';

class C {
  static const primary = Color(0xFF1A7DFF);
  static const primaryDeep = Color(0xFF0D63E0);
  static const primarySoft = Color(0xFFE8F1FF);
  static const bgApp = Color(0xFFF4F5F7);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceHover = Color(0xFFF2F4F8);
  static const textMain = Color(0xFF15181E);
  static const textSub = Color(0xFF8B909A);
  static const textMute = Color(0xFFB0B5BF);
  static const divider = Color(0xFFEDEFF3);
  static const dividerSoft = Color(0xFFF5F6F9);
  static const vipDark = Color(0xFF3F51B8);
  static const vipLight = Color(0xFF7C88E8);
  static const danger = Color(0xFFE5484D);
  static const green = Color(0xFF26B36B);
  static const redName = Color(0xFFE5484D);
  static const bubbleMine = Color(0xFF1A7DFF);
  static const bubbleOther = Color(0xFFFFFFFF);
  static const chatBg = Color(0xFFEDEFF3);

  static const vipGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [vipDark, Color(0xFF6D7FE0), Color(0xFF8F9CF0)],
  );

  static const brandGradient = LinearGradient(
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
    colors: [Color(0xFF1A7DFF), Color(0xFF5B9BFF)],
  );

  static const shadow = [
    BoxShadow(color: Color(0x0A141823), offset: Offset(0, 1), blurRadius: 2),
    BoxShadow(color: Color(0x0D141823), offset: Offset(0, 8), blurRadius: 24),
  ];

  static const shadowFloat = [
    BoxShadow(color: Color(0x471A7DFF), offset: Offset(0, 10), blurRadius: 30),
  ];
}

ThemeData buildTheme() {
  final base = ThemeData.light(useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: C.bgApp,
    colorScheme: base.colorScheme.copyWith(
      primary: C.primary,
      surface: C.surface,
      error: C.danger,
    ),
    splashFactory: InkRipple.splashFactory,
    appBarTheme: const AppBarTheme(
      backgroundColor: C.surface,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: TextStyle(color: C.textMain, fontSize: 17, fontWeight: FontWeight.w600),
      iconTheme: IconThemeData(color: C.textMain, size: 22),
    ),
    dividerTheme: const DividerThemeData(color: C.divider, thickness: 0.5, space: 0.5),
    textTheme: base.textTheme.apply(bodyColor: C.textMain, displayColor: C.textMain).copyWith(
          bodyMedium: const TextStyle(fontSize: 15, color: C.textMain),
          bodySmall: const TextStyle(fontSize: 13, color: C.textSub),
          titleMedium: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600, color: C.textMain),
        ),
    bottomSheetTheme: const BottomSheetThemeData(
      backgroundColor: C.surface,
      surfaceTintColor: Colors.transparent,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: Color(0xE6202430),
      contentTextStyle: TextStyle(color: Colors.white, fontSize: 14),
      behavior: SnackBarBehavior.floating,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: C.surfaceHover,
      hintStyle: const TextStyle(color: C.textMute, fontSize: 15),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: BorderSide.none),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: C.primary, width: 1.5)),
    ),
    switchTheme: SwitchThemeData(
      thumbColor: const WidgetStatePropertyAll(Colors.white),
      trackColor: WidgetStateProperty.resolveWith((s) => s.contains(WidgetState.selected) ? C.primary : const Color(0xFFDDE1E8)),
      trackOutlineColor: const WidgetStatePropertyAll(Colors.transparent),
    ),
  );
}

/// 昵称颜色：用了靓号 → 红色；会员 → 金棕色；普通 → 主文字色
Color nameColor({required bool redName, required bool vip}) {
  if (redName) return C.redName;
  if (vip) return const Color(0xFFC9922B);
  return C.textMain;
}

String vipLabel(String level) {
  switch (level) {
    case 'VIP':
    case 'VIP1':
    case 'SVIP1':
      return 'VIP1';
    case 'VIP2':
    case 'SVIP2':
      return 'VIP2';
    case 'VIP3':
    case 'SVIP3':
      return 'VIP3';
    case '至尊会员':
    case '至尊SVIP':
      return '至尊会员';
    default:
      return level;
  }
}

String fmtTime(String iso) {
  final t = DateTime.tryParse(iso)?.toLocal();
  if (t == null) return '';
  final now = DateTime.now();
  final sameDay = t.year == now.year && t.month == now.month && t.day == now.day;
  final hm = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  if (sameDay) return hm;
  final d = DateTime(now.year, now.month, now.day).difference(DateTime(t.year, t.month, t.day)).inDays;
  if (d == 1) return '昨天 $hm';
  if (d < 7) return '$d天前';
  return '${t.month}/${t.day}';
}

String fmtDateTime(String iso) {
  final t = DateTime.tryParse(iso)?.toLocal();
  if (t == null) return '';
  return '${t.year}-${t.month.toString().padLeft(2, '0')}-${t.day.toString().padLeft(2, '0')} '
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
}

String fmtChatTime(String iso) {
  final t = DateTime.tryParse(iso)?.toLocal();
  if (t == null) return '';
  final now = DateTime.now();
  final hm = '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';
  final d = DateTime(now.year, now.month, now.day).difference(DateTime(t.year, t.month, t.day)).inDays;
  if (d == 0) return hm;
  if (d == 1) return '昨天 $hm';
  if (d < 7) return '$d天前 $hm';
  return '${t.month}月${t.day}日 $hm';
}

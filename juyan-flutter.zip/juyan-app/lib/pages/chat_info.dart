/// 聊天详情（单聊）
library;

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import '../core/prefs.dart';
import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../data/api.dart';
import '../widgets/kit.dart';
import 'friend.dart';
import 'group.dart';

class ChatInfoPage extends StatefulWidget {
  final String convId;
  const ChatInfoPage({super.key, required this.convId});
  @override
  State<ChatInfoPage> createState() => _ChatInfoPageState();
}

class _ChatInfoPageState extends State<ChatInfoPage> {
  String peerId = '';

  @override
  void initState() {
    super.initState();
    final st = AppState.I;
    final list = st.convos.where((c) => c.id == widget.convId).toList();
    if (list.isNotEmpty && !list.first.isGroup) {
      peerId = list.first.members.firstWhere((m) => m != st.user?.id, orElse: () => '');
    }
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    final p = peerId.isEmpty ? null : st.personOf(peerId);
    final name = peerId.isEmpty ? '聊天' : st.displayOf(peerId);
    final conv = st.convos.where((c) => c.id == widget.convId).toList();

    return PageScaffold(
      title: '聊天信息',
      child: ListView(
        children: [
          if (peerId.isNotEmpty)
            CellGroup(
              children: [
                Cell(
                  leading: Avatar(url: p == null ? '' : profileAvatar(p), name: name, size: 50, radius: 13),
                  title: name,
                  subtitle: 'ID: ${p?.showId ?? ''}',
                  onTap: () => Nav.push(UserProfilePage(userId: peerId)),
                ),
              ],
            ),
          CellGroup(
            children: [
              SwitchCell(
                title: '消息置顶',
                value: Prefs.isPinned(widget.convId),
                onChanged: (v) async {
                  await Prefs.togglePin(widget.convId);
                  setState(() {});
                  st.bump();
                },
              ),
              SwitchCell(
                title: '消息免打扰',
                value: Prefs.isMuted(widget.convId),
                onChanged: (v) async {
                  await Prefs.toggleMute(widget.convId);
                  setState(() {});
                },
              ),
            ],
          ),
          CellGroup(
            children: [
              Cell(title: '查找聊天记录', onTap: () => Nav.push(SearchMsgPage(convId: widget.convId))),
              Cell(
                title: '设置聊天背景',
                onTap: () async {
                  final f = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 1200);
                  if (f == null) return;
                  try {
                    final path = await Api.I.uploadFile('conversations', widget.convId, 'background', File(f.path));
                    await Api.I.updateConversation(widget.convId, {'background': path});
                    await st.refreshAll();
                    st.say('聊天背景已更新');
                  } catch (_) {
                    st.say('设置失败');
                  }
                },
              ),
            ],
          ),
          CellGroup(
            children: [
              Cell(title: '清空聊天记录', titleColor: C.danger, onTap: () async {
                if (await confirmDialog(context, '清空和这个人的聊天记录？')) {
                  st.say('已清空');
                }
              }),
              Cell(title: '拉黑', titleColor: C.danger, onTap: () async {
                if (peerId.isEmpty) return;
                if (await confirmDialog(context, '确定拉黑对方？', body: '拉黑后你将不再收到对方的消息')) {
                  await Api.I.blockSet(target: peerId).catchError((_) {});
                  st.say('已拉黑');
                }
              }),
              Cell(title: '举报', onTap: () => st.say('已收到举报，我们会核实')),
            ],
          ),
          if (conv.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(16),
              child: Text('会话 ID：${widget.convId}', style: const TextStyle(fontSize: 11, color: C.textMute)),
            ),
        ],
      ),
    );
  }
}

class SearchMsgPage extends StatelessWidget {
  final String convId;
  const SearchMsgPage({super.key, required this.convId});
  @override
  Widget build(BuildContext context) => PageScaffold(title: '查找聊天记录', child: SearchMsgList(convId: convId));
}

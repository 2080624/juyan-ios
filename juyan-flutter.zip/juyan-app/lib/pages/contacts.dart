/// 通讯录
library;

import 'package:flutter/material.dart';

import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../widgets/kit.dart';
import 'chat.dart';
import 'friend.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

class ContactsPage extends StatefulWidget {
  const ContactsPage({super.key});
  @override
  State<ContactsPage> createState() => _ContactsPageState();
}

class _ContactsPageState extends State<ContactsPage> {
  final ctl = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => AppState.I.refreshFriends());
  }

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return AnimatedBuilder(
      animation: st,
      builder: (context, _) {
        // 去重（网页版有重复好友的坑，这里按 friend 去重）
        final seen = <String>{};
        final rows = <FriendRow>[];
        for (final f in st.friends) {
          if (seen.contains(f.friend)) continue;
          seen.add(f.friend);
          rows.add(f);
        }
        rows.sort((a, b) => st.displayOf(a.friend).compareTo(st.displayOf(b.friend)));

        final q = ctl.text.trim();
        final filtered = q.isEmpty ? rows : rows.where((f) => st.displayOf(f.friend).contains(q)).toList();

        final groups = st.sortedConvos.where((c) => c.isGroup).toList();

        final pending = st.pendingReqs.length + st.groupInvites.length;

        return Scaffold(
          backgroundColor: C.bgApp,
          appBar: AppBar(
            title: const Text('通讯录'),
            automaticallyImplyLeading: false,
            actions: [
              IconButton(icon: const Icon(LucideIcons.userPlus, size: 22), onPressed: () => Nav.push(const AddFriendPage())),
              const SizedBox(width: 4),
            ],
          ),
          body: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
                child: TextField(
                  controller: ctl,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    hintText: '搜索好友',
                    prefixIcon: Icon(LucideIcons.search, size: 19, color: C.textMute),
                  ),
                ),
              ),
              Expanded(
                child: RefreshIndicator(
                  onRefresh: () => st.refreshAll(),
                  child: ListView(
                    children: [
                      if (pending > 0)
                        Cell(
                          leading: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(color: const Color(0xFFE5A13B), borderRadius: BorderRadius.circular(11)),
                            child: const Icon(LucideIcons.userPlus, color: Colors.white, size: 21),
                          ),
                          title: '新的朋友',
                          hint: '$pending 条申请',
                          onTap: () => Nav.push(const NewFriendsPage()),
                        ),
                      if (filtered.isEmpty)
                        const SizedBox(height: 160, child: Empty(text: '还没有好友，去加一个吧', icon: LucideIcons.users))
                      else ...[
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
                          child: Text('好友 (${filtered.length})', style: const TextStyle(fontSize: 12.5, color: C.textSub)),
                        ),
                        ...filtered.map((f) {
                          final uid = f.friend;
                          final p = st.personOf(uid);
                          return Cell(
                            leading: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                Avatar(url: p == null ? '' : profileAvatar(p), name: st.displayOf(uid), size: 42),
                                if (st.onlineOf(uid))
                                  Positioned(
                                    right: -2,
                                    bottom: -2,
                                    child: Container(width: 12, height: 12, decoration: BoxDecoration(color: C.green, shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 2))),
                                  ),
                              ],
                            ),
                            titleWidget: NameRow(name: st.displayOf(uid), red: st.redOf(uid), vip: st.vipOf(uid)),
                            onTap: () => Nav.push(UserProfilePage(userId: uid)),
                          );
                        }),
                      ],
                      if (groups.isNotEmpty) ...[
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 14, 20, 4),
                          child: Text('群聊 (${groups.length})', style: const TextStyle(fontSize: 12.5, color: C.textSub)),
                        ),
                        ...groups.map((g) {
                          final admin = g.admins.contains(st.user?.id ?? '');
                          return Cell(
                            leading: Avatar(url: g.avatar, name: g.title.isEmpty ? '群聊' : g.title, size: 42),
                            titleWidget: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                NameRow(
                                  name: g.title.isEmpty ? '群聊' : g.title,
                                  groupType: g.groupType,
                                  lucky: st.isGroupLucky(g.groupNo),
                                ),
                                if (admin)
                                  Container(
                                    margin: const EdgeInsets.only(left: 4),
                                    padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1.5),
                                    decoration: BoxDecoration(color: const Color(0xFFEAF2FF), borderRadius: BorderRadius.circular(4)),
                                    child: const Text('管理员', style: TextStyle(fontSize: 10, color: C.primary, height: 1.1, fontWeight: FontWeight.w600)),
                                  ),
                              ],
                            ),
                            subtitle: '${g.members.length} 人${g.groupNo.isNotEmpty ? ' · 群号 ${g.groupNo}' : ''}',
                            onTap: () async {
                              final c = await st.startDirect(g.id, g.title);
                              if (context.mounted) Nav.push(ChatPage(convId: c.id));
                            },
                          );
                        }),
                      ],
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

/// 发现页
library;

import 'package:flutter/material.dart';

import '../core/router.dart';
import '../core/state.dart';
import '../core/theme.dart';
import '../widgets/kit.dart';
import 'friend.dart';
import 'misc.dart';
import 'packet.dart';
import 'moments.dart';
import 'vip.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';

class DiscoverPage extends StatelessWidget {
  const DiscoverPage({super.key});

  @override
  Widget build(BuildContext context) {
    final st = AppState.I;
    return Scaffold(
      backgroundColor: C.bgApp,
      appBar: AppBar(title: const Text('发现'), automaticallyImplyLeading: false),
      body: AnimatedBuilder(
        animation: st,
        builder: (context, _) => ListView(
          children: [
            CellGroup(
              children: [
                Cell(
                  leading: const _Ic(LucideIcons.camera, Color(0xFFE5A13B)),
                  title: '朋友圈',
                  subtitle: st.notices.isEmpty ? '分享生活点滴' : '看看大家的新动态',
                  onTap: () => Nav.push(const MomentsPage()),
                ),
                Cell(
                  leading: const _Ic(LucideIcons.scanLine, Color(0xFF4C9AFF)),
                  title: '扫一扫',
                  onTap: () => Nav.push(const ScanPage()),
                ),
              ],
            ),
            CellGroup(
              children: [
                Cell(
                  leading: const _Ic(LucideIcons.gift, Color(0xFFE5484D)),
                  title: '邀请有礼',
                  subtitle: '邀好友双方各得 20 积分',
                  onTap: () => Nav.push(const InvitePage()),
                ),
                Cell(
                  leading: const _Ic(LucideIcons.gem, Color(0xFF7C88E8)),
                  title: '靓号商城',
                  subtitle: '挑一个好看的 ID',
                  onTap: () => Nav.push(const LuckyPage()),
                ),
                Cell(
                  leading: const _Ic(LucideIcons.crown, Color(0xFFC9922B)),
                  title: '会员中心',
                  subtitle: st.isVip ? '当前：${vipLabel(st.myVipLevel)}' : '开通会员，解锁更多特权',
                  onTap: () => Nav.push(const VipPage()),
                ),
              ],
            ),
            CellGroup(
              children: [
                Cell(
                  leading: const _Ic(LucideIcons.receiptText, Color(0xFF26B36B)),
                  title: '我的账单',
                  onTap: () => Nav.push(const BillsPage()),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Ic extends StatelessWidget {
  final IconData icon;
  final Color color;
  const _Ic(this.icon, this.color);
  @override
  Widget build(BuildContext context) => Container(
        width: 38,
        height: 38,
        decoration: BoxDecoration(color: color.withValues(alpha: 0.12), borderRadius: BorderRadius.circular(10)),
        child: Icon(icon, color: color, size: 20),
      );
}

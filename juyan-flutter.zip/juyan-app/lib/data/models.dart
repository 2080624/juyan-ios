/// 聚言商聊 —— 数据模型（与后端字段 1:1 对齐）
library;

import 'dart:convert';

int _i(dynamic v) => v is int ? v : int.tryParse('$v') ?? 0;
double _d(dynamic v) => v is num ? v.toDouble() : double.tryParse('$v') ?? 0;
bool _b(dynamic v) => v == true || v == 'true' || v == 1;
String _s(dynamic v) => v == null ? '' : '$v';
List<String> _sl(dynamic v) {
  if (v is List) return v.map((e) => '$e').toList();
  return const [];
}

Map<String, dynamic> asMap(dynamic v) => v is Map ? Map<String, dynamic>.from(v) : <String, dynamic>{};
List<Map<String, dynamic>> asList(dynamic v) =>
    v is List ? v.map((e) => asMap(e)).toList() : <Map<String, dynamic>>[];

/* ---------------------------------- 用户 ---------------------------------- */

class UserRec {
  final String id;
  final String username;
  final String email;
  UserRec({required this.id, this.username = '', this.email = ''});
  factory UserRec.from(dynamic v) {
    final m = asMap(v);
    return UserRec(id: _s(m['id']), username: _s(m['username']), email: _s(m['email']));
  }
}

class Profile {
  final String id;
  final String user;
  final String account;
  final String nickname;
  final String showId;
  final String avatar;
  final String bio;
  final String gender;
  final String region;
  final String vipLevel;
  final String vipExpire;
  final bool redName;
  final int coins;
  final bool hasPayPwd;
  final bool banned;
  final String banReason;
  final bool real;
  final bool canceled;
  final String lastSeen;
  final bool hideOnline;
  final String referredBy;
  final String cover;
  final String prefsRaw;
  final String autoReply;
  final bool autoReplyOn;
  final String created;

  const Profile({
    required this.id,
    required this.user,
    this.account = '',
    this.nickname = '',
    this.showId = '',
    this.avatar = '',
    this.bio = '',
    this.gender = '',
    this.region = '',
    this.vipLevel = '',
    this.vipExpire = '',
    this.redName = false,
    this.coins = 0,
    this.hasPayPwd = false,
    this.banned = false,
    this.banReason = '',
    this.real = false,
    this.canceled = false,
    this.lastSeen = '',
    this.hideOnline = false,
    this.referredBy = '',
    this.cover = '',
    this.prefsRaw = '',
    this.autoReply = '',
    this.autoReplyOn = false,
    this.created = '',
  });

  factory Profile.from(dynamic v) {
    final m = asMap(v);
    return Profile(
      id: _s(m['id']),
      user: _s(m['user']),
      account: _s(m['account']),
      nickname: _s(m['nickname']),
      showId: _s(m['show_id']),
      avatar: _s(m['avatar']),
      bio: _s(m['bio']),
      gender: _s(m['gender']),
      region: _s(m['region']),
      vipLevel: _s(m['vip_level']),
      vipExpire: _s(m['vip_expire']),
      redName: _b(m['red_name']),
      coins: _i(m['coins']),
      hasPayPwd: _s(m['pay_pwd']).isNotEmpty,
      banned: _b(m['banned']),
      banReason: _s(m['ban_reason']),
      real: _b(m['real']),
      canceled: _b(m['canceled']),
      lastSeen: _s(m['last_seen']),
      hideOnline: _b(m['hide_online']),
      referredBy: _s(m['referred_by']),
      cover: _s(m['cover']),
      prefsRaw: _s(m['prefs']),
      autoReply: _s(m['auto_reply']),
      autoReplyOn: _b(m['auto_reply_on']),
      created: _s(m['created']),
    );
  }

  bool get vipAlive {
    if (vipExpire.isEmpty) return false;
    final t = DateTime.tryParse(vipExpire);
    if (t == null) return false;
    return t.isAfter(DateTime.now());
  }

  Map<String, dynamic> get prefs {
    if (prefsRaw.isEmpty) return const {};
    try {
      final v = jsonDecode(prefsRaw);
      return v is Map ? Map<String, dynamic>.from(v) : const {};
    } catch (_) {
      return const {};
    }
  }
}

class Presence {
  final bool online;
  final bool hidden;
  final String lastSeen;
  const Presence({this.online = false, this.hidden = false, this.lastSeen = ''});
  factory Presence.from(dynamic v) {
    final m = asMap(v);
    return Presence(online: _b(m['online']), hidden: _b(m['hidden']), lastSeen: _s(m['last_seen']));
  }
}

class VipPlan {
  final String id;
  final String tier;
  final String period;
  final int price;
  final int sort;
  final String note;
  const VipPlan({required this.id, required this.tier, required this.period, this.price = 0, this.sort = 0, this.note = ''});
  factory VipPlan.from(dynamic v) {
    final m = asMap(v);
    return VipPlan(id: _s(m['id']), tier: _s(m['tier']), period: _s(m['period']), price: _i(m['price']), sort: _i(m['sort']), note: _s(m['note']));
  }
}

/* --------------------------------- 会话/消息 -------------------------------- */

class Conversation {
  final String id;
  final String kind; // direct | group
  final String title;
  final List<String> members;
  final String owner;
  final String lastText;
  final String lastTime;
  final String groupType;
  final String intro;
  final String avatar;
  final String groupNo;
  final String notice;
  final bool noticePinned;
  final String adminsRaw;
  final String mutedRaw;
  final String background;
  final String manageRaw;
  final String nicknamesRaw;
  final String created;

  const Conversation({
    required this.id,
    this.kind = 'direct',
    this.title = '',
    this.members = const [],
    this.owner = '',
    this.lastText = '',
    this.lastTime = '',
    this.groupType = 'normal',
    this.intro = '',
    this.avatar = '',
    this.groupNo = '',
    this.notice = '',
    this.noticePinned = false,
    this.adminsRaw = '',
    this.mutedRaw = '',
    this.background = '',
    this.manageRaw = '',
    this.nicknamesRaw = '',
    this.created = '',
  });

  bool get isGroup => kind == 'group';

  factory Conversation.from(dynamic v) {
    final m = asMap(v);
    return Conversation(
      id: _s(m['id']),
      kind: _s(m['kind']).isEmpty ? 'direct' : _s(m['kind']),
      title: _s(m['title']),
      members: _sl(m['members']),
      owner: _s(m['owner']),
      lastText: _s(m['last_text']),
      lastTime: _s(m['last_time']),
      groupType: _s(m['group_type']).isEmpty ? 'normal' : _s(m['group_type']),
      intro: _s(m['intro']),
      avatar: _s(m['avatar']),
      groupNo: _s(m['group_no']),
      notice: _s(m['notice']),
      noticePinned: _b(m['notice_pinned']),
      adminsRaw: _s(m['admins']),
      mutedRaw: _s(m['muted']),
      background: _s(m['background']),
      manageRaw: _s(m['manage']),
      nicknamesRaw: _s(m['nicknames']),
      created: _s(m['created']),
    );
  }

  List<String> get admins => _jsonList(adminsRaw);
  List<String> get muted => _jsonList(mutedRaw);
  Map<String, String> get nicknames {
    if (nicknamesRaw.isEmpty) return const {};
    try {
      final v = jsonDecode(nicknamesRaw);
      if (v is Map) return v.map((k, val) => MapEntry('$k', '$val'));
    } catch (_) {}
    return const {};
  }

  Map<String, dynamic> get manage {
    if (manageRaw.isEmpty) return const {};
    try {
      final v = jsonDecode(manageRaw);
      if (v is Map) return Map<String, dynamic>.from(v);
    } catch (_) {}
    return const {};
  }

  int get capacity => switch (groupType) {
        'diamond' => 5000,
        'platinum' => 2000,
        _ => 200,
      };

  String get typeName => switch (groupType) {
        'diamond' => '至尊群',
        'platinum' => '超级群',
        _ => '普通群',
      };
}

List<String> _jsonList(String raw) {
  if (raw.isEmpty) return const [];
  try {
    final v = jsonDecode(raw);
    if (v is List) return v.map((e) => '$e').toList();
  } catch (_) {}
  return const [];
}

class Message {
  final String id;
  final String conversation;
  final String sender;
  final String kind; // text|image|file|audio|gift|transfer|call|sys
  final String text;
  final String image;
  final String file;
  final String audio;
  final String meta;
  final String quote;
  final String convOwner;
  final bool read;
  final String mentionsRaw;
  final String created;

  const Message({
    required this.id,
    required this.conversation,
    required this.sender,
    this.kind = 'text',
    this.text = '',
    this.image = '',
    this.file = '',
    this.audio = '',
    this.meta = '',
    this.quote = '',
    this.convOwner = '',
    this.read = false,
    this.mentionsRaw = '',
    this.created = '',
  });

  bool get isSys => kind == 'sys';

  List<String> get mentions => _jsonList(mentionsRaw);

  Map<String, dynamic> get metaMap {
    if (meta.isEmpty) return const {};
    try {
      final v = jsonDecode(meta);
      if (v is Map) return Map<String, dynamic>.from(v);
    } catch (_) {}
    return const {};
  }

  factory Message.from(dynamic v) {
    final m = asMap(v);
    return Message(
      id: _s(m['id']),
      conversation: _s(m['conversation']),
      sender: _s(m['sender']),
      kind: _s(m['kind']).isEmpty ? 'text' : _s(m['kind']),
      text: _s(m['text']),
      image: _s(m['image']),
      file: _s(m['file']),
      audio: _s(m['audio']),
      meta: _s(m['meta']),
      quote: _s(m['quote']),
      convOwner: _s(m['conv_owner']),
      read: _b(m['read']),
      mentionsRaw: _s(m['mentions']),
      created: _s(m['created']),
    );
  }
}

class MsgSearchHit {
  final String id;
  final String conv;
  final String convTitle;
  final String sender;
  final String senderName;
  final bool mine;
  final String text;
  final String kind;
  final String created;
  const MsgSearchHit({required this.id, this.conv = '', this.convTitle = '', this.sender = '', this.senderName = '', this.mine = false, this.text = '', this.kind = 'text', this.created = ''});
  factory MsgSearchHit.from(dynamic v) {
    final m = asMap(v);
    return MsgSearchHit(
      id: _s(m['id']),
      conv: _s(m['conv']),
      convTitle: _s(m['convTitle']),
      sender: _s(m['sender']),
      senderName: _s(m['senderName']),
      mine: _b(m['mine']),
      text: _s(m['text']),
      kind: _s(m['kind']),
      created: _s(m['created']),
    );
  }
}

/* --------------------------------- 好友/群 --------------------------------- */

class FriendRow {
  final String id;
  final String user;
  final String friend;
  final String friendName;
  final String remark;
  final String created;
  const FriendRow({required this.id, this.user = '', this.friend = '', this.friendName = '', this.remark = '', this.created = ''});
  factory FriendRow.from(dynamic v) {
    final m = asMap(v);
    return FriendRow(id: _s(m['id']), user: _s(m['user']), friend: _s(m['friend']), friendName: _s(m['friend_name']), remark: _s(m['remark']), created: _s(m['created']));
  }
}

class FriendRequest {
  final String id;
  final String fromUser;
  final String toUser;
  final String fromName;
  final String note;
  final String status;
  final String created;
  const FriendRequest({required this.id, this.fromUser = '', this.toUser = '', this.fromName = '', this.note = '', this.status = 'pending', this.created = ''});
  factory FriendRequest.from(dynamic v) {
    final m = asMap(v);
    return FriendRequest(id: _s(m['id']), fromUser: _s(m['from_user']), toUser: _s(m['to_user']), fromName: _s(m['from_name']), note: _s(m['note']), status: _s(m['status']), created: _s(m['created']));
  }
}

class GroupInvite {
  final String id;
  final String group;
  final String groupTitle;
  final String inviter;
  final String inviterName;
  final String invitee;
  final String peers;
  final String status;
  final String created;
  const GroupInvite({required this.id, this.group = '', this.groupTitle = '', this.inviter = '', this.inviterName = '', this.invitee = '', this.peers = '', this.status = 'pending', this.created = ''});
  factory GroupInvite.from(dynamic v) {
    final m = asMap(v);
    return GroupInvite(id: _s(m['id']), group: _s(m['group']), groupTitle: _s(m['group_title']), inviter: _s(m['inviter']), inviterName: _s(m['inviter_name']), invitee: _s(m['invitee']), peers: _s(m['peers']), status: _s(m['status']), created: _s(m['created']));
  }
}

class GroupApply {
  final String id;
  final String group;
  final String groupTitle;
  final String user;
  final String userName;
  final String owner;
  final String status;
  final String created;
  const GroupApply({required this.id, this.group = '', this.groupTitle = '', this.user = '', this.userName = '', this.owner = '', this.status = 'pending', this.created = ''});
  factory GroupApply.from(dynamic v) {
    final m = asMap(v);
    return GroupApply(id: _s(m['id']), group: _s(m['group']), groupTitle: _s(m['group_title']), user: _s(m['user']), userName: _s(m['user_name']), owner: _s(m['owner']), status: _s(m['status']), created: _s(m['created']));
  }
}

class SearchUser {
  final String user;
  final String profile;
  final String nickname;
  final String showId;
  final String avatar;
  final String vipLevel;
  final bool redName;
  const SearchUser({required this.user, this.profile = '', this.nickname = '', this.showId = '', this.avatar = '', this.vipLevel = '', this.redName = false});
  factory SearchUser.from(dynamic v) {
    final m = asMap(v);
    return SearchUser(user: _s(m['user']), profile: _s(m['profile']), nickname: _s(m['nickname']), showId: _s(m['show_id']), avatar: _s(m['avatar']), vipLevel: _s(m['vip_level']), redName: _b(m['red_name']));
  }
}

class SearchGroup {
  final String id;
  final String title;
  final String groupNo;
  final String avatar;
  final String groupType;
  final int members;
  final String owner;
  final bool isOwner;
  final bool joined;
  const SearchGroup({required this.id, this.title = '', this.groupNo = '', this.avatar = '', this.groupType = 'normal', this.members = 0, this.owner = '', this.isOwner = false, this.joined = false});
  factory SearchGroup.from(dynamic v) {
    final m = asMap(v);
    return SearchGroup(id: _s(m['id']), title: _s(m['title']), groupNo: _s(m['group_no']), avatar: _s(m['avatar']), groupType: _s(m['group_type']), members: _i(m['members']), owner: _s(m['owner']), isOwner: _b(m['isOwner']), joined: _b(m['joined']));
  }
}

/* ---------------------------------- 动态 ---------------------------------- */

class Moment {
  final String id;
  final String user;
  final String authorName;
  final String content;
  final String imagesRaw;
  final int likes;
  final String place;
  final String created;
  const Moment({required this.id, this.user = '', this.authorName = '', this.content = '', this.imagesRaw = '', this.likes = 0, this.place = '', this.created = ''});
  factory Moment.from(dynamic v) {
    final m = asMap(v);
    return Moment(id: _s(m['id']), user: _s(m['user']), authorName: _s(m['author_name']), content: _s(m['content']), imagesRaw: _s(m['images']), likes: _i(m['likes']), place: _s(m['place']), created: _s(m['created']));
  }
  List<String> get images => _jsonList(imagesRaw);
}

class MomentComment {
  final String id;
  final String moment;
  final String user;
  final String authorName;
  final String content;
  final String created;
  const MomentComment({required this.id, this.moment = '', this.user = '', this.authorName = '', this.content = '', this.created = ''});
  factory MomentComment.from(dynamic v) {
    final m = asMap(v);
    return MomentComment(id: _s(m['id']), moment: _s(m['moment']), user: _s(m['user']), authorName: _s(m['author_name']), content: _s(m['content']), created: _s(m['created']));
  }
}

/* ---------------------------------- 钱包 ---------------------------------- */

class Bill {
  final String id;
  final String kind;
  final String title;
  final int amount;
  final int balance;
  final String memo;
  final String created;
  const Bill({required this.id, this.kind = '', this.title = '', this.amount = 0, this.balance = 0, this.memo = '', this.created = ''});
  factory Bill.from(dynamic v) {
    final m = asMap(v);
    return Bill(id: _s(m['id']), kind: _s(m['kind']), title: _s(m['title']), amount: _i(m['amount']), balance: _i(m['balance']), memo: _s(m['memo']), created: _s(m['created']));
  }
}

class LuckyNumber {
  final String id;
  final String number;
  final int price;
  final String status;
  final bool taken;
  final String owner;
  final String ownerName;
  final bool hot;
  final String note;
  final String tier;
  final String kind;
  final String created;
  const LuckyNumber({required this.id, this.number = '', this.price = 0, this.status = 'on', this.taken = false, this.owner = '', this.ownerName = '', this.hot = false, this.note = '', this.tier = 'flat', this.kind = 'user', this.created = ''});
  factory LuckyNumber.from(dynamic v) {
    final m = asMap(v);
    return LuckyNumber(
      id: _s(m['id']),
      number: _s(m['number']),
      price: _i(m['price']),
      status: _s(m['status']),
      taken: _b(m['taken']),
      owner: _s(m['owner']),
      ownerName: _s(m['owner_name']),
      hot: _b(m['hot']),
      note: _s(m['note']),
      tier: _s(m['tier']).isEmpty ? 'flat' : _s(m['tier']),
      kind: _s(m['kind']).isEmpty ? 'user' : _s(m['kind']),
      created: _s(m['created']),
    );
  }
}

class InviteItem {
  final String nickname;
  final String showId;
  final String avatar;
  final String vipLevel;
  final bool redName;
  final String created;
  const InviteItem({this.nickname = '', this.showId = '', this.avatar = '', this.vipLevel = '', this.redName = false, this.created = ''});
  factory InviteItem.from(dynamic v) {
    final m = asMap(v);
    return InviteItem(nickname: _s(m['nickname']), showId: _s(m['show_id']), avatar: _s(m['avatar']), vipLevel: _s(m['vip_level']), redName: _b(m['red_name']), created: _s(m['created']));
  }
}

class InviteStat {
  final int count;
  final List<InviteItem> items;
  const InviteStat({this.count = 0, this.items = const []});
  factory InviteStat.from(dynamic v) {
    final m = asMap(v);
    return InviteStat(count: _i(m['count']), items: asList(m['items']).map(InviteItem.from).toList());
  }
}

/* --------------------------------- 其他 ---------------------------------- */

class Sticky {
  final String id;
  final String user;
  final String image;
  const Sticky({required this.id, this.user = '', this.image = ''});
  factory Sticky.from(dynamic v) {
    final m = asMap(v);
    return Sticky(id: _s(m['id']), user: _s(m['user']), image: _s(m['image']));
  }
}

class Favorite {
  final String id;
  final String user;
  final String content;
  final String source;
  final String created;
  const Favorite({required this.id, this.user = '', this.content = '', this.source = '', this.created = ''});
  factory Favorite.from(dynamic v) {
    final m = asMap(v);
    return Favorite(id: _s(m['id']), user: _s(m['user']), content: _s(m['content']), source: _s(m['source']), created: _s(m['created']));
  }
}

class Notice {
  final String id;
  final String title;
  final String body;
  final String kind;
  final String created;
  const Notice({required this.id, this.title = '', this.body = '', this.kind = '', this.created = ''});
  factory Notice.from(dynamic v) {
    final m = asMap(v);
    return Notice(id: _s(m['id']), title: _s(m['title']), body: _s(m['body']), kind: _s(m['kind']), created: _s(m['created']));
  }
}

class FeedbackRec {
  final String id;
  final String user;
  final String content;
  final String contact;
  final String status;
  final String reply;
  final String created;
  const FeedbackRec({required this.id, this.user = '', this.content = '', this.contact = '', this.status = 'open', this.reply = '', this.created = ''});
  factory FeedbackRec.from(dynamic v) {
    final m = asMap(v);
    return FeedbackRec(id: _s(m['id']), user: _s(m['user']), content: _s(m['content']), contact: _s(m['contact']), status: _s(m['status']), reply: _s(m['reply']), created: _s(m['created']));
  }
}

class CallMember {
  final String u;
  final String n;
  final String a;
  final String o;
  final String s;
  const CallMember({this.u = '', this.n = '', this.a = '', this.o = '', this.s = ''});
  factory CallMember.from(dynamic v) {
    final m = asMap(v);
    return CallMember(u: _s(m['u']), n: _s(m['n']), a: _s(m['a']), o: _s(m['o']), s: _s(m['s']));
  }
}

class CallRec {
  final String id;
  final String conv;
  final String fromUser;
  final String toUser;
  final String fromName;
  final String toName;
  final String fromAvatar;
  final String status;
  final String offer;
  final String answer;
  final String kind;
  final String group;
  final String membersRaw;
  final String invitedRaw;
  final String created;
  const CallRec({
    required this.id,
    this.conv = '',
    this.fromUser = '',
    this.toUser = '',
    this.fromName = '',
    this.toName = '',
    this.fromAvatar = '',
    this.status = 'ringing',
    this.offer = '',
    this.answer = '',
    this.kind = 'direct',
    this.group = '',
    this.membersRaw = '',
    this.invitedRaw = '',
    this.created = '',
  });
  factory CallRec.from(dynamic v) {
    final m = asMap(v);
    return CallRec(
      id: _s(m['id']),
      conv: _s(m['conv']),
      fromUser: _s(m['from_user']),
      toUser: _s(m['to_user']),
      fromName: _s(m['from_name']),
      toName: _s(m['to_name']),
      fromAvatar: _s(m['from_avatar']),
      status: _s(m['status']),
      offer: _s(m['offer']),
      answer: _s(m['answer']),
      kind: _s(m['kind']).isEmpty ? 'direct' : _s(m['kind']),
      group: _s(m['group']),
      membersRaw: _s(m['members']),
      invitedRaw: _s(m['invited']),
      created: _s(m['created']),
    );
  }
  List<CallMember> get members {
    if (membersRaw.isEmpty) return const [];
    try {
      final v = jsonDecode(membersRaw);
      if (v is List) return v.map(CallMember.from).toList();
    } catch (_) {}
    return const [];
  }
  bool get isGroup => kind == 'group';
}

class AdminRec {
  final String id;
  final String email;
  final String name;
  const AdminRec({required this.id, this.email = '', this.name = ''});
  factory AdminRec.from(dynamic v) {
    final m = asMap(v);
    return AdminRec(id: _s(m['id']), email: _s(m['email']), name: _s(m['name']));
  }
}

class BlockRow {
  final String id;
  final String conv;
  final String target;
  const BlockRow({required this.id, this.conv = '', this.target = ''});
  factory BlockRow.from(dynamic v) {
    final m = asMap(v);
    return BlockRow(id: _s(m['id']), conv: _s(m['conv']), target: _s(m['target']));
  }
}

class SearchResult {
  final List<SearchUser> users;
  final List<SearchGroup> groups;
  const SearchResult({this.users = const [], this.groups = const []});
}

String fileUrl(String collection, String id, String name) {
  if (id.isEmpty || name.isEmpty) return '';
  return 'https://jysl.pw/api/files/$collection/$id/$name';
}

String profileAvatar(Profile? p) => (p == null || p.avatar.isEmpty) ? '' : fileUrl('profiles', p.id, p.avatar);
String profileCover(Profile? p) => (p == null || p.cover.isEmpty) ? '' : fileUrl('profiles', p.id, p.cover);
String convAvatarUrl(Conversation c) => c.avatar.isEmpty ? '' : fileUrl('conversations', c.id, c.avatar);
String msgImageUrl(Message m) => m.image.isEmpty ? '' : fileUrl('messages', m.id, m.image);
String msgAudioUrl(Message m) => m.audio.isEmpty ? '' : fileUrl('messages', m.id, m.audio);
String stickyUrl(Sticky s) => s.image.isEmpty ? '' : fileUrl('stickies', s.id, s.image);
String momentImageUrl(Moment m, String name) => fileUrl('moments', m.id, name);

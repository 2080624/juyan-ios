/// 本地偏好：置顶 / 免打扰 / 已读时间 / 各类开关（对齐网页版 chatPrefs + prefs）
library;

import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class Prefs {
  static SharedPreferences? _sp;

  static Future<void> init() async {
    _sp ??= await SharedPreferences.getInstance();
  }

  static SharedPreferences get sp => _sp!;

  /// 当前账号的偏好命名空间
  static String uid = '';

  static String _k(String key) => 'jk_${uid}_$key';

  /* ------------------------------ 会话级偏好 ----------------------------- */

  static Set<String> _set(String key) => (sp.getStringList(_k(key)) ?? const []).toSet();

  static Future<void> _write(String key, Set<String> v) => sp.setStringList(_k(key), v.toList());

  static bool isPinned(String convId) => _set('pin').contains(convId);
  static bool isMuted(String convId) => _set('mute').contains(convId);
  static bool isHidden(String convId) => _set('hide').contains(convId);

  static Future<void> togglePin(String convId) async {
    final s = _set('pin');
    s.contains(convId) ? s.remove(convId) : s.add(convId);
    await _write('pin', s);
  }

  static Future<void> toggleMute(String convId) async {
    final s = _set('mute');
    s.contains(convId) ? s.remove(convId) : s.add(convId);
    await _write('mute', s);
  }

  static Future<void> hideConv(String convId) async {
    final s = _set('hide')..add(convId);
    await _write('hide', s);
  }

  static Future<void> showConv(String convId) async {
    final s = _set('hide')..remove(convId);
    await _write('hide', s);
  }

  /* ------------------------------- 已读 ------------------------------- */

  static Map<String, String> loadRead() {
    final raw = sp.getString(_k('read')) ?? '{}';
    try {
      final m = jsonDecode(raw);
      if (m is Map) return m.map((k, v) => MapEntry('$k', '$v'));
    } catch (_) {}
    return {};
  }

  static Future<void> saveRead(String convId, String iso) async {
    final m = loadRead();
    m[convId] = iso;
    await sp.setString(_k('read'), jsonEncode(m));
  }

  /* ------------------------------- 开关 ------------------------------- */

  static bool flag(String key, {bool def = true}) => sp.getBool(_k(key)) ?? def;
  static Future<void> setFlag(String key, bool v) => sp.setBool(_k(key), v);

  static bool get enterToSend => flag('chat_enter');
  static bool get typingOn => flag('chat_typing');
  static bool get autoImg => flag('chat_autoimg');
  static bool get showPreview => flag('chat_preview');
  static bool get notifyMsg => flag('notify_msg');
  static bool get notifySound => flag('notify_sound');
  static bool get notifyVibrate => flag('notify_vibrate');
  static bool get notifyGroup => flag('notify_group');
  static bool get notifyMoment => flag('notify_moment');

  static bool get hideOnline => flag('hide_online', def: false);

  static String get autoClean => sp.getString(_k('auto_clean')) ?? 'off';

  static Future<void> setStr(String key, String v) => sp.setString(_k(key), v);
  static String str(String key, [String def = '']) => sp.getString(_k(key)) ?? def;

  /* ----------------------------- 多账号 ------------------------------ */

  static List<String> get accounts => sp.getStringList('wy_accounts') ?? const [];
  static Future<void> setAccounts(List<String> v) => sp.setStringList('wy_accounts', v);
}

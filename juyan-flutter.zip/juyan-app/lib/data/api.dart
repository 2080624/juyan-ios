/// 聚言商聊 —— 接口层（与网页版 1:1 对齐，同域 API）
library;

import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'models.dart';

class ApiException implements Exception {
  final int status;
  final String message;
  ApiException(this.status, this.message);
  @override
  String toString() => message.isEmpty ? 'HTTP $status' : message;
}

class Api {
  Api._();
  static final Api I = Api._();

  static const String base = 'https://jysl.pw/api';

  String token = '';
  String adminToken = '';

  static const Map<String, String> _jsonHeaders = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'User-Agent': 'JuYanApp/2.0 (Flutter)',
  };

  Map<String, String> get authHeaders => {
        ..._jsonHeaders,
        if (token.isNotEmpty) 'Authorization': token,
      };

  Map<String, String> get adminHeaders => {
        ..._jsonHeaders,
        if (adminToken.isNotEmpty) 'Authorization': adminToken,
      };

  /* ------------------------------ 底层请求 ------------------------------ */

  Future<dynamic> reqRaw(String path, {String method = 'GET', Object? body, Map<String, String>? headers}) async {
    final uri = path.startsWith('http') ? Uri.parse(path) : Uri.parse('$base$path');
    late http.Response r;
    final h = headers ?? authHeaders;
    try {
      switch (method) {
        case 'POST':
          r = await http.post(uri, headers: h, body: body == null ? null : jsonEncode(body)).timeout(const Duration(seconds: 30));
        case 'PATCH':
          r = await http.patch(uri, headers: h, body: body == null ? null : jsonEncode(body)).timeout(const Duration(seconds: 30));
        case 'DELETE':
          r = await http.delete(uri, headers: h, body: body == null ? null : jsonEncode(body)).timeout(const Duration(seconds: 30));
        default:
          r = await http.get(uri, headers: h).timeout(const Duration(seconds: 30));
      }
    } on SocketException {
      throw ApiException(0, '网络连接失败，检查一下网络');
    } catch (e) {
      if (e is ApiException) rethrow;
      throw ApiException(0, '请求失败：$e');
    }
    if (r.statusCode >= 400) {
      String msg = '';
      try {
        final j = jsonDecode(utf8.decode(r.bodyBytes));
        if (j is Map) msg = '${j['message'] ?? j['error'] ?? ''}';
      } catch (_) {}
      throw ApiException(r.statusCode, msg.isEmpty ? '请求失败(${r.statusCode})' : msg);
    }
    if (r.bodyBytes.isEmpty) return null;
    try {
      return jsonDecode(utf8.decode(r.bodyBytes));
    } catch (_) {
      return utf8.decode(r.bodyBytes);
    }
  }

  Future<Map<String, dynamic>> req(String path, {String method = 'GET', Object? body, Map<String, String>? headers}) async {
    final r = await reqRaw(path, method: method, body: body, headers: headers);
    return asMap(r);
  }

  /* -------------------------------- 文件上传 ------------------------------- */

  Future<Map<String, dynamic>> upload(String collection, String recordId, String field, File file, {String filename = ''}) async {
    final uri = Uri.parse('$base/collections/$collection/records/$recordId');
    final rq = http.MultipartRequest('PATCH', uri);
    rq.headers.addAll({if (token.isNotEmpty) 'Authorization': token, 'Accept': 'application/json'});
    rq.files.add(await http.MultipartFile.fromPath(field, file.path, filename: filename.isEmpty ? null : filename));
    final res = await rq.send().timeout(const Duration(seconds: 120));
    final body = await res.stream.bytesToString();
    if (res.statusCode >= 400) {
      String msg = '';
      try {
        final j = jsonDecode(body);
        if (j is Map) msg = '${j['message'] ?? ''}';
      } catch (_) {}
      throw ApiException(res.statusCode, msg.isEmpty ? '上传失败' : msg);
    }
    return asMap(jsonDecode(body));
  }

  /// 上传到文件字段，返回文件名
  Future<String> uploadFile(String collection, String recordId, String field, File file, {String filename = ''}) async {
    final rec = await upload(collection, recordId, field, file, filename: filename);
    return '${rec[field] ?? ''}';
  }

  /* --------------------------------- 账号 --------------------------------- */

  String mailOf(String account) {
    final a = account.trim().toLowerCase();
    return a.contains('@') ? a : '$a@weiyu.chat';
  }

  Future<bool> nicknameTaken(String nickname) async {
    final r = await req('/collections/profiles/records?perPage=1&filter=${Uri.encodeComponent("nickname='${nickname.replaceAll("'", "")}'")}');
    return asList(r['items']).isNotEmpty;
  }

  Future<Map<String, dynamic>?> lookupAccount(String input) async {
    final raw = input.trim();
    if (raw.isEmpty) return null;
    final kw = raw.replaceAll('"', '').replaceAll("'", '');
    final r = await req('/collections/users/records?perPage=1&filter=${Uri.encodeComponent("username='$kw' || email='$kw' || email='${mailOf(kw)}'")}');
    final items = asList(r['items']);
    return items.isEmpty ? null : items.first;
  }

  Future<List<UserRec>> accountById(String showId) async {
    final list = <UserRec>[];
    var page = 1;
    while (true) {
      final r = await req('/collections/users/records?perPage=200&page=$page');
      final items = asList(r['items']).map(UserRec.from).toList();
      list.addAll(items);
      if (items.length < 200) break;
      page++;
      if (page > 50) break;
    }
    for (final u in list) {
      final p = await profileOf(u.id);
      if (p != null && p.showId == showId) return [u];
    }
    return const [];
  }

  Future<List<Profile>> allProfiles({int perPage = 500}) async {
    final r = await req('/collections/profiles/records?perPage=$perPage');
    return asList(r['items']).map(Profile.from).toList();
  }

  Future<List<Profile>> searchProfiles(String keyword, {int perPage = 20}) async {
    final kw = keyword.replaceAll("'", '').replaceAll('"', '');
    if (kw.isEmpty) return const [];
    final f = "nickname~'$kw' || show_id~'$kw'";
    final r = await req('/collections/profiles/records?perPage=$perPage&filter=${Uri.encodeComponent(f)}');
    return asList(r['items']).map(Profile.from).toList();
  }

  Future<Profile?> profileByShowId(String showId) async {
    final r = await req('/collections/profiles/records?perPage=1&filter=${Uri.encodeComponent("show_id='${showId.replaceAll("'", "")}'")}');
    final items = asList(r['items']);
    return items.isEmpty ? null : Profile.from(items.first);
  }

  Future<Profile?> profileOf(String userId) async {
    if (userId.isEmpty) return null;
    final r = await req('/collections/profiles/records?perPage=1&filter=${Uri.encodeComponent("user='$userId'")}');
    final items = asList(r['items']);
    return items.isEmpty ? null : Profile.from(items.first);
  }

  Future<Map<String, Profile>> profilesByIds(List<String> ids) async {
    if (ids.isEmpty) return {};
    final out = <String, Profile>{};
    const chunk = 40;
    for (var i = 0; i < ids.length; i += chunk) {
      final part = ids.sublist(i, i + chunk > ids.length ? ids.length : i + chunk);
      final f = part.map((e) => "user='$e'").join(' || ');
      final r = await req('/collections/profiles/records?perPage=200&filter=${Uri.encodeComponent(f)}');
      for (final p in asList(r['items']).map(Profile.from)) {
        out[p.user] = p;
      }
    }
    return out;
  }

  Future<Profile> createProfile(Map<String, dynamic> body) async => Profile.from(await req('/collections/profiles/records', method: 'POST', body: body));

  Future<Profile> updateProfile(String id, Map<String, dynamic> body) async => Profile.from(await req('/collections/profiles/records/$id', method: 'PATCH', body: body));

  Future<List<VipPlan>> vipPlans() async {
    final r = await req('/collections/vip_plans/records?perPage=100&sort=sort');
    return asList(r['items']).map(VipPlan.from).toList();
  }

  /* -------------------------------- 登录注册 ------------------------------- */

  /// 登录：先按账号名，再按邮箱，手机号/昵称兜底
  Future<Map<String, dynamic>> login(String account, String password) async {
    final tries = <String>[account.trim(), mailOf(account)];
    final seen = <String>{};
    Object? lastErr;
    for (final id in tries) {
      if (id.isEmpty || seen.contains(id)) continue;
      seen.add(id);
      try {
        return await req('/collections/users/auth-with-password', method: 'POST', body: {'identity': id, 'password': password});
      } catch (e) {
        lastErr = e;
      }
    }
    // 再按昵称/靓号找账号
    try {
      final p = await searchProfiles(account, perPage: 3);
      for (final x in p) {
        if (x.nickname == account || x.showId == account) {
          final u = await req('/collections/users/records/${x.user}');
          final un = '${u['username'] ?? ''}';
          if (un.isNotEmpty) {
            return await req('/collections/users/auth-with-password', method: 'POST', body: {'identity': un, 'password': password});
          }
        }
      }
    } catch (e) {
      lastErr = e;
    }
    throw lastErr is ApiException ? lastErr : ApiException(400, '账号或密码不正确');
  }

  Future<Map<String, dynamic>> signUp({
    required String nickname,
    required String password,
    String ref = '',
  }) async {
    final username = _randUser();
    final r = await req('/collections/users/records', method: 'POST', body: {
      'username': username,
      'email': '$username@weiyu.chat',
      'emailVisibility': false,
      'password': password,
      'passwordConfirm': password,
      if (ref.isNotEmpty) 'ref': ref,
    });
    final uid = '${r['id'] ?? ''}';
    token = '${r['token'] ?? ''}';
    await createProfile({
      'user': uid,
      'account': username,
      'nickname': nickname,
      'show_id': await _freeShowId(),
      if (ref.isNotEmpty) 'referred_by': ref,
    });
    return r;
  }

  String _randUser() {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    final rnd = DateTime.now().microsecondsSinceEpoch;
    final b = StringBuffer('u');
    var v = rnd;
    for (var i = 0; i < 9; i++) {
      b.write(chars[v % chars.length]);
      v = (v ~/ chars.length) + (i + 1) * 7919 + rnd % 97;
    }
    return b.toString();
  }

  /// 生成一个没被占用的 9 位靓号 ID
  Future<String> _freeShowId() async {
    for (var i = 0; i < 30; i++) {
      final n = '${DateTime.now().millisecondsSinceEpoch % 900000000 + 100000000}';
      final s = n.substring(0, 9);
      final p = await profileByShowId(s);
      if (p == null) return s;
      await Future.delayed(const Duration(milliseconds: 3));
    }
    return '${DateTime.now().microsecondsSinceEpoch % 1000000000}'.padLeft(9, '0');
  }

  Future<Map<String, dynamic>> refreshAuth() => req('/collections/users/auth-refresh', method: 'POST');

  Future<UserRec> userById(String id) async => UserRec.from(await req('/collections/users/records/$id'));
  Future<UserRec> updateUser(String id, Map<String, dynamic> body) async => UserRec.from(await req('/collections/users/records/$id', method: 'PATCH', body: body));

  /* -------------------------------- 会话/消息 ------------------------------- */

  Future<List<Conversation>> conversations() async {
    final r = await req('/collections/conversations/records?perPage=200&sort=-last_time');
    return asList(r['items']).map(Conversation.from).toList();
  }

  Future<Conversation?> findDirect(String me, String other) async {
    final r = await req('/collections/conversations/records?perPage=200&filter=${Uri.encodeComponent("kind='direct' && members~'$me'")}');
    for (final c in asList(r['items']).map(Conversation.from)) {
      if (c.members.length == 2 && c.members.contains(other)) return c;
    }
    return null;
  }

  Future<Conversation> createConversation(Map<String, dynamic> body) async => Conversation.from(await req('/collections/conversations/records', method: 'POST', body: body));
  Future<Conversation> conversationById(String id) async => Conversation.from(await req('/collections/conversations/records/$id'));
  Future<Conversation> updateConversation(String id, Map<String, dynamic> body) async => Conversation.from(await req('/collections/conversations/records/$id', method: 'PATCH', body: body));

  Future<void> groupUpdate(String conv, Map<String, dynamic> patch) => req('/jy/group-update', method: 'POST', body: {'conv': conv, ...patch});
  Future<void> groupKick(String conv, String uid) => req('/jy/group-kick', method: 'POST', body: {'conv': conv, 'user': uid});
  Future<void> groupMute(String conv, String uid, bool mute) => req('/jy/group-mute', method: 'POST', body: {'conv': conv, 'user': uid, 'mute': mute});
  Future<void> groupLeave(String conv) => req('/jy/group-leave', method: 'POST', body: {'conv': conv});
  Future<void> groupDismiss(String conv) => req('/jy/group-dismiss', method: 'POST', body: {'conv': conv});
  Future<void> groupUpgrade(String conv, String type) => req('/jy/group-upgrade', method: 'POST', body: {'conv': conv, 'type': type});
  Future<void> groupManageSet(String conv, Map<String, dynamic> manage) => req('/jy/group-manage', method: 'POST', body: {'conv': conv, ...manage});
  Future<void> groupNickSet(String conv, String name) => req('/jy/group-nick', method: 'POST', body: {'conv': conv, 'name': name});
  Future<void> noticePin(String conv, bool pinned) => req('/jy/notice-pin', method: 'POST', body: {'conv': conv, 'pinned': pinned});
  Future<void> msgRecall(String msg) => req('/jy/msg-recall', method: 'POST', body: {'msg': msg});

  Future<List<Message>> messages(String convId, {int perPage = 60, String until = ''}) async {
    final f = until.isEmpty ? "conversation='$convId'" : "conversation='$convId' && created<'$until'";
    final r = await req('/collections/messages/records?perPage=$perPage&sort=-created&filter=${Uri.encodeComponent(f)}');
    final list = asList(r['items']).map(Message.from).toList();
    return list.reversed.toList();
  }

  Future<List<MsgSearchHit>> msgSearch(String kw) async {
    final r = await req('/jy/msg-search', method: 'POST', body: {'kw': kw});
    return asList(r['items']).map(MsgSearchHit.from).toList();
  }

  Future<void> markConvRead(String convId) => req('/jy/read', method: 'POST', body: {'conv': convId});

  Future<void> typingPing(String conv, String to) => req('/jy/typing', method: 'POST', body: {'conv': conv, 'to': to});

  Future<Map<String, dynamic>> typingGet(String conv, String peer) async =>
      req('/jy/typing?conv=${Uri.encodeComponent(conv)}&peer=${Uri.encodeComponent(peer)}');

  /// 发消息（文本/图片/文件/语音/礼物/转账/通话记录都走这里）
  Future<Message> postMessage({
    required String convId,
    required String senderId,
    required String kind,
    String text = '',
    File? file,
    String field = '',
    Map<String, dynamic> meta = const {},
    String quote = '',
    List<String> mentions = const [],
  }) async {
    final body = <String, dynamic>{
      'conversation': convId,
      'sender': senderId,
      'kind': kind,
      'text': text,
      if (quote.isNotEmpty) 'quote': quote,
      if (mentions.isNotEmpty) 'mentions': jsonEncode(mentions),
      if (meta.isNotEmpty) 'meta': jsonEncode(meta),
    };
    final rec = await req('/collections/messages/records', method: 'POST', body: body);
    final id = '${rec['id'] ?? ''}';
    if (file != null && field.isNotEmpty && id.isNotEmpty) {
      try {
        await upload('messages', id, field, file);
      } catch (_) {}
    }
    return Message.from(rec);
  }

  /* ---------------------------------- 好友 --------------------------------- */

  Future<List<FriendRow>> friends(String userId) async {
    final r = await req('/collections/friends/records?perPage=200&filter=${Uri.encodeComponent("user='$userId'")}');
    return asList(r['items']).map(FriendRow.from).toList();
  }

  Future<void> addFriend(String userId, String friendId, String friendName, {String remark = ''}) =>
      req('/collections/friends/records', method: 'POST', body: {
        'user': userId,
        'friend': friendId,
        'friend_name': friendName,
        if (remark.isNotEmpty) 'remark': remark,
      });

  Future<void> removeFriend(String id) => req('/collections/friends/records/$id', method: 'DELETE');

  Future<bool> isFriend(String userId, String friendId) async {
    final r = await req('/collections/friends/records?perPage=1&filter=${Uri.encodeComponent("user='$userId' && friend='$friendId'")}');
    return asList(r['items']).isNotEmpty;
  }

  Future<List<FriendRequest>> incomingRequests(String userId) async {
    final r = await req('/collections/friend_requests/records?perPage=50&sort=-created&filter=${Uri.encodeComponent("to_user='$userId' && status='pending'")}');
    return asList(r['items']).map(FriendRequest.from).toList();
  }

  Future<void> sendFriendRequest(String fromId, String toId, String fromName, String note) =>
      req('/collections/friend_requests/records', method: 'POST', body: {'from_user': fromId, 'to_user': toId, 'from_name': fromName, 'note': note, 'status': 'pending'});

  Future<void> answerRequest(String id, bool agree) =>
      req('/collections/friend_requests/records/$id', method: 'PATCH', body: {'status': agree ? 'accepted' : 'rejected'});

  Future<void> bulkUnfriend(List<String> ids) => req('/jy/bulk-unfriend', method: 'POST', body: {'ids': ids});
  Future<void> bulkQuit(List<String> ids) => req('/jy/bulk-quit', method: 'POST', body: {'ids': ids});

  Future<void> blockSet({String conv = '', String target = '', String mode = 'add'}) =>
      req('/jy/block', method: 'POST', body: {if (conv.isNotEmpty) 'conv': conv, if (target.isNotEmpty) 'target': target, 'mode': mode});

  Future<List<BlockRow>> blocks() async {
    final r = await req('/jy/blocks');
    return asList(r['items']).map(BlockRow.from).toList();
  }

  Future<void> autoReplySet({String? text, bool? on}) =>
      req('/jy/auto-reply', method: 'POST', body: {if (text != null) 'text': text, if (on != null) 'on': on});

  Future<Map<String, dynamic>> prefsOf(String uid) => req('/jy/prefs?uid=${Uri.encodeComponent(uid)}');
  Future<void> prefsSet(Map<String, dynamic> prefs) => req('/jy/prefs', method: 'POST', body: prefs);

  Future<Map<String, dynamic>> searchExact(String kw) => req('/jy/search', method: 'POST', body: {'kw': kw});

  /* ---------------------------------- 群组 --------------------------------- */

  Future<List<GroupInvite>> myGroupInvites(String userId) async {
    final r = await req('/collections/group_invites/records?perPage=50&sort=-created&filter=${Uri.encodeComponent("invitee='$userId' && status='pending'")}');
    return asList(r['items']).map(GroupInvite.from).toList();
  }

  Future<void> updateGroupInvite(String id, String status) =>
      req('/collections/group_invites/records/$id', method: 'PATCH', body: {'status': status});

  Future<void> inviteToGroup(String group, String groupTitle, String inviter, String inviterName, String invitee) =>
      req('/collections/group_invites/records', method: 'POST', body: {
        'group': group,
        'group_title': groupTitle,
        'inviter': inviter,
        'inviter_name': inviterName,
        'invitee': invitee,
        'status': 'pending',
      });

  Future<void> applyGroup(String conv) => req('/jy/group-apply', method: 'POST', body: {'conv': conv});
  Future<List<GroupApply>> myApplies() async {
    final r = await req('/jy/my-applies');
    return asList(r['items']).map(GroupApply.from).toList();
  }
  Future<void> answerApply(String apply, bool agree) => req('/jy/group-apply-answer', method: 'POST', body: {'apply': apply, 'agree': agree});

  /* ---------------------------------- 动态 --------------------------------- */

  Future<List<Moment>> moments({int perPage = 30}) async {
    final r = await req('/collections/moments/records?perPage=$perPage&sort=-created');
    return asList(r['items']).map(Moment.from).toList();
  }

  Future<List<Moment>> myMoments(String userId, {int perPage = 30}) async {
    final r = await req('/collections/moments/records?perPage=$perPage&sort=-created&filter=${Uri.encodeComponent("user='$userId'")}');
    return asList(r['items']).map(Moment.from).toList();
  }

  Future<Moment> createMoment(String userId, String authorName, String content, List<File> files, {String place = ''}) async {
    final body = <String, dynamic>{'user': userId, 'author_name': authorName, 'content': content, 'likes': 0, if (place.isNotEmpty) 'place': place};
    if (files.isEmpty) return Moment.from(await req('/collections/moments/records', method: 'POST', body: body));
    final rq = http.MultipartRequest('POST', Uri.parse('$base/collections/moments/records'));
    rq.headers.addAll({if (token.isNotEmpty) 'Authorization': token, 'Accept': 'application/json'});
    body.forEach((k, v) => rq.fields[k] = '$v');
    for (final f in files) {
      rq.files.add(await http.MultipartFile.fromPath('images', f.path));
    }
    final res = await rq.send().timeout(const Duration(seconds: 180));
    final txt = await res.stream.bytesToString();
    if (res.statusCode >= 400) throw ApiException(res.statusCode, '发布失败');
    return Moment.from(jsonDecode(txt));
  }

  Future<void> updateMoment(String id, Map<String, dynamic> body) => req('/collections/moments/records/$id', method: 'PATCH', body: body);
  Future<void> deleteMoment(String id) => req('/collections/moments/records/$id', method: 'DELETE');

  Future<List<MomentComment>> comments(List<String> momentIds) async {
    if (momentIds.isEmpty) return const [];
    final f = momentIds.map((e) => "moment='$e'").join(' || ');
    final r = await req('/collections/moment_comments/records?perPage=200&sort=created&filter=${Uri.encodeComponent(f)}');
    return asList(r['items']).map(MomentComment.from).toList();
  }

  Future<void> addComment(String momentId, String userId, String authorName, String content) =>
      req('/collections/moment_comments/records', method: 'POST', body: {'moment': momentId, 'user': userId, 'author_name': authorName, 'content': content});

  /* ---------------------------------- 钱包 --------------------------------- */

  Future<void> setPayPwd(String pwd, {String old = ''}) => req('/jy/paypwd', method: 'POST', body: {'pwd': pwd, 'old': old});

  Future<void> transfer(String to, int amount, String pwd, String conv, {String note = ''}) =>
      req('/jy/transfer', method: 'POST', body: {'to': to, 'amount': amount, 'pwd': pwd, 'conv': conv, 'note': note});

  Future<void> transferRecv(String msg) => req('/jy/transfer-recv', method: 'POST', body: {'msg': msg});
  Future<void> transferBack(String msg) => req('/jy/transfer-back', method: 'POST', body: {'msg': msg});

  Future<void> gift(String to, Map<String, dynamic> payload, {String conv = ''}) =>
      req('/jy/gift', method: 'POST', body: {'to': to, ...payload, if (conv.isNotEmpty) 'conv': conv});

  Future<void> giftClaim(String msg) => req('/jy/gift-claim', method: 'POST', body: {'msg': msg});
  Future<void> giftBack(String msg) => req('/jy/gift-back', method: 'POST', body: {'msg': msg});

  Future<List<Bill>> bills({int page = 1, int perPage = 20, String kind = 'all'}) async {
    final r = await req('/jy/bills?page=$page&perPage=$perPage&kind=$kind');
    return asList(r['items']).map(Bill.from).toList();
  }

  Future<List<LuckyNumber>> luckyShop() async {
    final r = await req('/collections/lucky_shop/records?perPage=200&sort=price');
    return asList(r['items']).map(LuckyNumber.from).toList();
  }

  Future<List<LuckyNumber>> luckyFree() async {
    final r = await req('/jy/gift-lucky');
    return asList(r['items']).map(LuckyNumber.from).toList();
  }

  Future<List<String>> groupLuckyNos() async {
    final r = await req('/jy/group-lucky');
    return asList(r['items']).map((e) => '${e['number'] ?? ''}').toList();
  }

  Future<void> buyLucky(String shop) => req('/jy/buy-lucky', method: 'POST', body: {'shop': shop});
  Future<void> buyGroupLucky(String shop, String conv) => req('/jy/buy-lucky', method: 'POST', body: {'shop': shop, 'conv': conv});

  /* ---------------------------------- 实名 --------------------------------- */

  Future<void> realName(String name, String idNo) => req('/jy/realname', method: 'POST', body: {'name': name, 'id_no': idNo});

  Future<void> cancelAccount(String pwd) => req('/jy/cancel', method: 'POST', body: {'pwd': pwd});

  /* ---------------------------------- 邀请 --------------------------------- */

  Future<int> inviteCount(String showId) async {
    final r = await req('/jy/invite-stat?show_id=${Uri.encodeComponent(showId)}');
    return int.tryParse('${r['count'] ?? 0}') ?? 0;
  }

  Future<InviteStat> inviteStat() async => InviteStat.from(await req('/jy/invite-stat'));

  Future<List<InviteItem>> inviteList(String showId) async {
    final r = await req('/jy/invite-stat?show_id=${Uri.encodeComponent(showId)}&list=1');
    return asList(r['items']).map(InviteItem.from).toList();
  }

  /* ---------------------------------- 通话 --------------------------------- */

  Future<CallRec> callCreate(Map<String, dynamic> body) async => CallRec.from(await req('/collections/calls/records', method: 'POST', body: body));
  Future<void> callPatch(String id, Map<String, dynamic> body) => req('/collections/calls/records/$id', method: 'PATCH', body: body);
  Future<CallRec> callGet(String id) async => CallRec.from(await req('/collections/calls/records/$id'));
  Future<void> callHangup(String id) => callPatch(id, {'status': 'ended'}).catchError((_) {});

  Future<CallRec?> callIncoming(String myId) async {
    try {
      final r = await req('/collections/calls/records?perPage=1&sort=-created&filter=${Uri.encodeComponent("to_user='$myId' && status='ringing'")}');
      final items = asList(r['items']);
      if (items.isEmpty) return null;
      final c = CallRec.from(items.first);
      final age = DateTime.now().difference(DateTime.tryParse(c.created)?.toLocal() ?? DateTime.now()).inSeconds;
      if (age > 60) return null;
      return c;
    } catch (_) {
      return null;
    }
  }

  Future<CallRec?> activeGroupCall(String convId) async {
    try {
      final r = await req('/collections/calls/records?perPage=1&sort=-created&filter=${Uri.encodeComponent("group='$convId' && kind='group' && (status='ringing' || status='talking')")}');
      final items = asList(r['items']);
      return items.isEmpty ? null : CallRec.from(items.first);
    } catch (_) {
      return null;
    }
  }

  Future<List<CallRec>> groupCallInvites(String myId) async {
    try {
      final r = await req('/collections/calls/records?perPage=10&sort=-created&filter=${Uri.encodeComponent("kind='group' && status='ringing' && invited~'$myId'")}');
      return asList(r['items']).map(CallRec.from).toList();
    } catch (_) {
      return const [];
    }
  }

  Future<void> callLog(String conv, int secs, String call, {String kind = 'direct', bool video = false}) =>
      req('/jy/calllog', method: 'POST', body: {'conv': conv, 'secs': secs, 'call': call, 'kind': kind, 'video': video});

  /* --------------------------------- 在线状态 ------------------------------- */

  Future<bool> ping() async {
    try {
      final r = await req('/jy/ping', method: 'POST', body: const {});
      return r['ok'] == true;
    } catch (_) {
      return false;
    }
  }

  Future<Map<String, Presence>> presence(List<String> uids) async {
    if (uids.isEmpty) return {};
    final r = await req('/jy/presence', method: 'POST', body: {'uids': uids});
    final m = asMap(r['map']);
    return m.map((k, v) => MapEntry(k, Presence.from(v)));
  }

  Future<void> setOnlinePref(bool hide) => req('/jy/online-pref', method: 'POST', body: {'hide': hide});

  /* ---------------------------------- 封禁 --------------------------------- */

  Future<Map<String, dynamic>> banCheck(String uid) async {
    try {
      return await req('/jy/bancheck?uid=${Uri.encodeComponent(uid)}');
    } catch (_) {
      return const {};
    }
  }

  Future<void> appeal(String showId, String content, String contact) =>
      req('/jy/appeal', method: 'POST', body: {'show_id': showId, 'content': content, 'contact': contact});

  /* ---------------------------------- 反馈 --------------------------------- */

  Future<Map<String, dynamic>> notices({String kind = ''}) => req('/collections/notices/records?perPage=20&sort=-created${kind.isEmpty ? '' : '&filter=${Uri.encodeComponent("kind='$kind'")}'}');

  Future<void> sendFeedback(String userId, String content, String contact) =>
      req('/collections/feedbacks/records', method: 'POST', body: {'user': userId, 'content': content, 'contact': contact, 'status': 'open'});

  Future<List<FeedbackRec>> myFeedbacks(String userId) async {
    final r = await req('/collections/feedbacks/records?perPage=50&sort=-created&filter=${Uri.encodeComponent("user='$userId'")}');
    return asList(r['items']).map(FeedbackRec.from).toList();
  }

  /* ---------------------------------- 收藏 --------------------------------- */

  Future<List<Favorite>> myFavorites(String userId) async {
    final r = await req('/collections/favorites/records?perPage=100&sort=-created&filter=${Uri.encodeComponent("user='$userId'")}');
    return asList(r['items']).map(Favorite.from).toList();
  }

  Future<void> addFavorite(String userId, String content, String source) =>
      req('/collections/favorites/records', method: 'POST', body: {'user': userId, 'content': content, 'source': source});

  Future<void> deleteFavorite(String id) => req('/collections/favorites/records/$id', method: 'DELETE');

  /* --------------------------------- 表情包 -------------------------------- */

  Future<List<Sticky>> myStickies(String userId) async {
    final r = await req('/collections/stickies/records?perPage=100&sort=-created&filter=${Uri.encodeComponent("user='$userId'")}');
    return asList(r['items']).map(Sticky.from).toList();
  }

  Future<Sticky> addSticky(String userId, File file) async {
    final rq = http.MultipartRequest('POST', Uri.parse('$base/collections/stickies/records'));
    rq.headers.addAll({if (token.isNotEmpty) 'Authorization': token, 'Accept': 'application/json'});
    rq.fields['user'] = userId;
    rq.files.add(await http.MultipartFile.fromPath('image', file.path));
    final res = await rq.send().timeout(const Duration(seconds: 60));
    final txt = await res.stream.bytesToString();
    if (res.statusCode >= 400) throw ApiException(res.statusCode, '添加失败');
    return Sticky.from(jsonDecode(txt));
  }

  Future<void> delSticky(String id) => req('/collections/stickies/records/$id', method: 'DELETE');

  Future<void> deleteMessage(String id) => req('/collections/messages/records/$id', method: 'DELETE');

  /* --------------------------------- 管理后台 ------------------------------- */

  Future<Map<String, dynamic>> adminLogin(String email, String password) async {
    final r = await req('/collections/admins/auth-with-password', method: 'POST', body: {'identity': email, 'password': password}, headers: _jsonHeaders);
    adminToken = '${r['token'] ?? ''}';
    return r;
  }

  Future<Map<String, dynamic>> adminReq(String path, {String method = 'GET', Object? body}) =>
      req(path, method: method, body: body, headers: adminHeaders);

  Future<List<Map<String, dynamic>>> adminList(String collection, {int perPage = 200, String sort = '', String filter = ''}) async {
    final q = StringBuffer('/collections/$collection/records?perPage=$perPage');
    if (sort.isNotEmpty) q.write('&sort=$sort');
    if (filter.isNotEmpty) q.write('&filter=${Uri.encodeComponent(filter)}');
    final r = await adminReq(q.toString());
    return asList(r['items']);
  }

  Future<Map<String, dynamic>> adminPatch(String collection, String id, Map<String, dynamic> body) =>
      adminReq('/collections/$collection/records/$id', method: 'PATCH', body: body);

  Future<void> adminDelete(String collection, String id) => adminReq('/collections/$collection/records/$id', method: 'DELETE');

  Future<void> adminCoins(String userId, int coins) => adminReq('/jy/admin-coins', method: 'POST', body: {'user': userId, 'coins': coins});
}

/// 聚言商聊 —— 全局状态（登录态 / 会话 / 好友 / 通知）
library;

import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/api.dart';
import '../data/models.dart';
import 'prefs.dart';
import 'notifier.dart';

class AppState extends ChangeNotifier {
  static final AppState I = AppState._();
  AppState._();

  final Api api = Api.I;

  bool booting = true;
  UserRec? user;
  Profile? profile;
  String tab = 'messages';
  final List<Map<String, dynamic>> stack = [];

  List<Conversation> convos = [];
  List<FriendRow> friends = [];
  List<FriendRequest> pendingReqs = [];
  List<GroupInvite> groupInvites = [];
  List<Notice> notices = [];

  final Map<String, Profile> people = {};
  final Map<String, Presence> presenceMap = {};
  final Map<String, String> readMap = {}; // convId -> 已读时间

  String? toast;
  int toastSeq = 0;
  String lastMsgId = '';
  bool banned = false;
  String banReason = '';
  String banShowId = '';

  Timer? _poll;
  Timer? _presence;
  bool _fetching = false;

  /* ------------------------------ 派生信息 ------------------------------ */

  String get displayName => profile?.nickname.isNotEmpty == true ? profile!.nickname : (profile?.showId ?? '');

  bool get isVip => profile?.vipAlive ?? false;

  String get myAvatar => profileAvatar(profile);

  String get myVipLevel => (profile?.vipAlive ?? false) ? (profile!.vipLevel) : '';

  List<Conversation> get sortedConvos {
    final list = [...convos];
    list.sort((a, b) => (b.lastTime).compareTo(a.lastTime));
    return list;
  }

  Profile? personOf(String userId) => people[userId];

  String avatarOf(String userId) {
    final p = people[userId];
    if (p == null) return '';
    return profileAvatar(p);
  }

  String nameOf(String userId, {String fallback = ''}) {
    final p = people[userId];
    if (p != null && p.nickname.isNotEmpty) return p.nickname;
    return fallback;
  }

  /// 好友备注优先
  String displayOf(String userId, {String fallback = ''}) {
    for (final f in friends) {
      if (f.friend == userId && f.remark.isNotEmpty) return f.remark;
    }
    return nameOf(userId, fallback: fallback);
  }

  bool onlineOf(String userId) => presenceMap[userId]?.online ?? false;

  String titleOf(Conversation c) {
    if (c.isGroup) return c.title;
    final idx = c.members.indexWhere((m) => m != user?.id);
    if (idx >= 0) return displayOf(c.members[idx], fallback: c.title);
    return c.title;
  }

  String avatarUrlOf(Conversation c) {
    if (c.isGroup) {
      final a = convAvatarUrl(c);
      if (a.isNotEmpty) return a;
      return '';
    }
    final idx = c.members.indexWhere((m) => m != user?.id);
    if (idx >= 0) return avatarOf(c.members[idx]);
    return '';
  }

  bool unreadOf(Conversation c) {
    if (c.lastTime.isEmpty) return false;
    final seen = readMap[c.id];
    if (seen == null || seen.isEmpty) return c.lastText.isNotEmpty;
    return c.lastTime.compareTo(seen) > 0;
  }

  /* ------------------------------ 生命周期 ------------------------------ */

  Future<void> boot() async {
    final sp = await SharedPreferences.getInstance();
    final t = sp.getString('wy_token') ?? '';
    final uid = sp.getString('wy_uid') ?? '';
    api.token = t;
    if (t.isNotEmpty && uid.isNotEmpty) {
      try {
        final r = await api.refreshAuth();
        user = UserRec.from(r['record']);
        await _loadMine();
        await refreshAll();
        if (profile?.banned == true) {
          banned = true;
          banReason = profile?.banReason ?? '';
          banShowId = profile?.showId ?? '';
        }
      } catch (_) {
        api.token = '';
        await sp.remove('wy_token');
      }
    }
    booting = false;
    notifyListeners();
    if (user != null) _startPolling();
  }

  Future<void> _loadMine() async {
    if (user == null) return;
    Prefs.uid = user!.id;
    readMap
      ..clear()
      ..addAll(Prefs.loadRead());
    profile = await api.profileOf(user!.id);
    if (profile != null) people[user!.id] = profile!;
  }

  void _startPolling() {
    _poll?.cancel();
    _poll = Timer.periodic(const Duration(seconds: 4), (_) => _tick());
    _presence?.cancel();
    _presence = Timer.periodic(const Duration(seconds: 30), (_) => refreshPresence());
  }

  void stopPolling() {
    _poll?.cancel();
    _presence?.cancel();
  }

  Future<void> _tick() async {
    if (user == null || _fetching) return;
    _fetching = true;
    try {
      await _refreshConvos(silent: true);
    } catch (_) {}
    _fetching = false;
  }

  /* ------------------------------- 通知 -------------------------------- */

  Future<void> _refreshConvos({bool silent = false}) async {
    final list = await api.conversations();
    // 新消息检测
    for (final c in list) {
      final old = convos.where((x) => x.id == c.id).toList();
      if (old.isEmpty) continue;
      if (c.lastTime != old.first.lastTime) {
        final isMine = c.lastText.startsWith('我:');
        if (!isMine && !_isMuted(c.id)) {
          final inThis = stack.isNotEmpty &&
              stack.last['name'] == 'chat' &&
              stack.last['params']?['convId'] == c.id;
          if (!inThis) {
            AppNotifier.instance.notify(title: titleOf(c), body: c.lastText, convId: c.id);
          }
        }
      }
    }
    convos = list;

    final ids = <String>{};
    for (final c in list) {
      ids.addAll(c.members);
    }
    for (final f in friends) {
      ids.add(f.friend);
    }
    if (ids.isNotEmpty) {
      final missing = ids.where((e) => !people.containsKey(e)).toList();
      if (missing.isNotEmpty) {
        final got = await api.profilesByIds(missing);
        people.addAll(got);
      }
    }
    if (!silent) notifyListeners();
    notifyListeners();
  }

  bool _isMuted(String convId) => Prefs.isMuted(convId);

  Future<void> refreshAll() async {
    if (user == null) return;
    await Future.wait([
      _refreshConvos(),
      refreshFriends(),
      refreshRequests(),
      refreshGroupInvites(),
      refreshNotices(),
      refreshPresence(),
    ]);
    notifyListeners();
  }

  Future<void> refreshFriends() async {
    if (user == null) return;
    friends = await api.friends(user!.id);
    notifyListeners();
  }

  Future<void> refreshRequests() async {
    if (user == null) return;
    pendingReqs = await api.incomingRequests(user!.id);
    notifyListeners();
  }

  Future<void> refreshGroupInvites() async {
    if (user == null) return;
    groupInvites = await api.myGroupInvites(user!.id);
    notifyListeners();
  }

  Future<void> refreshNotices() async {
    try {
      final r = await api.notices();
      notices = asList(r['items']).map(Notice.from).toList();
    } catch (_) {}
  }

  Future<void> refreshPresence() async {
    if (user == null) return;
    final ids = <String>{};
    for (final c in convos) {
      ids.addAll(c.members.where((m) => m != user!.id));
    }
    if (ids.isEmpty) return;
    try {
      final got = await api.presence(ids.toList());
      presenceMap.addAll(got);
      notifyListeners();
    } catch (_) {}
    unawaited(api.ping());
  }

  Future<void> refreshProfile() async {
    await _loadMine();
    notifyListeners();
  }

  /* ------------------------------- 认证 -------------------------------- */

  Future<void> signIn(String identity, String password) async {
    final r = await api.login(identity, password);
    final t = '${r['token'] ?? ''}';
    final u = UserRec.from(r['record']);
    api.token = t;
    user = u;
    await api.updateUser(u.id, {'lastLogin': DateTime.now().toUtc().toIso8601String()}).catchError((_) => u);
    await _loadMine();
    if (profile != null && profile!.banned) {
      banned = true;
      banReason = profile!.banReason;
      banShowId = profile!.showId;
      api.token = '';
      notifyListeners();
      throw ApiException(403, '账号已封禁');
    }
    Prefs.uid = u.id;
    final sp = await SharedPreferences.getInstance();
    await sp.setString('wy_token', t);
    await sp.setString('wy_uid', u.id);
    await refreshAll();
    _startPolling();
    notifyListeners();
  }

  Future<void> signUp(String nickname, String password, {String ref = ''}) async {
    await api.signUp(nickname: nickname, password: password, ref: ref);
    user = UserRec.from(await api.refreshAuth().then((r) => r['record']));
    await _loadMine();
    final sp = await SharedPreferences.getInstance();
    await sp.setString('wy_token', api.token);
    await sp.setString('wy_uid', user!.id);
    await refreshAll();
    _startPolling();
    notifyListeners();
  }

  Future<void> signOut() async {
    stopPolling();
    final sp = await SharedPreferences.getInstance();
    await sp.remove('wy_token');
    await sp.remove('wy_uid');
    api.token = '';
    user = null;
    profile = null;
    Prefs.uid = '';
    readMap.clear();
    convos = [];
    friends = [];
    people.clear();
    stack.clear();
    tab = 'messages';
    notifyListeners();
  }

  /* ------------------------------- 路由 -------------------------------- */

  void push(String name, [Map<String, dynamic> params = const {}]) {
    stack.add({'name': name, 'params': params});
    notifyListeners();
  }

  bool back() {
    if (stack.isEmpty) return false;
    stack.removeLast();
    notifyListeners();
    return true;
  }

  void home() {
    stack.clear();
    notifyListeners();
  }

  void setTab(String t) {
    tab = t;
    stack.clear();
    notifyListeners();
  }

  void bump() => notifyListeners();

  void say(String msg) {
    toast = msg;
    toastSeq++;
    notifyListeners();
    Future.delayed(const Duration(seconds: 2), () {
      if (toast == msg) {
        toast = null;
        notifyListeners();
      }
    });
  }

  /* ------------------------------- 业务 -------------------------------- */

  Future<Conversation> openChat(Conversation c) async {
    push('chat', {'convId': c.id});
    readMap[c.id] = DateTime.now().toUtc().toIso8601String();
    Prefs.saveRead(c.id, readMap[c.id]!);
    unawaited(api.markConvRead(c.id).catchError((_) {}));
    notifyListeners();
    return c;
  }

  Future<Conversation> startDirect(String targetId, String targetName) async {
    var c = await api.findDirect(user!.id, targetId);
    c ??= await api.createConversation({
      'kind': 'direct',
      'title': targetName,
      'members': [user!.id, targetId],
      'last_text': '',
      'last_time': DateTime.now().toUtc().toIso8601String(),
    });
    await _refreshConvos();
    await openChat(c);
    return c;
  }

  /// 官方客服（00001）
  Future<void> openOfficial({String draft = '', bool autoSend = false}) async {
    final p = await api.profileByShowId('00001');
    if (p == null) {
      say('客服暂时不在线');
      return;
    }
    final c = await startDirect(p.user, p.nickname.isEmpty ? '官方客服' : p.nickname);
    if (draft.isNotEmpty) {
      push('chat', {'convId': c.id, 'draft': draft, 'autoSend': autoSend});
      notifyListeners();
    }
  }

  Future<void> markRead(String convId) async {
    final t = DateTime.now().toUtc().toIso8601String();
    readMap[convId] = t;
    await Prefs.saveRead(convId, t);
    unawaited(api.markConvRead(convId).catchError((_) {}));
    notifyListeners();
  }

  void clearBanned() {
    banned = false;
    banReason = '';
    banShowId = '';
    notifyListeners();
  }
}
